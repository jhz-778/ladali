clear @s #minecraft:bottle
effect clear @s[nbt={active_effects:[{id:"minecraft:night_vision"}]}] minecraft:blindness
advancement revoke @s only bedwars:game/bottle