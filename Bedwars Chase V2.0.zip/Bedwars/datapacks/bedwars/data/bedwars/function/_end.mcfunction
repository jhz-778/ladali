#缓冲
kill @e[tag=!npc,type=!minecraft:player]
data merge storage minecraft:bedwars {start:0b,rain:0b,dragon:0b}
title @a times 0 100 0
title @a title {"text":"Ending...","color":"yellow","bold":true}
gamemode spectator @a
schedule function bedwars:ending 50t replace
worldborder set 5000
#建筑清理
fill -127 111 -127 127 111 127 minecraft:air replace
fill -127 110 -127 127 110 127 minecraft:air replace
fill -127 109 -127 127 109 127 minecraft:air replace
fill -127 108 -127 127 108 127 minecraft:air replace
fill -127 107 -127 127 107 127 minecraft:air replace
fill -127 106 -127 127 106 127 minecraft:air replace
fill -127 105 -127 127 105 127 minecraft:air replace
fill -127 104 -127 127 104 127 minecraft:air replace
fill -127 103 -127 127 103 127 minecraft:air replace
fill -127 102 -127 127 102 127 minecraft:air replace
fill -127 101 -127 127 101 127 minecraft:air replace
fill -127 100 -127 127 100 127 minecraft:air replace
fill -127 99 -127 127 99 127 minecraft:air replace
fill -127 98 -127 127 98 127 minecraft:air replace
fill -127 97 -127 127 97 127 minecraft:air replace
fill -127 96 -127 127 96 127 minecraft:air replace
fill -127 95 -127 127 95 127 minecraft:air replace
fill -127 94 -127 127 94 127 minecraft:air replace
fill -127 93 -127 127 93 127 minecraft:air replace
fill -127 92 -127 127 92 127 minecraft:air replace
fill -127 91 -127 127 91 127 minecraft:air replace
fill -127 90 -127 127 90 127 minecraft:air replace
fill -127 89 -127 127 89 127 minecraft:air replace
fill -127 88 -127 127 88 127 minecraft:air replace
fill -127 87 -127 127 87 127 minecraft:air replace
fill -127 86 -127 127 86 127 minecraft:air replace
fill -127 85 -127 127 85 127 minecraft:air replace
fill -127 84 -127 127 84 127 minecraft:air replace
fill -127 83 -127 127 83 127 minecraft:air replace
fill -127 82 -127 127 82 127 minecraft:air replace
fill -127 81 -127 127 81 127 minecraft:air replace
fill -127 80 -127 127 80 127 minecraft:air replace
fill -127 79 -127 127 79 127 minecraft:air replace
fill -127 78 -127 127 78 127 minecraft:air replace
fill -127 77 -127 127 77 127 minecraft:air replace
fill -127 76 -127 127 76 127 minecraft:air replace
fill -127 75 -127 127 75 127 minecraft:air replace
fill -127 74 -127 127 74 127 minecraft:air replace
fill -127 73 -127 127 73 127 minecraft:air replace
fill -127 72 -127 127 72 127 minecraft:air replace
fill -127 71 -127 127 71 127 minecraft:air replace
fill -127 70 -127 127 70 127 minecraft:air replace
fill -127 69 -127 127 69 127 minecraft:air replace
fill -127 68 -127 127 68 127 minecraft:air replace
fill -127 67 -127 127 67 127 minecraft:air replace
fill -127 66 -127 127 66 127 minecraft:air replace
fill -127 65 -127 127 65 127 minecraft:air replace
fill -127 64 -127 127 64 127 minecraft:air replace
execute if data storage minecraft:bedwars {mode:1b} run function mode:chase/clear
execute if data storage minecraft:bedwars {mode:3b} run function mode:chase/clear