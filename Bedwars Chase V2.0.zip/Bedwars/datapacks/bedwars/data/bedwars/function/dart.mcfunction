kill @e[type=minecraft:experience_bottle,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[14.0f]}}}},limit=1]
execute anchored eyes positioned ^ ^ ^ run summon minecraft:arrow ~ ~ ~ {crit:1b,damage:0.3d,Tags:["dart"]}
execute anchored eyes positioned ^ ^ ^1 run particle minecraft:crit ~ ~ ~ 0 0 0 1 5 normal
data modify entity @e[type=minecraft:arrow,limit=1,tag=dart] Owner set from entity @s UUID
summon minecraft:marker ~ ~ ~ {Tags:["motion"]}
tag @s add dartmotion
execute as @e[type=minecraft:marker,tag=motion] run tp 0.0 0.0 0.0
execute as @e[type=minecraft:marker,tag=motion] at @s rotated as @a[tag=dartmotion,limit=1] run tp ^ ^ ^10
tag @s remove dartmotion
data modify entity @e[type=minecraft:arrow,limit=1,tag=dart] Motion set from entity @e[type=minecraft:marker,limit=1,tag=motion] Pos
tag @e[type=minecraft:arrow] remove dart
kill @e[type=minecraft:marker,tag=motion]