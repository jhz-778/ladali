tag @s remove out
gamemode spectator @s
function bedwars:player_death
function bedwars:enderchest_loot
function bedwars:_list
function bedwars:_test