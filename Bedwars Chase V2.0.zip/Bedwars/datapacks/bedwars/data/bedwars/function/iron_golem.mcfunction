advancement grant @s only bedwars:bedwars/summon_iron_golem
execute if entity @s[team=red] at @s run team join red @e[type=minecraft:iron_golem,limit=1,sort=nearest,tag=!iron_golem]
execute if entity @s[team=blue] at @s run team join blue @e[type=minecraft:iron_golem,limit=1,sort=nearest,tag=!iron_golem]
execute if entity @s[team=green] at @s run team join green @e[type=minecraft:iron_golem,limit=1,sort=nearest,tag=!iron_golem]
execute if entity @s[team=yellow] at @s run team join yellow @e[type=minecraft:iron_golem,limit=1,sort=nearest,tag=!iron_golem]
execute as @e[type=minecraft:iron_golem,limit=1,sort=nearest,tag=!iron_golem] at @s run function bedwars:goleming
scoreboard players reset @s golem