gamemode spectator @a
tp @a 0 112 0
title @a times 0 100 0
title @a title {"text":"Loading...","color":"green","bold":true}
schedule function bedwars:starting 50t replace