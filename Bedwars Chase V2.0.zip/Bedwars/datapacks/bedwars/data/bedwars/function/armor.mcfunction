#盔甲
item modify entity @s armor.head bedwars:armor
item modify entity @s armor.chest bedwars:armor
item modify entity @s armor.legs bedwars:armor
item modify entity @s armor.feet bedwars:armor
#盾牌
execute if items entity @s weapon.mainhand minecraft:shield run item modify entity @s weapon.mainhand bedwars:hand_shield
execute if items entity @s weapon.offhand minecraft:shield run item modify entity @s weapon.offhand bedwars:hand_shield
execute store result score @s custom run clear @s minecraft:shield[!minecraft:custom_data={hand:1b}]
loot give @s loot bedwars:weapon/shield
execute store result score @s dummy run clear @s minecraft:shield 0
scoreboard players operation @s custom -= @s dummy
execute if score @s custom matches 1.. at @s run loot spawn ~ ~ ~ loot bedwars:weapon/shield
execute if items entity @s weapon.mainhand minecraft:shield run item modify entity @s weapon.mainhand bedwars:hand_remove
execute if items entity @s weapon.offhand minecraft:shield run item modify entity @s weapon.offhand bedwars:hand_remove