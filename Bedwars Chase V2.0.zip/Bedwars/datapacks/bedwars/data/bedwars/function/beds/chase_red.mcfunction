function mode:chase/test
execute unless score #red tick matches 1..5 as @a[team=red] run function bedwars:_death
execute unless score #red tick matches 1..5 as @a[team=blue] at @s run playsound minecraft:entity.ender_dragon.ambient master @s ~ ~ ~ 0.75
execute unless score #red tick matches 1..5 run tellraw @a [{"text":">-","color":"white","bold":true},{"translate":"warn.base.red","color":"red"},{"translate":"warn.was.break","bold":false},{"selector":"@s"},{"translate":"warn.base.destroy","bold":false},{"text":"！"}]
title @a[team=red] title [{"translate":"warn.base.lost","color":"red"}]
execute if score #red tick matches 1 run function mode:chase/bed/red_1
execute if score #red tick matches 2 run function mode:chase/bed/red_2
execute if score #red tick matches 3 run function mode:chase/bed/red_3
execute if score #red tick matches 4 run function mode:chase/bed/red_4
execute if score #red tick matches 5 run function mode:chase/bed/red_5
execute if score #red tick matches 6 run function mode:chase/bed/red_6
execute if score #red tick matches 7 run function mode:chase/bed/red_7
execute if score #red tick matches 8 run function mode:chase/bed/red_8
execute if score #red tick matches 9 run function mode:chase/bed/red_9
execute if score #red tick matches 10 run function mode:chase/bed/red_10
execute if score #red tick matches 11 run function mode:chase/bed/red_11
execute if score #red tick matches 12 run function mode:chase/bed/red_12
execute if score #red tick matches 13 run function mode:chase/bed/red_13
execute if score #red tick matches 14 run function mode:chase/bed/red_14
execute if score #red tick matches 15 run function mode:chase/bed/red_15
function mode:chase/list
function mode:chase/worldborder