execute if entity @s[team=green] run function bedwars:beds/own
execute if entity @s[team=!green] run function bedwars:beds/bed_lime
scoreboard players reset @s bed_lime