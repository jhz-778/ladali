execute if entity @s[team=yellow] run function bedwars:beds/own
execute if entity @s[team=!yellow] run function bedwars:beds/bed_yellow
scoreboard players reset @s bed_yellow