function mode:chase/test
execute unless score #blue tick matches 1 unless score #blue tick matches 6 unless score #blue tick matches 10 unless score #blue tick matches 13 unless score #blue tick matches 15 as @a[team=blue] run function bedwars:_death
title @a[team=blue] title [{"translate":"warn.base.lost","color":"red"}]
execute unless score #blue tick matches 1 unless score #blue tick matches 6 unless score #blue tick matches 10 unless score #blue tick matches 13 unless score #blue tick matches 15 as @a[team=red] at @s run playsound minecraft:entity.ender_dragon.ambient master @s ~ ~ ~ 0.75
execute unless score #blue tick matches 1 unless score #blue tick matches 6 unless score #blue tick matches 10 unless score #blue tick matches 13 unless score #blue tick matches 15 run tellraw @a [{"text":">-","color":"white","bold":true},{"translate":"warn.base.blue","color":"blue"},{"translate":"warn.was.break","bold":false},{"selector":"@s"},{"translate":"warn.base.destroy","bold":false},{"text":"！"}]
execute if score #blue tick matches 1 run function mode:chase/bed/blue_1
execute if score #blue tick matches 2 run function mode:chase/bed/blue_2
execute if score #blue tick matches 3 run function mode:chase/bed/blue_3
execute if score #blue tick matches 4 run function mode:chase/bed/blue_4
execute if score #blue tick matches 5 run function mode:chase/bed/blue_5
execute if score #blue tick matches 6 run function mode:chase/bed/blue_6
execute if score #blue tick matches 7 run function mode:chase/bed/blue_7
execute if score #blue tick matches 8 run function mode:chase/bed/blue_8
execute if score #blue tick matches 9 run function mode:chase/bed/blue_9
execute if score #blue tick matches 10 run function mode:chase/bed/blue_10
execute if score #blue tick matches 11 run function mode:chase/bed/blue_11
execute if score #blue tick matches 12 run function mode:chase/bed/blue_12
execute if score #blue tick matches 13 run function mode:chase/bed/blue_13
execute if score #blue tick matches 14 run function mode:chase/bed/blue_14
execute if score #blue tick matches 15 run function mode:chase/bed/blue_15
function mode:chase/list
function mode:chase/worldborder