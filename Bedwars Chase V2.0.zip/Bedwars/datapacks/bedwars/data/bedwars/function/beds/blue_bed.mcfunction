execute if entity @s[team=blue] run function bedwars:beds/own
execute unless data storage minecraft:bedwars {mode:1b} unless data storage minecraft:bedwars {mode:3b} if entity @s[team=!blue] run function bedwars:beds/bed_blue
execute if data storage minecraft:bedwars {mode:1b} if entity @s[team=!blue] run function bedwars:beds/chase_blue
execute if data storage minecraft:bedwars {mode:3b} if entity @s[team=!blue] run function bedwars:beds/chase_blue
scoreboard players reset @s bed_blue