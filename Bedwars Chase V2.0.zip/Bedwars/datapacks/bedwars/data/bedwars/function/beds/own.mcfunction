advancement grant @s only bedwars:bedwars/traitor
tellraw @s [{"translate":"warn.break.own","color":"red"}]
execute if entity @s[team=red] run function map:bed/_red
execute if entity @s[team=blue] run function map:bed/_blue
execute if entity @s[team=green] run function map:bed/_green
execute if entity @s[team=yellow] run function map:bed/_yellow