execute if entity @s[team=red] run function bedwars:beds/own
execute unless data storage minecraft:bedwars {mode:1b} unless data storage minecraft:bedwars {mode:3b} if entity @s[team=!red] run function bedwars:beds/bed_red
execute if data storage minecraft:bedwars {mode:1b} if entity @s[team=!red] run function bedwars:beds/chase_red
execute if data storage minecraft:bedwars {mode:3b} if entity @s[team=!red] run function bedwars:beds/chase_red
scoreboard players reset @s bed_red