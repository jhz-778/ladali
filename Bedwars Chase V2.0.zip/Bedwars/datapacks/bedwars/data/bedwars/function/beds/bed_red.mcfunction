data merge storage minecraft:red {bed:0b}
function bedwars:_list
execute as @a[team=red] at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 1.5
execute as @a[team=!red] at @s run playsound minecraft:entity.ender_dragon.ambient master @s ~ ~ ~ 0.75
title @a[team=red] times 10 50 10
execute as @a[team=red] run scoreboard players set @s title 60
execute as @a[team=red] run title @s title [{"translate":"warn.title.bed","color":"red"}]
execute as @a[team=red] run title @s subtitle [{"translate":"warn.sub.bed","color":"white"}]
tellraw @a [{"text":">-","color":"white","bold":true},{"translate":"warn.bed.red","color":"red"},{"translate":"warn.was.break","bold":false},{"selector":"@s"},{"translate":"warn.bed.destroy","bold":false},{"text":"！"}]
scoreboard players add @s bed 1
execute if score @s bed matches 3.. run advancement grant @s only bedwars:bedwars/brokener
function bedwars:_test