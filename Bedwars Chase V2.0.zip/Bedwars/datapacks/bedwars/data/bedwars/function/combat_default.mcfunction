data modify block 2011 82 2019 front_text.messages[2] set value '{"translate":"setting.combat.default","clickEvent":{"action":"run_command","value":"function bedwars:combat_faster"}}'
data merge storage minecraft:bedwars {combat:0b}
execute if score #control gui matches 2 run function gui:_control/weapon_list
execute if score #control gui matches 3 run function gui:_control/bows_list
execute if score #control gui matches 4 run function gui:_control/tool_list
execute as @a run attribute @s minecraft:attack_speed base set 4
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1