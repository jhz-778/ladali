execute if data storage minecraft:red {bed:1b} unless entity @a[team=red,gamemode=!spectator] unless entity @a[team=red,gamemode=spectator,scores={revive=1..}] run schedule function bedwars:schedule/red_bed 6000t
execute if data storage minecraft:blue {bed:1b} unless entity @a[team=blue,gamemode=!spectator] unless entity @a[team=blue,gamemode=spectator,scores={revive=1..}] run schedule function bedwars:schedule/blue_bed 6000t
execute if data storage minecraft:green {bed:1b} unless entity @a[team=green,gamemode=!spectator] unless entity @a[team=green,gamemode=spectator,scores={revive=1..}] run schedule function bedwars:schedule/green_bed 6000t
execute if data storage minecraft:yellow {bed:1b} unless entity @a[team=yellow,gamemode=!spectator] unless entity @a[team=yellow,gamemode=spectator,scores={revive=1..}] run schedule function bedwars:schedule/yellow_bed 6000t
function bedwars:_test
function bedwars:_list