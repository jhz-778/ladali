execute if entity @s[tag=egg_red] run team join red @e[type=minecraft:chicken,sort=nearest,tag=!cxk,distance=..3]
execute if entity @s[tag=egg_blue] run team join blue @e[type=minecraft:chicken,sort=nearest,tag=!cxk,distance=..3]
execute if entity @s[tag=egg_green] run team join green @e[type=minecraft:chicken,sort=nearest,tag=!cxk,distance=..3]
execute if entity @s[tag=egg_yellow] run team join yellow @e[type=minecraft:chicken,sort=nearest,tag=!cxk,distance=..3]
item replace entity @e[type=minecraft:chicken,sort=nearest,tag=!cxk,distance=..3] armor.head from entity @s armor.chest
execute as @e[type=minecraft:chicken,sort=nearest,tag=!cxk,distance=..3] run function bedwars:chicken_data
kill @s