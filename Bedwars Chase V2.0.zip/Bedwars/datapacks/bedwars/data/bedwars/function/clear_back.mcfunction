clear @s
scoreboard players set @s gui -100
effect clear @s
effect give @s minecraft:instant_health 1 4 true
function bedwars:player_attribute