team join spectator @s
scoreboard players set @s gui -1
tellraw @s [{"translate":"warn.game.start"},{"translate":"gameMode.spectator","color":"gray"}]