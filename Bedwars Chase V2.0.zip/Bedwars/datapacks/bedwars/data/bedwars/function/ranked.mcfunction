scoreboard players set #ranking tick 0
scoreboard players operation #ranking tick > @a[scores={tick=0..},team=!spectator] tick
execute as @a[team=!spectator] if score @s tick = #ranking tick run tag @s add 3rd
tellraw @a [{"text":"   "},{"text":"3rd-","color":"yellow","bold":true},{"selector":"@a[tag=3rd]"},{"text":":","bold":true},{"score":{"name":"#ranking","objective":"tick"},"color":"red"}]
scoreboard players set @a[tag=3rd] tick -1
tag @a remove 3rd