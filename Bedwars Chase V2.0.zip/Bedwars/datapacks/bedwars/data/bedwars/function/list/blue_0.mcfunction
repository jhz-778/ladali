scoreboard players set §9蓝队§9-B：§c✘§r§7（You） blue_ui 5
scoreboard players set §9蓝队§9-B：§c✘ red_ui 5
scoreboard players set §9蓝队§9-B：§c✘ green_ui 5
scoreboard players set §9蓝队§9-B：§c✘ yellow_ui 5
scoreboard players set §9蓝队§9-B：§c✘ spectator_ui 5