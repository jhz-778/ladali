#获取(后续函数会调用，勿删)
function mode:chase/test
#检测
scoreboard players set #blue limit 1
execute if data storage minecraft:chase {r2:"blue"} run scoreboard players add #blue limit 1
execute if data storage minecraft:chase {r1:"blue"} run scoreboard players add #blue limit 1
execute if data storage minecraft:chase {b1:"blue"} run scoreboard players add #blue limit 1
execute if data storage minecraft:chase {b2:"blue"} run scoreboard players add #blue limit 1
#五床
execute if score #blue limit matches 5 run scoreboard players set §9蓝队§9-B：§a✔✔✔✔✔§r§7（You） blue_ui 5
execute if score #blue limit matches 5 run scoreboard players set §9蓝队§9-B：§a✔✔✔✔✔ red_ui 5
execute if score #blue limit matches 5 run scoreboard players set §9蓝队§9-B：§a✔✔✔✔✔ spectator_ui 5
#四床
execute if score #blue limit matches 4 run scoreboard players set §9蓝队§9-B：§a✔✔✔✔§r§7（You） blue_ui 5
execute if score #blue limit matches 4 run scoreboard players set §9蓝队§9-B：§a✔✔✔✔ red_ui 5
execute if score #blue limit matches 4 run scoreboard players set §9蓝队§9-B：§a✔✔✔✔ spectator_ui 5
#三床
execute if score #blue limit matches 3 run scoreboard players set §9蓝队§9-B：§a✔✔✔§r§7（You） blue_ui 5
execute if score #blue limit matches 3 run scoreboard players set §9蓝队§9-B：§a✔✔✔ red_ui 5
execute if score #blue limit matches 3 run scoreboard players set §9蓝队§9-B：§a✔✔✔ spectator_ui 5
#二床
execute if score #blue limit matches 2 run scoreboard players set §9蓝队§9-B：§a✔✔§r§7（You） blue_ui 5
execute if score #blue limit matches 2 run scoreboard players set §9蓝队§9-B：§a✔✔ red_ui 5
execute if score #blue limit matches 2 run scoreboard players set §9蓝队§9-B：§a✔✔ spectator_ui 5
#一床
execute if score #blue limit matches 1 run scoreboard players set §9蓝队§9-B：§a✔§r§7（You） blue_ui 5
execute if score #blue limit matches 1 run scoreboard players set §9蓝队§9-B：§a✔ red_ui 5
execute if score #blue limit matches 1 run scoreboard players set §9蓝队§9-B：§a✔ spectator_ui 5