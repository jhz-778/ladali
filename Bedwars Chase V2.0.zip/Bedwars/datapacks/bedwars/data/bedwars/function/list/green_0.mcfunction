scoreboard players set §a绿队§a-G：§c✘§r§7（You） green_ui 4
scoreboard players set §a绿队§a-G：§c✘ blue_ui 4
scoreboard players set §a绿队§a-G：§c✘ red_ui 4
scoreboard players set §a绿队§a-G：§c✘ yellow_ui 4
scoreboard players set §a绿队§a-G：§c✘ spectator_ui 4