scoreboard players set §c红队§c-R：§a✔§r§7（You） red_ui 6
scoreboard players set §c红队§c-R：§a✔ blue_ui 6
scoreboard players set §c红队§c-R：§a✔ green_ui 6
scoreboard players set §c红队§c-R：§a✔ yellow_ui 6
scoreboard players set §c红队§c-R：§a✔ spectator_ui 6