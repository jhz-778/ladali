scoreboard players set §a绿队§a-G：§a✔§r§7（You） green_ui 4
scoreboard players set §a绿队§a-G：§a✔ blue_ui 4
scoreboard players set §a绿队§a-G：§a✔ red_ui 4
scoreboard players set §a绿队§a-G：§a✔ yellow_ui 4
scoreboard players set §a绿队§a-G：§a✔ spectator_ui 4