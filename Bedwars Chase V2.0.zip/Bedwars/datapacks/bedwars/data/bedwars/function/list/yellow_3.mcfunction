scoreboard players set §e黄队§e-Y：§e3§r§7（You） yellow_ui 3
scoreboard players set §e黄队§e-Y：§e3 blue_ui 3
scoreboard players set §e黄队§e-Y：§e3 green_ui 3
scoreboard players set §e黄队§e-Y：§e3 red_ui 3
scoreboard players set §e黄队§e-Y：§e3 spectator_ui 3