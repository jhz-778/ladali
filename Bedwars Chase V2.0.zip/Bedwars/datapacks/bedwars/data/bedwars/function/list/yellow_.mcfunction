scoreboard players set §e黄队§e-Y：§a✔§r§7（You） yellow_ui 3
scoreboard players set §e黄队§e-Y：§a✔ blue_ui 3
scoreboard players set §e黄队§e-Y：§a✔ green_ui 3
scoreboard players set §e黄队§e-Y：§a✔ red_ui 3
scoreboard players set §e黄队§e-Y：§a✔ spectator_ui 3