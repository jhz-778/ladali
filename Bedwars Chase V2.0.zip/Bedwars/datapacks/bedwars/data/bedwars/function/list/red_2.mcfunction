scoreboard players set §c红队§c-R：§e2§r§7（You） red_ui 6
scoreboard players set §c红队§c-R：§e2 blue_ui 6
scoreboard players set §c红队§c-R：§e2 green_ui 6
scoreboard players set §c红队§c-R：§e2 yellow_ui 6
scoreboard players set §c红队§c-R：§e2 spectator_ui 6