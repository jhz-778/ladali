scoreboard players set §a绿队§a-G：§a4§r§7（You） green_ui 4
scoreboard players set §a绿队§a-G：§a4 blue_ui 4
scoreboard players set §a绿队§a-G：§a4 red_ui 4
scoreboard players set §a绿队§a-G：§a4 yellow_ui 4
scoreboard players set §a绿队§a-G：§a4 spectator_ui 4