scoreboard players set §c红队§c-R：§e3§r§7（You） red_ui 6
scoreboard players set §c红队§c-R：§e3 blue_ui 6
scoreboard players set §c红队§c-R：§e3 green_ui 6
scoreboard players set §c红队§c-R：§e3 yellow_ui 6
scoreboard players set §c红队§c-R：§e3 spectator_ui 6