scoreboard players set §9蓝队§9-B：§e3§r§7（You） blue_ui 5
scoreboard players set §9蓝队§9-B：§e3 red_ui 5
scoreboard players set §9蓝队§9-B：§e3 green_ui 5
scoreboard players set §9蓝队§9-B：§e3 yellow_ui 5
scoreboard players set §9蓝队§9-B：§e3 spectator_ui 5