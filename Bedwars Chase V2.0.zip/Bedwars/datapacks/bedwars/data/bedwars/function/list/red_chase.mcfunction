#获取(后续函数会调用，勿删)
function mode:chase/test
#检测
scoreboard players set #red limit 1
execute if data storage minecraft:chase {r2:"red"} run scoreboard players add #red limit 1
execute if data storage minecraft:chase {r1:"red"} run scoreboard players add #red limit 1
execute if data storage minecraft:chase {b1:"red"} run scoreboard players add #red limit 1
execute if data storage minecraft:chase {b2:"red"} run scoreboard players add #red limit 1
#五床
execute if score #red limit matches 5 run scoreboard players set §c红队§c-R：§a✔✔✔✔✔§r§7（You） red_ui 6
execute if score #red limit matches 5 run scoreboard players set §c红队§c-R：§a✔✔✔✔✔ blue_ui 6
execute if score #red limit matches 5 run scoreboard players set §c红队§c-R：§a✔✔✔✔✔ spectator_ui 6
#四床
execute if score #red limit matches 4 run scoreboard players set §c红队§c-R：§a✔✔✔✔§r§7（You） red_ui 6
execute if score #red limit matches 4 run scoreboard players set §c红队§c-R：§a✔✔✔✔ blue_ui 6
execute if score #red limit matches 4 run scoreboard players set §c红队§c-R：§a✔✔✔✔ spectator_ui 6
#三床
execute if score #red limit matches 3 run scoreboard players set §c红队§c-R：§a✔✔✔§r§7（You） red_ui 6
execute if score #red limit matches 3 run scoreboard players set §c红队§c-R：§a✔✔✔ blue_ui 6
execute if score #red limit matches 3 run scoreboard players set §c红队§c-R：§a✔✔✔ spectator_ui 6
#二床
execute if score #red limit matches 2 run scoreboard players set §c红队§c-R：§a✔✔§r§7（You） red_ui 6
execute if score #red limit matches 2 run scoreboard players set §c红队§c-R：§a✔✔ blue_ui 6
execute if score #red limit matches 2 run scoreboard players set §c红队§c-R：§a✔✔ spectator_ui 6
#一床
execute if score #red limit matches 1 run scoreboard players set §c红队§c-R：§a✔§r§7（You） red_ui 6
execute if score #red limit matches 1 run scoreboard players set §c红队§c-R：§a✔ blue_ui 6
execute if score #red limit matches 1 run scoreboard players set §c红队§c-R：§a✔ spectator_ui 6