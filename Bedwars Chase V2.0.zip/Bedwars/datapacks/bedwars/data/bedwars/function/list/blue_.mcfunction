scoreboard players set §9蓝队§9-B：§a✔§r§7（You） blue_ui 5
scoreboard players set §9蓝队§9-B：§a✔ red_ui 5
scoreboard players set §9蓝队§9-B：§a✔ green_ui 5
scoreboard players set §9蓝队§9-B：§a✔ yellow_ui 5
scoreboard players set §9蓝队§9-B：§a✔ spectator_ui 5