scoreboard players set §9蓝队§9-B：§a4§r§7（You） blue_ui 5
scoreboard players set §9蓝队§9-B：§a4 red_ui 5
scoreboard players set §9蓝队§9-B：§a4 green_ui 5
scoreboard players set §9蓝队§9-B：§a4 yellow_ui 5
scoreboard players set §9蓝队§9-B：§a4 spectator_ui 5