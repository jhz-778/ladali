scoreboard players set §9蓝队§9-B：§e1§r§7（You） blue_ui 5
scoreboard players set §9蓝队§9-B：§e1 red_ui 5
scoreboard players set §9蓝队§9-B：§e1 green_ui 5
scoreboard players set §9蓝队§9-B：§e1 yellow_ui 5
scoreboard players set §9蓝队§9-B：§e1 spectator_ui 5