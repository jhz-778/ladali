scoreboard players set §e黄队§e-Y：§e2§r§7（You） yellow_ui 3
scoreboard players set §e黄队§e-Y：§e2 blue_ui 3
scoreboard players set §e黄队§e-Y：§e2 green_ui 3
scoreboard players set §e黄队§e-Y：§e2 red_ui 3
scoreboard players set §e黄队§e-Y：§e2 spectator_ui 3