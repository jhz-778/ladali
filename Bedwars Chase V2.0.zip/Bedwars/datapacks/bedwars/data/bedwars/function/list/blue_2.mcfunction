scoreboard players set §9蓝队§9-B：§e2§r§7（You） blue_ui 5
scoreboard players set §9蓝队§9-B：§e2 red_ui 5
scoreboard players set §9蓝队§9-B：§e2 green_ui 5
scoreboard players set §9蓝队§9-B：§e2 yellow_ui 5
scoreboard players set §9蓝队§9-B：§e2 spectator_ui 5