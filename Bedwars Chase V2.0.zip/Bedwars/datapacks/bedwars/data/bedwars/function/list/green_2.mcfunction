scoreboard players set §a绿队§a-G：§e2§r§7（You） green_ui 4
scoreboard players set §a绿队§a-G：§e2 blue_ui 4
scoreboard players set §a绿队§a-G：§e2 red_ui 4
scoreboard players set §a绿队§a-G：§e2 yellow_ui 4
scoreboard players set §a绿队§a-G：§e2 spectator_ui 4