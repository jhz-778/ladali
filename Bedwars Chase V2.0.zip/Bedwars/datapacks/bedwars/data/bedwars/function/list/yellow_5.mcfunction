scoreboard players set §e黄队§e-Y：§e4§9+§r§7（You） yellow_ui 3
scoreboard players set §e黄队§e-Y：§e4§9+ blue_ui 3
scoreboard players set §e黄队§e-Y：§e4§9+ green_ui 3
scoreboard players set §e黄队§e-Y：§e4§9+ red_ui 3
scoreboard players set §e黄队§e-Y：§e4§9+ spectator_ui 3