scoreboard players set §e黄队§e-Y：§c✘§r§7（You） yellow_ui 3
scoreboard players set §e黄队§e-Y：§c✘ blue_ui 3
scoreboard players set §e黄队§e-Y：§c✘ green_ui 3
scoreboard players set §e黄队§e-Y：§c✘ red_ui 3
scoreboard players set §e黄队§e-Y：§c✘ spectator_ui 3