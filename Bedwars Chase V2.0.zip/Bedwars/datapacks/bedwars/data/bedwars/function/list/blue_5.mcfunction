scoreboard players set §9蓝队§9-B：§e4§9+§r§7（You） blue_ui 5
scoreboard players set §9蓝队§9-B：§e4§9+ red_ui 5
scoreboard players set §9蓝队§9-B：§e4§9+ green_ui 5
scoreboard players set §9蓝队§9-B：§e4§9+ yellow_ui 5
scoreboard players set §9蓝队§9-B：§e4§9+ spectator_ui 5