scoreboard players set §c红队§c-R：§c✘§r§7（You） red_ui 6
scoreboard players set §c红队§c-R：§c✘ blue_ui 6
scoreboard players set §c红队§c-R：§c✘ green_ui 6
scoreboard players set §c红队§c-R：§c✘ yellow_ui 6
scoreboard players set §c红队§c-R：§c✘ spectator_ui 6