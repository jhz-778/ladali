scoreboard players set §a绿队§a-G：§e4§9+§r§7（You） green_ui 4
scoreboard players set §a绿队§a-G：§e4§9+ blue_ui 4
scoreboard players set §a绿队§a-G：§e4§9+ red_ui 4
scoreboard players set §a绿队§a-G：§e4§9+ yellow_ui 4
scoreboard players set §a绿队§a-G：§e4§9+ spectator_ui 4