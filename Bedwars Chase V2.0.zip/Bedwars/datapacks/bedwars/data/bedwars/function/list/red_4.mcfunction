scoreboard players set §c红队§c-R：§a4§r§7（You） red_ui 6
scoreboard players set §c红队§c-R：§a4 blue_ui 6
scoreboard players set §c红队§c-R：§a4 green_ui 6
scoreboard players set §c红队§c-R：§a4 yellow_ui 6
scoreboard players set §c红队§c-R：§a4 spectator_ui 6