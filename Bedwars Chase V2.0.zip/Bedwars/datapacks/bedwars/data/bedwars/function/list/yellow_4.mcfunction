scoreboard players set §e黄队§e-Y：§a4§r§7（You） yellow_ui 3
scoreboard players set §e黄队§e-Y：§a4 blue_ui 3
scoreboard players set §e黄队§e-Y：§a4 green_ui 3
scoreboard players set §e黄队§e-Y：§a4 red_ui 3
scoreboard players set §e黄队§e-Y：§a4 spectator_ui 3