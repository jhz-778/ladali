scoreboard players set §a绿队§a-G：§e3§r§7（You） green_ui 4
scoreboard players set §a绿队§a-G：§e3 blue_ui 4
scoreboard players set §a绿队§a-G：§e3 red_ui 4
scoreboard players set §a绿队§a-G：§e3 yellow_ui 4
scoreboard players set §a绿队§a-G：§e3 spectator_ui 4