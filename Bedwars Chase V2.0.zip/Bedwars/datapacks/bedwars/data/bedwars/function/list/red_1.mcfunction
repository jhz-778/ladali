scoreboard players set §c红队§c-R：§e1§r§7（You） red_ui 6
scoreboard players set §c红队§c-R：§e1 blue_ui 6
scoreboard players set §c红队§c-R：§e1 green_ui 6
scoreboard players set §c红队§c-R：§e1 yellow_ui 6
scoreboard players set §c红队§c-R：§e1 spectator_ui 6