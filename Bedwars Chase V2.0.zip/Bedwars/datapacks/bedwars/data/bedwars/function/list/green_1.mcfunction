scoreboard players set §a绿队§a-G：§e1§r§7（You） green_ui 4
scoreboard players set §a绿队§a-G：§e1 blue_ui 4
scoreboard players set §a绿队§a-G：§e1 red_ui 4
scoreboard players set §a绿队§a-G：§e1 yellow_ui 4
scoreboard players set §a绿队§a-G：§e1 spectator_ui 4