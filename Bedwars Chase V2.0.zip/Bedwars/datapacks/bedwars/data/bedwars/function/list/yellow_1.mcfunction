scoreboard players set §e黄队§e-Y：§e1§r§7（You） yellow_ui 3
scoreboard players set §e黄队§e-Y：§e1 blue_ui 3
scoreboard players set §e黄队§e-Y：§e1 green_ui 3
scoreboard players set §e黄队§e-Y：§e1 red_ui 3
scoreboard players set §e黄队§e-Y：§e1 spectator_ui 3