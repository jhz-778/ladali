scoreboard players set §c红队§c-R：§e4§9+§r§7（You） red_ui 6
scoreboard players set §c红队§c-R：§e4§9+ blue_ui 6
scoreboard players set §c红队§c-R：§e4§9+ green_ui 6
scoreboard players set §c红队§c-R：§e4§9+ yellow_ui 6
scoreboard players set §c红队§c-R：§e4§9+ spectator_ui 6