scoreboard players set #withers tick 90
execute summon minecraft:wither run function bedwars:wither_set
data modify entity @e[type=minecraft:text_display,limit=1,tag=wither] text set value '""'