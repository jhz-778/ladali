item replace entity @e[type=minecraft:item_frame,tag=tracker,limit=1] container.0 from entity @s weapon.offhand
function bedwars:track
item replace entity @s weapon.offhand from entity @e[type=minecraft:item_frame,limit=1,tag=tracker] container.0