#综合
fill 2011 82 2023 2011 81 2019 minecraft:air replace
fill 2011 82 2017 2011 81 2011 minecraft:air replace
scoreboard players set #minute tick 0
scoreboard players set #second tick 0
scoreboard players set @a trap 0
scoreboard players set @a gui 0
scoreboard players set @a tip 0
scoreboard players set @a chest 0
scoreboard players set @a revive 0
scoreboard players set @a slay 0
scoreboard players set @a death 0
time set noon
weather clear
tag @a remove blocking
execute as @e[type=minecraft:marker,tag=saves] run data merge entity @s {data:{EnderItems:[]}}
execute as @a run function bedwars:ender_clear
experience set @a 0 levels
experience set @a 0 points
execute if data storage minecraft:bedwars {combat:1b} as @a run attribute @s minecraft:attack_speed base set 10
scoreboard players set @a bed 0
scoreboard players set @a kill 0
scoreboard players set @a last_kill 0
effect give @a minecraft:instant_health 1 9 true
scoreboard players set #plan tick 0
scoreboard players set #diamond tick 60
scoreboard players set #emerald tick 80
scoreboard players set #withers tick 90
scoreboard players set #diamond_tier tick 1
scoreboard players set #emerald_tier tick 1
scoreboard players reset @a pickaxe
scoreboard players reset @a axe
scoreboard players reset @a shovel
scoreboard players reset @a cd
scoreboard objectives remove quit
scoreboard objectives remove armor
scoreboard objectives remove spyglass
scoreboard objectives remove shears
scoreboard objectives remove compass
scoreboard objectives add quit dummy
scoreboard objectives add armor dummy
scoreboard objectives add spyglass dummy
scoreboard objectives add shears dummy
scoreboard objectives add compass dummy
scoreboard objectives add spectator_ui dummy [{"translate":"bedwars","color":"yellow"}]
scoreboard objectives add red_ui dummy [{"translate":"bedwars","color":"yellow"}]
scoreboard objectives add blue_ui dummy [{"translate":"bedwars","color":"yellow"}]
scoreboard objectives add green_ui dummy [{"translate":"bedwars","color":"yellow"}]
scoreboard objectives add yellow_ui dummy [{"translate":"bedwars","color":"yellow"}]
scoreboard objectives setdisplay sidebar.team.red red_ui
scoreboard objectives setdisplay sidebar.team.blue blue_ui
scoreboard objectives setdisplay sidebar.team.green green_ui
scoreboard objectives setdisplay sidebar.team.yellow yellow_ui
scoreboard objectives setdisplay sidebar.team.gray spectator_ui
scoreboard players set @a quit 0
#红队
data merge storage minecraft:red {bed:1b,glowing:0b,respawn:0b,twice:0b,out:0b,Items:[]}
scoreboard players set #red_breath tick 0
scoreboard players set #red_mining tick 0
scoreboard players set #red_healing tick 0
scoreboard players set #red_fire tick 0
scoreboard players set #red_protection tick 0
scoreboard players reset #red_sharpness tick
scoreboard players reset #red_resource
scoreboard players reset #red_trap tick
scoreboard players reset #red_trap_slow tick
scoreboard players reset #red_trap_mining tick
scoreboard players reset #red_trap_speed tick
scoreboard players reset #red_trap_warning tick
scoreboard players reset #red_trap_tp tick
scoreboard players reset #red_trap_slow limit
scoreboard players reset #red_trap_mining limit
scoreboard players reset #red_trap_speed limit
scoreboard players reset #red_trap_warning limit
scoreboard players reset #red_trap_tp limit
scoreboard players set #red_point count 0
scoreboard players set #red_point amount 0
scoreboard players set #red_point custom 0
#蓝队
data merge storage minecraft:blue {bed:1b,glowing:0b,respawn:0b,twice:0b,out:0b,Items:[]}
scoreboard players set #blue_breath tick 0
scoreboard players set #blue_mining tick 0
scoreboard players set #blue_healing tick 0
scoreboard players set #blue_fire tick 0
scoreboard players set #blue_protection tick 0
scoreboard players reset #blue_sharpness tick
scoreboard players reset #blue_resource
scoreboard players reset #blue_trap tick
scoreboard players reset #blue_trap_slow tick
scoreboard players reset #blue_trap_mining tick
scoreboard players reset #blue_trap_speed tick
scoreboard players reset #blue_trap_warning tick
scoreboard players reset #blue_trap_tp tick
scoreboard players reset #blue_trap_slow limit
scoreboard players reset #blue_trap_mining limit
scoreboard players reset #blue_trap_speed limit
scoreboard players reset #blue_trap_warning limit
scoreboard players reset #blue_trap_tp limit
scoreboard players set #blue_point count 0
scoreboard players set #blue_point amount 0
scoreboard players set #blue_point custom 0
#绿队
data merge storage minecraft:green {bed:1b,glowing:0b,respawn:0b,twice:0b,out:0b,Items:[]}
scoreboard players set #green_breath tick 0
scoreboard players set #green_mining tick 0
scoreboard players set #green_healing tick 0
scoreboard players set #green_fire tick 0
scoreboard players set #green_protection tick 0
scoreboard players reset #green_sharpness tick
scoreboard players reset #green_resource
scoreboard players reset #green_trap tick
scoreboard players reset #green_trap_slow tick
scoreboard players reset #green_trap_mining tick
scoreboard players reset #green_trap_speed tick
scoreboard players reset #green_trap_warning tick
scoreboard players reset #green_trap_tp tick
scoreboard players reset #green_trap_slow limit
scoreboard players reset #green_trap_mining limit
scoreboard players reset #green_trap_speed limit
scoreboard players reset #green_trap_warning limit
scoreboard players reset #green_trap_tp limit
scoreboard players set #green_point count 0
scoreboard players set #green_point amount 0
scoreboard players set #green_point custom 0
#黄队
data merge storage minecraft:yellow {bed:1b,glowing:0b,respawn:0b,twice:0b,out:0b,Items:[]}
scoreboard players set #yellow_breath tick 0
scoreboard players set #yellow_mining tick 0
scoreboard players set #yellow_healing tick 0
scoreboard players set #yellow_fire tick 0
scoreboard players set #yellow_protection tick 0
scoreboard players reset #yellow_sharpness tick
scoreboard players reset #yellow_resource
scoreboard players reset #yellow_trap tick
scoreboard players reset #yellow_trap_slow tick
scoreboard players reset #yellow_trap_mining tick
scoreboard players reset #yellow_trap_speed tick
scoreboard players reset #yellow_trap_warning tick
scoreboard players reset #yellow_trap_tp tick
scoreboard players reset #yellow_trap_slow limit
scoreboard players reset #yellow_trap_mining limit
scoreboard players reset #yellow_trap_speed limit
scoreboard players reset #yellow_trap_warning limit
scoreboard players reset #yellow_trap_tp limit
scoreboard players set #yellow_point count 0
scoreboard players set #yellow_point amount 0
scoreboard players set #yellow_point custom 0
#资源点
execute if data storage minecraft:bedwars {teams:0b} if data storage minecraft:detail {resource_fours:0b} run function bedwars:schedule/resource_slowly
execute if data storage minecraft:bedwars {teams:0b} if data storage minecraft:detail {resource_fours:1b} run function bedwars:schedule/resource_medium
execute if data storage minecraft:bedwars {teams:0b} if data storage minecraft:detail {resource_fours:2b} run function bedwars:schedule/resource_faster
execute if data storage minecraft:bedwars {teams:1b} if data storage minecraft:detail {resource_double:0b} run function bedwars:schedule/resource_slowly
execute if data storage minecraft:bedwars {teams:1b} if data storage minecraft:detail {resource_double:1b} run function bedwars:schedule/resource_medium
execute if data storage minecraft:bedwars {teams:1b} if data storage minecraft:detail {resource_double:2b} run function bedwars:schedule/resource_faster