scoreboard players set @a revive 0
title @a subtitle {"text":"加载中...","color":"white","bold":true,"italic":true}
data merge storage minecraft:bedwars {rain:0b,start:1b,dragon:0b}
function gui:_start
schedule function bedwars:begining 50t replace