fill ~ ~1 ~ ~ ~1 ~ minecraft:air replace minecraft:cobweb
fill ~1 ~ ~1 ~-1 ~ ~-1 minecraft:air replace minecraft:slime_block
fill ~-2 ~ ~1 ~2 ~ ~1 minecraft:air replace minecraft:slime_block
fill ~-2 ~ ~-1 ~2 ~ ~-1 minecraft:air replace minecraft:slime_block
fill ~-1 ~ ~2 ~-1 ~ ~-2 minecraft:air replace minecraft:slime_block
fill ~1 ~ ~2 ~1 ~ ~-2 minecraft:air replace minecraft:slime_block
kill @s