tag @s add looting
execute as @a[tag=!looting] if score @s uid = @a[tag=looting,limit=1] hid run tag @s add looter
execute as @a[tag=looter] run function bedwars:looter
tag @a remove looting