#夜视增益
execute if data storage minecraft:red {glowing:1b} run effect give @a[team=red] minecraft:night_vision 30 0 true
execute if data storage minecraft:blue {glowing:1b} run effect give @a[team=blue] minecraft:night_vision 30 0 true
execute if data storage minecraft:green {glowing:1b} run effect give @a[team=green] minecraft:night_vision 30 0 true
execute if data storage minecraft:yellow {glowing:1b} run effect give @a[team=yellow] minecraft:night_vision 30 0 true
#闪电
execute if predicate bedwars:lightning positioned 0 64 0 summon minecraft:marker run function bedwars:lightning