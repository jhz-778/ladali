tellraw @a [{"text":"➫","bold":true,"color":"dark_aqua"},{"translate":"game.time","bold":true,"color":"dark_aqua"},{"text":"："},{"color":"white","score":{"name":"#minute","objective":"tick"}},{"text":"m","color":"aqua","bold":false},{"color":"white","score":{"name":"#second","objective":"tick"}},{"text":"s","color":"aqua","bold":false}]
tellraw @a [{"text":"-------------------------","bold":true,"color":"green"}]
scoreboard players set #ranking tick 0
tellraw @a [{"translate":"ranking","bold":true,"color":"aqua"}]
execute as @a run scoreboard players operation @s tick = @s kill
scoreboard players operation #ranking tick > @a[scores={tick=0..},team=!spectator] tick
execute as @a[team=!spectator] if score @s tick = #ranking tick run tag @s add 1st
tellraw @a [{"text":"   "},{"text":"1st-","color":"yellow","bold":true},{"selector":"@a[tag=1st]"},{"text":":","bold":true},{"score":{"name":"#ranking","objective":"tick"},"color":"red"}]
scoreboard players set @a[tag=1st] tick -1
tag @a remove 1st
execute if entity @a[scores={tick=0..},team=!spectator] run function bedwars:ranking
scoreboard players reset #ranking tick
tellraw @a [{"text":"-------------------------","bold":true,"color":"green"}]