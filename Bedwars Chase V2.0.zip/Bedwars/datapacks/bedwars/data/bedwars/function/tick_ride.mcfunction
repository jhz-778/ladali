execute if entity @s[tag=fireball] run function explode:fireball
execute if entity @s[tag=silverfish] run function bedwars:silverfish_summon
execute if entity @s[tag=pearl_back] run function bedwars:pearl/store
execute if entity @s[tag=pearl] run function bedwars:pearl/tp
execute if entity @s[tag=rock] run function bedwars:rocked