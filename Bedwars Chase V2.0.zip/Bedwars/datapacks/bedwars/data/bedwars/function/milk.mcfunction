effect give @s minecraft:unluck 60 0 false
effect clear @s minecraft:wither
effect clear @s minecraft:slowness
effect clear @s minecraft:glowing
effect clear @s minecraft:weakness
effect clear @s minecraft:levitation
advancement revoke @s only bedwars:prop/milk