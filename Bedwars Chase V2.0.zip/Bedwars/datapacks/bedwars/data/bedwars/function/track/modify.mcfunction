scoreboard players add @s compass 1
scoreboard players set @s dummy 0
execute if score @s compass matches 3.. if data storage minecraft:bedwars {teams:1b} run scoreboard players set @s compass 1
execute if score @s compass matches 5.. run scoreboard players set @s compass 1
execute store success score @s dummy if predicate bedwars:empty run loot replace entity @s weapon.mainhand loot bedwars:compass
execute if predicate bedwars:empty_off unless score @s dummy matches 1 run loot replace entity @s weapon.offhand loot bedwars:compass
execute at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1