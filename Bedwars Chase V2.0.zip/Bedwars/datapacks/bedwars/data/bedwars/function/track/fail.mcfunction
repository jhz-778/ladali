scoreboard players set @s dummy 0
execute store success score @s dummy if predicate bedwars:empty run loot replace entity @s weapon.mainhand loot bedwars:compass
execute if predicate bedwars:empty_off unless score @s dummy matches 1 run loot replace entity @s weapon.offhand loot bedwars:compass
execute at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 0.5
tellraw @s [{"translate":"warn.cant.modify","color":"red"}]