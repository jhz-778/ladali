clear @s minecraft:compass
execute if entity @s[team=red] if data storage minecraft:blue {bed:0b} if data storage minecraft:green {bed:0b} if data storage minecraft:yellow {bed:0b} run tag @s add drop_pass
execute if entity @s[team=blue] if data storage minecraft:red {bed:0b} if data storage minecraft:green {bed:0b} if data storage minecraft:yellow {bed:0b} run tag @s add drop_pass
execute if entity @s[team=green] if data storage minecraft:red {bed:0b} if data storage minecraft:blue {bed:0b} if data storage minecraft:yellow {bed:0b} run tag @s add drop_pass
execute if entity @s[team=yellow] if data storage minecraft:red {bed:0b} if data storage minecraft:blue {bed:0b} if data storage minecraft:green {bed:0b} run tag @s add drop_pass
execute if entity @s[tag=drop_pass] run function bedwars:track/modify
execute if entity @s[tag=!drop_pass] run function bedwars:track/fail
tag @a remove drop_pass
scoreboard players set @s drop 0