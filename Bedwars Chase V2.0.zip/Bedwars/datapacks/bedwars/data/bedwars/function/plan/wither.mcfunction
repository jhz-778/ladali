scoreboard players reset §5凋灵生成§r§5Wither-Spawn
scoreboard players set §b钻石点§r§bDiamond-III spectator_ui 8
scoreboard players set §b钻石点§r§bDiamond-III red_ui 9
scoreboard players set §b钻石点§r§bDiamond-III blue_ui 9
scoreboard players set §b钻石点§r§bDiamond-III green_ui 9
scoreboard players set §b钻石点§r§bDiamond-III yellow_ui 9
execute if data storage minecraft:bedwars {combat:0b} unless data storage minecraft:detail {wither_default:{attributes:[{base:0.0f,id:"minecraft:max_health"}]}} run function bedwars:withers_pass
execute if data storage minecraft:bedwars {combat:1b} unless data storage minecraft:detail {wither_faster:{attributes:[{base:0.0f,id:"minecraft:max_health"}]}} run function bedwars:withers_pass
execute if entity @e[type=minecraft:wither] as @a at @s run playsound minecraft:entity.wither.ambient master @s ~ ~ ~ 1 1
execute if entity @e[type=minecraft:wither] run tellraw @a [{"text":"—","bold":true},{"translate":"entity.minecraft.wither","color":"dark_purple","bold":false},{"translate":"warn.has.spawn","bold":false},{"text":"！"}]
execute at @e[type=minecraft:text_display,tag=wither] run setblock ~ ~-1 ~ minecraft:tinted_glass replace
function time:5min/30s