weather thunder
time set midnight
execute as @a at @s run playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 1 1
scoreboard players reset §5雷暴夜§r§5Thunder-Night
scoreboard players set §c床自毁§r§cBeds-Down spectator_ui 8
scoreboard players set §c床自毁§r§cBeds-Down red_ui 9
scoreboard players set §c床自毁§r§cBeds-Down blue_ui 9
scoreboard players set §c床自毁§r§cBeds-Down green_ui 9
scoreboard players set §c床自毁§r§cBeds-Down yellow_ui 9
item replace block 2012 77 2004 container.17 from block 2012 77 2004 container.8
execute as @a[scores={gui=6}] run item replace entity @s enderchest.5 from block 2012 57 2004 container.17
tellraw @a [{"text":"—","bold":true},{"translate":"warn.plan.rain","color":"dark_purple","bold":false},{"translate":"warn.coming","bold":false},{"text":",","bold":false},{"translate":"warn.show.rain","bold":false},{"text":"！"}]
data merge storage minecraft:bedwars {rain:1b}
function time:5min/60s