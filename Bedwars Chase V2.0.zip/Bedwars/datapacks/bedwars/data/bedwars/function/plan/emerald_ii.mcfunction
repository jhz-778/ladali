scoreboard players set #emerald_tier tick 2
scoreboard players reset §2绿宝石点§r§2Emerald-II
scoreboard players set §5凋灵生成§r§5Wither-Spawn spectator_ui 8
scoreboard players set §5凋灵生成§r§5Wither-Spawn red_ui 9
scoreboard players set §5凋灵生成§r§5Wither-Spawn blue_ui 9
scoreboard players set §5凋灵生成§r§5Wither-Spawn green_ui 9
scoreboard players set §5凋灵生成§r§5Wither-Spawn yellow_ui 9
execute if data storage minecraft:bedwars {combat:0b} if data storage minecraft:detail {wither_default:{attributes:[{base:0.0f,id:"minecraft:max_health"}]}} run scoreboard players add #plan tick 1
execute if data storage minecraft:bedwars {combat:1b} if data storage minecraft:detail {wither_faster:{attributes:[{base:0.0f,id:"minecraft:max_health"}]}} run scoreboard players add #plan tick 1
execute if score #plan tick matches 3 run kill @e[type=minecraft:text_display,tag=wither]
tellraw @a [{"text":"—","bold":true},{"translate":"resource.emerald","color":"dark_green","bold":false},{"text":" "},{"translate":"warn.update.to","bold":false},{"text":" "},{"text":"Tier-II","bold":false,"color":"yellow"}]
execute if score #plan tick matches 2 run function time:0min/60s