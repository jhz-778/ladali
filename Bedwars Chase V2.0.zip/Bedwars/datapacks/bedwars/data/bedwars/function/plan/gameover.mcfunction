scoreboard players set #minute number 0
scoreboard players set #second number 0
scoreboard players set §r时间§rTime-0:00 red_ui 8
scoreboard players set §r时间§rTime-0:00 blue_ui 8
scoreboard players set §r时间§rTime-0:00 green_ui 8
scoreboard players set §r时间§rTime-0:00 yellow_ui 8
execute if data storage minecraft:bedwars {win:0b} run function bedwars:win/draw