scoreboard players reset §5雷暴夜§r§5Thunder-Night
scoreboard players set §c床自毁§r§cBeds-Down spectator_ui 8
scoreboard players set §c床自毁§r§cBeds-Down red_ui 9
scoreboard players set §c床自毁§r§cBeds-Down blue_ui 9
scoreboard players set §c床自毁§r§cBeds-Down green_ui 9
scoreboard players set §c床自毁§r§cBeds-Down yellow_ui 9
scoreboard players set #plan tick 6
function time:9min/60s