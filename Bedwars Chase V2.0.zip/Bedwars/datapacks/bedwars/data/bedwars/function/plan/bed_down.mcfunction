scoreboard players reset §c床自毁§r§cBeds-Down
scoreboard players set §4绝杀模式§r§4Lore-Mode spectator_ui 8
scoreboard players set §4绝杀模式§r§4Lore-Mode red_ui 9
scoreboard players set §4绝杀模式§r§4Lore-Mode blue_ui 9
scoreboard players set §4绝杀模式§r§4Lore-Mode green_ui 9
scoreboard players set §4绝杀模式§r§4Lore-Mode yellow_ui 9
schedule clear bedwars:schedule/red_bed
schedule clear bedwars:schedule/blue_bed
schedule clear bedwars:schedule/green_bed
schedule clear bedwars:schedule/yellow_bed
title @a times 10 50 10
title @a title [{"translate":"warn.bed.down","color":"red"}]
title @a subtitle [{"translate":"warn.sub.bed","color":"white"}]
execute as @a at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 1.5
tellraw @a [{"text":"> ","color":"white","bold":true},{"translate":"warn.bed.down","color":"red"},{"text":",","bold":false},{"translate":"warn.sub.bed","bold":false},{"text":"！"}]
execute as @e[type=minecraft:marker,tag=bedset] at @s run fill ~5 ~5 ~5 ~-5 ~-5 ~-5 minecraft:air replace #minecraft:beds
data merge storage minecraft:red {bed:0b}
data merge storage minecraft:blue {bed:0b}
data merge storage minecraft:green {bed:0b}
data merge storage minecraft:yellow {bed:0b}
function bedwars:_list
function bedwars:_test
execute if data storage minecraft:bedwars {mode:1b} run function mode:chase/list
execute if data storage minecraft:bedwars {mode:1b} run function mode:chase/worldborder
execute if data storage minecraft:bedwars {mode:3b} run function mode:chase/list
execute if data storage minecraft:bedwars {mode:3b} run function mode:chase/worldborder
function time:6min/60s