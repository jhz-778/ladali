scoreboard players set #emerald_tier tick 3
scoreboard players reset §2绿宝石点§r§2Emerald-III
scoreboard players set §5雷暴夜§r§5Thunder-Night spectator_ui 8
scoreboard players set §5雷暴夜§r§5Thunder-Night red_ui 9
scoreboard players set §5雷暴夜§r§5Thunder-Night blue_ui 9
scoreboard players set §5雷暴夜§r§5Thunder-Night green_ui 9
scoreboard players set §5雷暴夜§r§5Thunder-Night yellow_ui 9
execute if data storage minecraft:detail {rain_plan:0b} run function bedwars:plan/dark_rain_skip
tellraw @a [{"text":"—","bold":true},{"translate":"resource.emerald","color":"dark_green","bold":false},{"text":" "},{"translate":"warn.update.to","bold":false},{"text":" "},{"text":"Tier-III","bold":false,"color":"yellow"}]
execute if data storage minecraft:detail {rain_plan:1b} run function time:5min/60s