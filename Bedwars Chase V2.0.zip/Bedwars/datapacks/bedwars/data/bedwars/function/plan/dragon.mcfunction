scoreboard players reset §4绝杀模式§r§4Lore-Mode
scoreboard players set §e游戏结束§r§eGame-Over spectator_ui 8
scoreboard players set §e游戏结束§r§eGame-Over red_ui 9
scoreboard players set §e游戏结束§r§eGame-Over blue_ui 9
scoreboard players set §e游戏结束§r§eGame-Over green_ui 9
scoreboard players set §e游戏结束§r§eGame-Over yellow_ui 9
data merge storage minecraft:bedwars {dragon:1b}
scoreboard players set #dragon cd 0
gamerule mobGriefing true
gamemode survival @a[gamemode=adventure]
function bedwars:schedule/dragon
execute as @a at @s run playsound minecraft:entity.ender_dragon.ambient master @s ~ ~ ~ 2
execute positioned 0 80 0 summon minecraft:ender_dragon run function bedwars:dragon/set
function time:9min/60s