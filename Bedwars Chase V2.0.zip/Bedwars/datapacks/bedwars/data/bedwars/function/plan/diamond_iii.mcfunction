scoreboard players set #diamond_tier tick 3
scoreboard players reset §b钻石点§r§bDiamond-III
scoreboard players set §2绿宝石点§r§2Emerald-III spectator_ui 8
scoreboard players set §2绿宝石点§r§2Emerald-III red_ui 9
scoreboard players set §2绿宝石点§r§2Emerald-III blue_ui 9
scoreboard players set §2绿宝石点§r§2Emerald-III green_ui 9
scoreboard players set §2绿宝石点§r§2Emerald-III yellow_ui 9
tellraw @a [{"text":"—","bold":true},{"translate":"resource.diamond","color":"aqua","bold":false},{"text":" "},{"translate":"warn.update.to","bold":false},{"text":" "},{"text":"Tier-III","bold":false,"color":"yellow"}]
function time:5min/60s