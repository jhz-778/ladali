scoreboard players set #diamond_tier tick 2
scoreboard players reset §b钻石点§r§bDiamond-II
scoreboard players set §2绿宝石点§r§2Emerald-II spectator_ui 8
scoreboard players set §2绿宝石点§r§2Emerald-II red_ui 9
scoreboard players set §2绿宝石点§r§2Emerald-II blue_ui 9
scoreboard players set §2绿宝石点§r§2Emerald-II green_ui 9
scoreboard players set §2绿宝石点§r§2Emerald-II yellow_ui 9
tellraw @a [{"text":"—","bold":true},{"translate":"resource.diamond","color":"aqua","bold":false},{"text":" "},{"translate":"warn.update.to","bold":false},{"text":" "},{"text":"Tier-II","bold":false,"color":"yellow"}]
function time:4min/30s