tag @a[nbt={HurtTime:10s},limit=1] add arrowdm
execute as @a[tag=arrowdm] store result score #arrowdm math run data get entity @s Health 10
execute as @a[tag=arrowdm] store result score #arrowdm number run data get entity @s AbsorptionAmount 10
scoreboard players operation #arrowdm math += #arrowdm number
scoreboard players operation #arrowdm number = #arrowdm math
scoreboard players operation #arrowdm math /= #math10 math
scoreboard players operation #arrowdm number %= #math10 math
tellraw @s [{"selector":"@a[tag=arrowdm]"},{"translate":"warn.arrow.damage","color":"white"},{"score":{"name":"#arrowdm","objective":"math"},"color":"red"},{"text":".","color":"red"},{"score":{"name":"#arrowdm","objective":"number"},"color":"red"},{"text":"❤","color":"red"}]
tag @a remove arrowdm
advancement revoke @s only bedwars:game/bows
advancement revoke @s only bedwars:game/firework
advancement revoke @s only bedwars:game/trident