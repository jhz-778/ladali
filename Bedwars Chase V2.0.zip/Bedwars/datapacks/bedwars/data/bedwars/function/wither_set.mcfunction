ride @s mount @e[type=minecraft:text_display,limit=1,tag=wither]
tag @s add wither
execute if data storage minecraft:bedwars {combat:0b} run data modify entity @s attributes set from storage minecraft:detail wither_default.attributes
execute if data storage minecraft:bedwars {combat:1b} run data modify entity @s attributes set from storage minecraft:detail wither_faster.attributes
attribute @s minecraft:follow_range base set 16
data merge entity @s {ArmorDropChances:[0.0f,0.0f,0.0f,0.0f]}
item replace entity @s armor.head with minecraft:iron_ingot[minecraft:enchantments={levels:{"bedwars:phdi":1,"bedwars:mob":1}}]
team join spectator @s