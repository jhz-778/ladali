execute if entity @s[team=red] if data storage minecraft:red {bed:1b} run scoreboard players set @s revive 11
execute if entity @s[team=blue] if data storage minecraft:blue {bed:1b} run scoreboard players set @s revive 11
execute if entity @s[team=green] if data storage minecraft:green {bed:1b} run scoreboard players set @s revive 11
execute if entity @s[team=yellow] if data storage minecraft:yellow {bed:1b} run scoreboard players set @s revive 11
execute if score @s revive matches 1.. run title @s title [{"translate":"warn.title.revive","color":"red"}]
execute if entity @s[team=red] unless data storage minecraft:red {bed:1b} run function bedwars:player_death
execute if entity @s[team=blue] unless data storage minecraft:blue {bed:1b} run function bedwars:player_death
execute if entity @s[team=green] unless data storage minecraft:green {bed:1b} run function bedwars:player_death
execute if entity @s[team=yellow] unless data storage minecraft:yellow {bed:1b} run function bedwars:player_death
execute if entity @s[team=red] run schedule clear bedwars:schedule/red_bed
execute if entity @s[team=blue] run schedule clear bedwars:schedule/blue_bed
execute if entity @s[team=green] run schedule clear bedwars:schedule/green_bed
execute if entity @s[team=yellow] run schedule clear bedwars:schedule/yellow_bed