data modify block 2011 82 2023 front_text.messages[2] set value '{"translate":"setting.random","clickEvent":{"action":"run_command","value":"function bedwars:team_custom"}}'
data merge storage minecraft:bedwars {team:0b}
team empty red
team empty blue
team empty green
team empty yellow
setblock 2011 81 2023 minecraft:air destroy
setblock 2011 81 2022 minecraft:air destroy
setblock 2011 81 2020 minecraft:air destroy
setblock 2011 81 2019 minecraft:air destroy
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1