$execute anchored eyes positioned ^ ^ ^ run summon minecraft:arrow ^ ^ ^ {Motion:$(Motion),Tags:["fishm"]}
execute as @e[type=minecraft:arrow,tag=fishm] at @s run function bedwars:fishing