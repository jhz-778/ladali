function explode:_explsion
execute if data storage minecraft:bedwars {mode:2b} run function mode:ocean/tick
execute if data storage minecraft:bedwars {mode:3b} run function mode:super_chase/tick
execute if data storage minecraft:bedwars {Special:{exper:1b}} as @a[scores={throw=1..}] at @s run data modify entity @n[type=minecraft:item,nbt={Age:0s,Item:{components:{"minecraft:custom_data":{resource:2b}}}}] Item.components."minecraft:custom_data".resource set value 3b
execute as @a[scores={tip=1..}] at @s run function bedwars:wood_chest
execute as @a[scores={golem=1..}] at @s run function bedwars:iron_golem
execute if score #store_elytra tick matches 0 as @a[team=!spectator,gamemode=!spectator,nbt=!{active_effects:[{id:"minecraft:invisibility"}]}] unless items entity @s armor.chest * at @s run function bedwars:elytra
execute if score #store_fireball tick matches 0 as @e[type=minecraft:fireball,tag=!fired] run function bedwars:fireballing
execute if score #store_back_pearl tick matches 0 as @e[type=minecraft:armor_stand,tag=backpearl] run function bedwars:pearl/backing
execute if score #store_move_pearl tick matches 0 as @e[type=minecraft:snowball,tag=movepearl] unless predicate bedwars:player run kill @s
execute if score #store_potion_invisible tick matches 0 as @a[nbt={active_effects:[{id:"minecraft:invisibility",duration:1}]}] run function bedwars:potion/clear
execute if score #store_burst_mushroom tick matches 0 as @a[nbt={active_effects:[{id:"minecraft:raid_omen",duration:1}]}] run function bedwars:potion/burst
execute if score #store_growth_mushroom tick matches 0 as @a[nbt={active_effects:[{id:"minecraft:luck",duration:1}]}] run function bedwars:potion/growth
execute as @a[scores={firework=1..}] at @s run function bedwars:firework
execute as @a[scores={block=1..}] run function bedwars:blocking
execute if data storage minecraft:bedwars {rain:1b} run function bedwars:_rain
execute if data storage minecraft:bedwars {dragon:1b} run function bedwars:dragon
function bedwars:beds
function bedwars:_title
execute unless data storage minecraft:bedwars {mode:2b} run title @a[team=!spectator] actionbar [{"translate":"title.kill"},{"text":":"},{"score":{"name":"*","objective":"kill"},"color":"red"},{"text":"   "},{"translate":"title.last.kill"},{"text":":"},{"score":{"name":"*","objective":"last_kill"},"color":"red"},{"text":"   "},{"translate":"title.bed"},{"text":":"},{"score":{"name":"*","objective":"bed"},"color":"red"}]
execute if data storage minecraft:bedwars {mode:2b} run title @a[team=!spectator] actionbar [{"text":"O₂- ","color":"aqua"},{"score":{"name":"*","objective":"o2"}},{"text":"%    "},{"translate":"title.kill","color":"white"},{"text":":","color":"white"},{"score":{"name":"*","objective":"kill"},"color":"red"},{"text":"   "},{"translate":"title.last.kill","color":"white"},{"text":":","color":"white"},{"score":{"name":"*","objective":"last_kill"},"color":"red"},{"text":"   "},{"translate":"title.bed","color":"white"},{"text":":","color":"white"},{"score":{"name":"*","objective":"bed"},"color":"red"},{"text":"     "},{"text":"O₂- "},{"score":{"name":"*","objective":"o2"}},{"text":"%"}]
title @a[team=spectator] actionbar [{"translate":"title.next.event"},{"text":":"},{"score":{"name":"#minute","objective":"number"},"color":"red"},{"text":"min"},{"score":{"name":"#second","objective":"number"},"color":"red"},{"text":"s"},{"text":"   "},{"translate":"game.time"},{"text":":"},{"score":{"name":"#minute","objective":"tick"},"color":"aqua"},{"text":"min"},{"score":{"name":"#second","objective":"tick"},"color":"aqua"},{"text":"s"}]
execute as @e[type=minecraft:text_display,tag=wither] if predicate bedwars:wither at @s run function bedwars:wither
execute as @e[type=minecraft:armor_stand,tag=diamond] at @s run tp @s ~ ~ ~ ~5 ~
execute as @e[type=minecraft:armor_stand,tag=emerald] at @s run tp @s ~ ~ ~ ~-5 ~
execute as @a if score @s death matches 1.. run function bedwars:_death
scoreboard players set @a[scores={slay=1..}] slay 0
execute as @a[scores={drop=1..}] run function bedwars:track/drop
scoreboard players remove @a[scores={trap=1..}] trap 1
scoreboard players add @e[type=minecraft:egg] egg 1
kill @e[type=minecraft:egg,scores={egg=30..}]
tag @e[type=minecraft:firework_rocket,tag=!firework] add firework
kill @e[type=minecraft:arrow,nbt={inGround:1b}]
kill @e[type=minecraft:spectral_arrow,nbt={inGround:1b}]
kill @e[type=minecraft:experience_orb]
execute if score #store_platform tick matches 0 as @e[type=minecraft:marker,tag=platform] at @s run function bedwars:platform_ing
execute if score #store_tnt_minecart tick matches 0 as @e[type=minecraft:item_display,tag=tntminecart] unless predicate bedwars:ride at @s run function explode:explode
execute unless data storage minecraft:detail {trap:1b} run function bedwars:trap/trap_homeless
execute if data storage minecraft:detail {trap:1b} run function bedwars:trap/trap_normal
execute if score #red_trap trap matches 1.. run function bedwars:trap/traping_red
execute if score #blue_trap trap matches 1.. run function bedwars:trap/traping_blue
execute if score #green_trap trap matches 1.. run function bedwars:trap/traping_green
execute if score #yellow_trap trap matches 1.. run function bedwars:trap/traping_yellow