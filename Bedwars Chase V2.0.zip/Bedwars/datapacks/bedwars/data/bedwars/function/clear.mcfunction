tag @s remove quicky_empty
tag @s add quickytest
execute as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[limit=1,tag=quickytest] uid if data entity @s {data:{Quicky:{Slot0:"function bedwars:_none",Slot1:"function bedwars:_none",Slot2:"function bedwars:_none",Slot3:"function bedwars:_none",Slot4:"function bedwars:_none",Slot5:"function bedwars:_none",Slot6:"function bedwars:_none",Slot7:"function bedwars:_none",Slot8:"function bedwars:_none",Slot9:"function bedwars:_none",Slot10:"function bedwars:_none",Slot11:"function bedwars:_none",Slot12:"function bedwars:_none",Slot13:"function bedwars:_none",Slot14:"function bedwars:_none",Slot15:"function bedwars:_none",Slot16:"function bedwars:_none",Slot17:"function bedwars:_none"}}} run tag @a[limit=1,tag=quickytest] add quicky_empty
tag @s remove quickytest
clear @s
effect clear @s
execute if data storage minecraft:bedwars {mode:2b} run scoreboard players set @s o2 100
execute if data storage minecraft:bedwars {mode:2b} run scoreboard players set @s unbreath 0
loot replace entity @s armor.head loot bedwars:helmet
loot replace entity @s armor.chest loot bedwars:chestplate
loot replace entity @s armor.legs loot bedwars:leggings
loot replace entity @s armor.feet loot bedwars:boots
function bedwars:player_attribute
execute if score @s armor matches 1 run loot replace entity @s armor.legs loot gui:store/chainmail_leggings
execute if score @s armor matches 1 run loot replace entity @s armor.feet loot gui:store/chainmail_boots
execute if score @s armor matches 2 run loot replace entity @s armor.legs loot gui:store/iron_leggings
execute if score @s armor matches 2 run loot replace entity @s armor.feet loot gui:store/iron_boots
execute if score @s armor matches 3 run loot replace entity @s armor.legs loot gui:store/diamond_leggings
execute if score @s armor matches 3 run loot replace entity @s armor.feet loot gui:store/diamond_boots
execute if score @s armor matches 4.. run loot replace entity @s armor.legs loot gui:store/netherite_leggings
execute if score @s armor matches 4.. run loot replace entity @s armor.feet loot gui:store/netherite_boots
loot replace entity @s container.0 loot bedwars:wooden_sword
loot replace entity @s container.8 loot bedwars:compass