scoreboard players operation @s hid = @e[type=minecraft:fishing_bobber,tag=fishing,sort=nearest,limit=1] uid
execute unless score @s uid = @s hid run function bedwars:hurted
advancement revoke @s only bedwars:game/furt