execute if entity @e[type=minecraft:experience_bottle,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[14.0f]}}}},sort=nearest,limit=1] at @s run function bedwars:dart
execute if entity @e[type=minecraft:experience_bottle,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[10.0f]}}}},sort=nearest,limit=1] at @s run function bedwars:ice
execute if entity @e[type=minecraft:experience_bottle,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[11.0f]}}}},sort=nearest,limit=1] at @s run function bedwars:minecart
execute if entity @e[type=minecraft:experience_bottle,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[12.0f]}}}},sort=nearest,limit=1] at @s run function bedwars:platform
execute if entity @e[type=minecraft:experience_bottle,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[21.0f]}}}},sort=nearest,limit=1] at @s run function mode:ocean/magma_block
execute if entity @e[type=minecraft:experience_bottle,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[22.0f]}}}},sort=nearest,limit=1] at @s run function mode:ocean/soul_sand
scoreboard players set @s exp 0