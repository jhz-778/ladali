clear @s
effect clear @s
scoreboard players set @s quit 0
function bedwars:player_attribute