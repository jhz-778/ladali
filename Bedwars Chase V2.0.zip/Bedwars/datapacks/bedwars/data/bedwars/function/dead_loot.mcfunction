execute store result score @s dummy run clear @s minecraft:nether_star
execute store result score @s number run clear @s minecraft:emerald
execute store result score @s custom run clear @s minecraft:diamond
execute store result score @s amount run clear @s minecraft:gold_ingot
execute store result score @s count run clear @s minecraft:iron_ingot
execute at @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_data":{player:1b}}}}] run loot spawn ~ ~ ~ loot bedwars:loot