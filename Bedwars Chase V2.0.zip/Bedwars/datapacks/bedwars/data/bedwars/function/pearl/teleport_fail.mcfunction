tag @s add tped
tag @s add tpfail
playsound minecraft:block.anvil.place block @s ~ ~ ~ 1 1.5
tellraw @s [{"translate":"warn.tpearl.fail","color":"yellow"}]
execute if predicate bedwars:empty run tag @s add mainhand_empty
execute if entity @s[tag=!mainhand_empty] run loot give @s loot gui:store/tp_pearl
execute if entity @s[tag=mainhand_empty] run loot replace entity @s weapon.mainhand loot gui:store/tp_pearl
tag @s remove mainhand_empty