execute store result score @s tip run data get entity @s Pos[1]
tag @s[scores={tip=60..105}] add backing
execute as @a if score @s uid = @e[type=minecraft:armor_stand,tag=backing,limit=1] uid at @s run function bedwars:pearl/storing
tag @s remove backing