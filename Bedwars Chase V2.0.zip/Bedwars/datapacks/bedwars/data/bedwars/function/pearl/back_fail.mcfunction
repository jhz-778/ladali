kill @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[7.0f]}}}},sort=nearest,limit=1,tag=!snowball]
playsound minecraft:block.anvil.place block @s ~ ~ ~ 1 1.5
tellraw @s [{"translate":"warn.backcd.up","color":"red"},{"score":{"name":"@s","objective":"backcd"},"color":"yellow"},{"text":"s","color":"yellow"},{"translate":"warn.backcd.down"}]
execute if predicate bedwars:empty run tag @s add mainhand_empty
execute if entity @s[tag=!mainhand_empty] run loot give @s loot gui:store/back_pearl
execute if entity @s[tag=mainhand_empty] run loot replace entity @s weapon.mainhand loot gui:store/back_pearl
tag @s remove mainhand_empty