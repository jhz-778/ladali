execute if score @s backcd matches 1.. run function bedwars:pearl/back_fail
execute unless score @s backcd matches 1.. run function bedwars:pearl/back_pass