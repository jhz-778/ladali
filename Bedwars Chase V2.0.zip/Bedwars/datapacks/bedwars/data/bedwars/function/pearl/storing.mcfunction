summon minecraft:armor_stand ~ ~ ~ {Marker:1b,Invisible:1b,Tags:["marker","backpearl"]}
scoreboard players operation @e[type=minecraft:armor_stand,limit=1,sort=nearest,tag=marker] uid = @s uid
tag @e[type=minecraft:armor_stand] remove marker