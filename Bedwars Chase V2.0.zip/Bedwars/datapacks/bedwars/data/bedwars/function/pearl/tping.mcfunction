execute store result score @s u0 run data get entity @s Pos[0]
execute store result score @s u1 run data get entity @s Pos[1]
execute store result score @s u2 run data get entity @s Pos[2]
execute if data storage minecraft:bedwars {mode:1b} run tag @s[scores={u1=64..112}] add tping
execute unless data storage minecraft:bedwars {mode:1b} run tag @s[scores={u0=-98..98,u1=64..112,u2=-98..98}] add tping
execute unless data storage minecraft:bedwars {mode:1b} unless entity @s[scores={u0=-98..98}] at @s unless block ~ ~-1 ~ minecraft:air run tag @s add tping
execute unless data storage minecraft:bedwars {mode:1b} unless entity @s[scores={u2=-98..98}] at @s unless block ~ ~-1 ~ minecraft:air run tag @s add tping
execute unless data storage minecraft:bedwars {mode:1b} unless entity @s[scores={u0=-98..98}] at @s unless block ~ ~-1.5 ~ minecraft:air run tag @s add tping
execute unless data storage minecraft:bedwars {mode:1b} unless entity @s[scores={u2=-98..98}] at @s unless block ~ ~-1.5 ~ minecraft:air run tag @s add tping
execute unless data storage minecraft:bedwars {mode:1b} unless entity @s[scores={u0=-98..98}] at @s unless block ~ ~-2 ~ minecraft:air run tag @s add tping
execute unless data storage minecraft:bedwars {mode:1b} unless entity @s[scores={u2=-98..98}] at @s unless block ~ ~-2 ~ minecraft:air run tag @s add tping
execute as @a if score @s uid = @e[type=minecraft:armor_stand,tag=tping,limit=1] uid run effect give @s minecraft:slow_falling 1 0 true
execute as @a if score @s uid = @e[type=minecraft:armor_stand,tag=tping,limit=1] uid at @e[type=minecraft:armor_stand,limit=1,tag=tping] run tp @s ~ ~-0.2 ~
execute as @a if score @s uid = @e[type=minecraft:armor_stand,tag=tping,limit=1] uid if data storage minecraft:detail {pearl_damage:1b} run damage @s 4 minecraft:fall
execute if entity @s[tag=tping] run playsound minecraft:entity.player.teleport master @a ~ ~ ~ 1 1
tag @s remove tping
kill @s