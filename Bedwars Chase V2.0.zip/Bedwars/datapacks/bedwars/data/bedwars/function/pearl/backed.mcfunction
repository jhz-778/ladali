tag @s add tping
execute as @a if score @s uid = @e[type=minecraft:armor_stand,tag=tping,limit=1] uid run effect give @s minecraft:slow_falling 1 0 true
execute as @a if score @s uid = @e[type=minecraft:armor_stand,tag=tping,limit=1] uid at @e[type=minecraft:armor_stand,limit=1,tag=tping] run tp @s ~ ~ ~
playsound minecraft:entity.player.teleport master @a ~ ~ ~ 1 1
tag @s remove tping
kill @s