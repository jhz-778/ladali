kill @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[9.0f]}}}},sort=nearest,limit=1,tag=!snowball]
execute if score @s tpcd matches 1.. run function bedwars:pearl/teleport_cd
execute unless score @s tpcd matches 1.. anchored eyes run function bedwars:pearl/teleport_pass
execute unless score @s tpcd matches 1.. if entity @s[tag=!tpsuccess,tag=!tpfail] run function bedwars:pearl/teleport_fail
tag @s[tag=tpfail] remove tped
tag @s remove tpfail
tag @s remove tpsuccess