execute if score @s tick matches 60.. at @s run function bedwars:pearl/backed
scoreboard players add @s tick 1