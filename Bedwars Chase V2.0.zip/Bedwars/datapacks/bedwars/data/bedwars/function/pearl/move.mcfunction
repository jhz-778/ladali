execute if data storage minecraft:bedwars {mode:2b} as @e[type=minecraft:snowball,sort=nearest,limit=1,tag=!snowball] store result entity @s Motion[0] double 0.000000075 run data get entity @s Motion[0] 10000000
execute if data storage minecraft:bedwars {mode:2b} as @e[type=minecraft:snowball,sort=nearest,limit=1,tag=!snowball] store result entity @s Motion[1] double 0.000000075 run data get entity @s Motion[1] 10000000
execute if data storage minecraft:bedwars {mode:2b} as @e[type=minecraft:snowball,sort=nearest,limit=1,tag=!snowball] store result entity @s Motion[2] double 0.000000075 run data get entity @s Motion[2] 10000000
ride @s dismount
playsound minecraft:entity.player.teleport master @a ~ ~ ~ 0.75 1
execute if data storage minecraft:detail {pearl_damage:1b} run damage @s 4 minecraft:fall
ride @s mount @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[8.0f]}}}},sort=nearest,limit=1,tag=!snowball]
tag @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[8.0f]}}}},sort=nearest,limit=1,tag=!snowball] add movepearl
tag @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[8.0f]}}}},sort=nearest,limit=1,tag=!snowball] add snowball