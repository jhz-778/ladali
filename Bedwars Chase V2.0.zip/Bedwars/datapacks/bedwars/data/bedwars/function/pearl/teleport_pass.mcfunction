execute unless block ^ ^ ^0.5 #minecraft:airs run tag @s add tped
execute if entity @s[tag=tped] on vehicle run tp @s ^ ^ ^-2
execute if entity @s[tag=tped] unless predicate bedwars:ride run tp @s ~ ~ ~
tag @s[tag=tped] add tpsuccess
effect give @s[tag=tped] minecraft:slow_falling 1 0 true
execute if data storage minecraft:detail {pearl_damage:1b} run damage @s 4 minecraft:fall
scoreboard players set @s[tag=tped] tpcd 6
playsound minecraft:entity.player.teleport master @s[tag=tped] ~ ~ ~ 1 1
execute as @s[distance=64..,tag=!tped] at @s run function bedwars:pearl/teleport_fail
execute as @s[distance=..64,tag=!tped] if block ^ ^ ^0.5 #minecraft:airs positioned ^ ^ ^0.5 run function bedwars:pearl/teleport_pass
tag @s remove tped