execute if data storage minecraft:bedwars {mode:2b} as @e[type=minecraft:snowball,sort=nearest,limit=1,tag=!snowball] store result entity @s Motion[0] double 0.000000075 run data get entity @s Motion[0] 10000000
execute if data storage minecraft:bedwars {mode:2b} as @e[type=minecraft:snowball,sort=nearest,limit=1,tag=!snowball] store result entity @s Motion[1] double 0.000000075 run data get entity @s Motion[1] 10000000
execute if data storage minecraft:bedwars {mode:2b} as @e[type=minecraft:snowball,sort=nearest,limit=1,tag=!snowball] store result entity @s Motion[2] double 0.000000075 run data get entity @s Motion[2] 10000000
summon minecraft:armor_stand ~ ~ ~ {Marker:1b,Invisible:1b,Tags:["marker","pearl","pearl_ender","tick_ride"]}
ride @e[type=minecraft:armor_stand,limit=1,sort=nearest,tag=marker] mount @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[6.0f]}}}},sort=nearest,limit=1,tag=!snowball]
scoreboard players operation @e[type=minecraft:armor_stand,limit=1,sort=nearest,tag=marker] uid = @s uid
tag @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[6.0f]}}}},sort=nearest,limit=1,tag=!snowball] add pearl
tag @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[6.0f]}}}},sort=nearest,limit=1,tag=!snowball] add snowball
tag @e[type=minecraft:armor_stand] remove marker