execute store result score #dset tick run data get storage minecraft:detail wither_faster.attributes[0].base
execute unless data storage minecraft:bedwars {settings:1b} run scoreboard players add #dset tick 25
execute if score #dset tick matches 301.. run scoreboard players set #dset tick 0
execute store result storage minecraft:detail wither_faster.attributes[0].base float 1 run scoreboard players get #dset tick
data modify block 2011 81 2011 front_text.messages[2] set value '[{"clickEvent":{"action":"run_command","value":"function bedwars:detail/wither_faster"},"score":{"name":"#dset","objective":"tick"}},{"text":"❤"}]'
execute if score #dset tick matches 0 run data modify block 2011 81 2011 front_text.messages[2] set value '{"clickEvent":{"action":"run_command","value":"function bedwars:detail/wither_faster"},"translate":"setting.disenable"}'
execute unless data storage minecraft:bedwars {settings:1b} run playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1