data modify block 2011 82 2012 front_text.messages[2] set value '{"clickEvent":{"action":"run_command","value":"function bedwars:detail/satiety_off"},"translate":"setting.enable"}'
data merge storage minecraft:detail {satiety:1b}
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1