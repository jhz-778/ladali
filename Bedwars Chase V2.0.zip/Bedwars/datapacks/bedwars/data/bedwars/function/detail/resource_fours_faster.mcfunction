data modify block 2011 82 2017 front_text.messages[2] set value '{"clickEvent":{"action":"run_command","value":"function bedwars:detail/resource_fours_slowly"},"translate":"setting.faster"}'
data merge storage minecraft:detail {resource_fours:2b}
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1