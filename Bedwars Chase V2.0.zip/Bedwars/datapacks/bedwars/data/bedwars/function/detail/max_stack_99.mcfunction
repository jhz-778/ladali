data modify block 2011 82 2016 front_text.messages[2] set value '{"clickEvent":{"action":"run_command","value":"function bedwars:detail/max_stack_64"},"translate":"99"}'
data merge storage minecraft:detail {max_stack:99}
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1