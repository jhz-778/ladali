data modify block 2011 81 2015 front_text.messages[2] set value '{"clickEvent":{"action":"run_command","value":"function bedwars:detail/tool_update"},"translate":"setting.tool.buy"}'
data merge storage minecraft:detail {tool:0b}
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1