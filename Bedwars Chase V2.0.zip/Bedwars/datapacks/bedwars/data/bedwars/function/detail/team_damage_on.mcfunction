data modify block 2011 81 2014 front_text.messages[2] set value '{"clickEvent":{"action":"run_command","value":"function bedwars:detail/team_damage_off"},"translate":"setting.enable"}'
data merge storage minecraft:detail {team_damage:1b}
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1
team modify red friendlyFire true
team modify blue friendlyFire true
team modify green friendlyFire true
team modify yellow friendlyFire true