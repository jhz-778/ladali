data modify block 2011 82 2014 front_text.messages[2] set value '{"clickEvent":{"action":"run_command","value":"function bedwars:detail/pearl_off"},"translate":"setting.enable"}'
data merge storage minecraft:detail {pearl_damage:1b}
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1