data modify block 2011 81 2013 front_text.messages[2] set value '{"clickEvent":{"action":"run_command","value":"function bedwars:detail/rain_on"},"translate":"setting.disenable"}'
data merge storage minecraft:detail {rain_plan:0b}
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1