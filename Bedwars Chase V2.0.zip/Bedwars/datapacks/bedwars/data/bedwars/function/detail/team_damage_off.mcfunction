data modify block 2011 81 2014 front_text.messages[2] set value '{"clickEvent":{"action":"run_command","value":"function bedwars:detail/team_damage_on"},"translate":"setting.disenable"}'
data merge storage minecraft:detail {team_damage:0b}
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1
team modify red friendlyFire false
team modify blue friendlyFire false
team modify green friendlyFire false
team modify yellow friendlyFire false