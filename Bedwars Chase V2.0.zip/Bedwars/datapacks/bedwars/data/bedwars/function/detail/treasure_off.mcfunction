data modify block 2011 82 2013 front_text.messages[2] set value '{"clickEvent":{"action":"run_command","value":"function bedwars:detail/treasure_on"},"translate":"setting.disenable","color":"gold"}'
data merge storage minecraft:detail {treasure:0b}
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1