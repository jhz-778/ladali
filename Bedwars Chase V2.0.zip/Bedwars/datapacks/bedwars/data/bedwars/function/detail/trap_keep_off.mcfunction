data modify block 2011 81 2016 front_text.messages[2] set value '{"clickEvent":{"action":"run_command","value":"function bedwars:detail/trap_keep_on"},"translate":"setting.disenable"}'
data merge storage minecraft:detail {trap:0b}
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1