data modify block 2011 81 2016 front_text.messages[2] set value '{"clickEvent":{"action":"run_command","value":"function bedwars:detail/trap_keep_off"},"translate":"setting.enable"}'
data merge storage minecraft:detail {trap:1b}
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1