data modify block 2011 81 2017 front_text.messages[2] set value '{"clickEvent":{"action":"run_command","value":"function bedwars:detail/resource_double_medium"},"translate":"setting.slowly"}'
data merge storage minecraft:detail {resource_double:0b}
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1