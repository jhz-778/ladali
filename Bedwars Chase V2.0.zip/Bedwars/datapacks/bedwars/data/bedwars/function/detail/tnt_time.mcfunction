execute store result score #tt tick run data get storage minecraft:detail tnt_time
scoreboard players add #tt tick 10
execute if score #tt tick matches 101.. run scoreboard players set #tt tick 0
execute store result storage minecraft:detail tnt_time float 1 run scoreboard players get #tt tick
data modify block 2011 82 2015 front_text.messages[2] set value '[{"clickEvent":{"action":"run_command","value":"function bedwars:detail/tnt_time"},"color":"dark_red","score":{"name":"#tt","objective":"tick"}},{"text":"t","color":"dark_red"}]'
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1