data modify block 2011 81 2015 front_text.messages[2] set value '{"clickEvent":{"action":"run_command","value":"function bedwars:detail/tool_buy"},"translate":"setting.tool.update"}'
data merge storage minecraft:detail {tool:1b}
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1