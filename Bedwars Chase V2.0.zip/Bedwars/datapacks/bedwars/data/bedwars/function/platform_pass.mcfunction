execute if score @s platcd matches 1.. run function bedwars:platform_cd
execute unless score @s platcd matches 1.. run function bedwars:platform_fill