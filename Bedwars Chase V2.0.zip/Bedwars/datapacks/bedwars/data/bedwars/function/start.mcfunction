data merge storage minecraft:bedwars {pass:0b}
execute store result score #test tick if entity @a[team=!spectator]
execute if score #test tick matches 2.. run data merge storage minecraft:bedwars {pass:1b}
execute if data storage minecraft:bedwars {team:1b} run function bedwars:start_test
execute if data storage minecraft:bedwars {pass:1b} run function bedwars:_start
execute if data storage minecraft:bedwars {pass:0b} run function bedwars:start_fail