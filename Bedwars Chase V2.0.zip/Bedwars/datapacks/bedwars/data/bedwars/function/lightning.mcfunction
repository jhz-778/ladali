execute store result entity @s Pos[0] double 1 run random value -100..100
execute store result entity @s Pos[2] double 1 run random value -100..100
execute at @s run summon minecraft:lightning_bolt ~ ~ ~
kill @s