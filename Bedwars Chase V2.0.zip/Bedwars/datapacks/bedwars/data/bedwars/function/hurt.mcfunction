execute if data entity @s {active_effects:[{id:"minecraft:invisibility"}]} run function bedwars:potion/restore
scoreboard players reset @s hid