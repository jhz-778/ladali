tag @s add blocking
scoreboard players set @s block 2
advancement revoke @s only bedwars:game/block