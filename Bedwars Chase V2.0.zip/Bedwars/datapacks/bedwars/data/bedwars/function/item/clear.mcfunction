execute if data storage minecraft:detail {tool:1b} run function bedwars:item/clear_tool
execute unless score @s shears matches 1.. run clear @s minecraft:shears[!minecraft:custom_data={gui:1b}]
execute unless score @s spyglass matches 1.. run clear @s minecraft:spyglass[!minecraft:custom_data={gui:1b}]
advancement revoke @s only bedwars:game/clear