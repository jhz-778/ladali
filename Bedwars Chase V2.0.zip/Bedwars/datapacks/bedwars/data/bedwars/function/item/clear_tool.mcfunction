#镐
execute unless score @s pickaxe matches 1 run clear @s minecraft:wooden_pickaxe[!minecraft:custom_data={gui:1b}]
execute unless score @s pickaxe matches 2 run clear @s minecraft:iron_pickaxe[!minecraft:custom_data={gui:1b}]
execute unless score @s pickaxe matches 3 run clear @s minecraft:golden_pickaxe[!minecraft:custom_data={gui:1b}]
execute unless score @s pickaxe matches 4 run clear @s minecraft:diamond_pickaxe[!minecraft:custom_data={gui:1b}]
execute unless score @s pickaxe matches 5 run clear @s minecraft:netherite_pickaxe[!minecraft:custom_data={gui:1b}]
#斧
execute unless score @s axe matches 1 run clear @s minecraft:wooden_axe[!minecraft:custom_data={gui:1b}]
execute unless score @s axe matches 2 run clear @s minecraft:stone_axe[!minecraft:custom_data={gui:1b}]
execute unless score @s axe matches 3 run clear @s minecraft:iron_axe[!minecraft:custom_data={gui:1b}]
execute unless score @s axe matches 4 run clear @s minecraft:diamond_axe[!minecraft:custom_data={gui:1b}]
execute unless score @s axe matches 5 run clear @s minecraft:netherite_axe[!minecraft:custom_data={gui:1b}]
#锹
execute unless score @s shovel matches 1 run clear @s minecraft:wooden_shovel[!minecraft:custom_data={gui:1b}]
execute unless score @s shovel matches 2 run clear @s minecraft:stone_shovel[!minecraft:custom_data={gui:1b}]
execute unless score @s shovel matches 3 run clear @s minecraft:iron_shovel[!minecraft:custom_data={gui:1b}]
execute unless score @s shovel matches 4 run clear @s minecraft:diamond_shovel[!minecraft:custom_data={gui:1b}]
execute unless score @s shovel matches 5 run clear @s minecraft:netherite_shovel[!minecraft:custom_data={gui:1b}]