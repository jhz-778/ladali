execute if score @s pickaxe matches 1.. store result score @s number run clear @s #minecraft:pickaxes 0
execute if score @s pickaxe matches 1.. if score @s number matches 0 run loot give @s loot bedwars:pickaxe_update
execute if score @s axe matches 1.. store result score @s number run clear @s #minecraft:axes 0
execute if score @s axe matches 1.. if score @s number matches 0 run loot give @s loot bedwars:axe_update
execute if score @s shovel matches 1.. store result score @s number run clear @s #minecraft:shovels 0
execute if score @s shovel matches 1.. if score @s number matches 0 run loot give @s loot bedwars:shovel_update