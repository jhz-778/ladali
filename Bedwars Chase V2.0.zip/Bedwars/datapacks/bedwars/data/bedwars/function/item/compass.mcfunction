execute store result score @s number run clear @s minecraft:compass 0
execute unless score @s number matches 1.. run loot give @s loot bedwars:compass