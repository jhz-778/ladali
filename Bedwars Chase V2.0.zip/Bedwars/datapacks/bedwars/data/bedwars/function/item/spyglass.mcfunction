execute store result score @s number run clear @s minecraft:spyglass 0
execute unless score @s number matches 1.. run loot give @s loot gui:store/spyglass