execute store result score @s number run clear @s minecraft:wooden_sword 0
execute if score @s number matches 0 store result score @s number run clear @s minecraft:wooden_hoe 0
execute unless score @s number matches 1.. run loot give @s loot bedwars:wooden_sword