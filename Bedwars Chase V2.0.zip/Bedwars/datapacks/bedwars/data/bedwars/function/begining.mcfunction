setblock 2018 81 2034 minecraft:air replace
worldborder center 0.5 0.5
worldborder set 201
worldborder damage amount 1
execute if data storage minecraft:bedwars {mode:1b} run function mode:chase/start
execute if data storage minecraft:bedwars {mode:3b} run function mode:chase/start
execute if data storage minecraft:bedwars {mode:2b} run function mode:ocean/start
function bedwars:reset
execute unless data storage minecraft:bedwars {mode:1b} unless data storage minecraft:bedwars {mode:3b} if data storage minecraft:bedwars {team:0b,teams:0b} run function team:random_first
execute unless data storage minecraft:bedwars {mode:1b} unless data storage minecraft:bedwars {mode:3b} if data storage minecraft:bedwars {team:0b,teams:1b} run function team:random_first_double
execute if data storage minecraft:bedwars {team:0b,mode:1b} run function team:random_first_double
execute if data storage minecraft:bedwars {team:0b,mode:3b} run function team:random_first_double
scoreboard players set @a[team=red] compass 1
scoreboard players set @a[team=blue] compass 2
scoreboard players set @a[team=green] compass 3
scoreboard players set @a[team=yellow] compass 4
execute as @a run function bedwars:clear
function team:_ui
execute unless entity @a[team=red] run data merge storage minecraft:red {bed:0b}
execute unless entity @a[team=blue] run data merge storage minecraft:blue {bed:0b}
execute unless entity @a[team=green] run data merge storage minecraft:green {bed:0b}
execute unless entity @a[team=yellow] run data merge storage minecraft:yellow {bed:0b}
function bedwars:_list
execute if data storage minecraft:bedwars {team:1b} run team join spectator @a[team=!red,team=!blue,team=!green,team=!yellow,team=!spectator]
gamemode adventure @a
gamemode spectator @a[team=spectator]
tp @a[team=spectator] 0 112 0
setworldspawn 0 112 0
spawnpoint @a 0 112 0
execute if data storage minecraft:bedwars {mode:0b} run function mode:help
execute if data storage minecraft:bedwars {mode:1b} run function mode:chase/help
execute if data storage minecraft:bedwars {mode:2b} run function mode:ocean/help
execute if data storage minecraft:bedwars {mode:3b} run function mode:super_chase/help
execute if data storage minecraft:bedwars {mode:4b} run function mode:exper/help
function map:_start
teleport @a[team=red] @e[type=minecraft:marker,tag=team_red,limit=1]
teleport @a[team=blue] @e[type=minecraft:marker,tag=team_blue,limit=1]
teleport @a[team=green] @e[type=minecraft:marker,tag=team_green,limit=1]
teleport @a[team=yellow] @e[type=minecraft:marker,tag=team_yellow,limit=1]
function bedwars:schedule/healing
execute if score #store_ice tick matches 0 run function bedwars:schedule/ice
kill @e[type=minecraft:item]