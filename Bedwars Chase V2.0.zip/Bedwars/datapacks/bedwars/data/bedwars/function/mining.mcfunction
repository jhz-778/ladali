scoreboard players operation @s[team=red] math = #red_mining tick
scoreboard players operation @s[team=blue] math = #blue_mining tick
scoreboard players operation @s[team=green] math = #green_mining tick
scoreboard players operation @s[team=yellow] math = #yellow_mining tick
execute if score @s math matches 1 run effect give @s minecraft:haste 2 0 true
execute if score @s math matches 2 run effect give @s minecraft:haste 2 1 true
execute if score @s math matches 3 run effect give @s minecraft:haste 2 2 true
execute if score @s math matches 4 run effect give @s minecraft:haste 2 3 true