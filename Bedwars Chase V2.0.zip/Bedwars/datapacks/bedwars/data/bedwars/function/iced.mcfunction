execute as @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_data":{ice:1b}}}}] at @s run fill ~ ~ ~ ~ ~ ~ minecraft:air replace minecraft:water
kill @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_data":{ice:1b}}}}]
scoreboard players reset @s ice