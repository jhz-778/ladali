tp @s[team=red] @e[type=minecraft:marker,limit=1,tag=team_red]
tp @s[team=blue] @e[type=minecraft:marker,limit=1,tag=team_blue]
tp @s[team=green] @e[type=minecraft:marker,limit=1,tag=team_green]
tp @s[team=yellow] @e[type=minecraft:marker,limit=1,tag=team_yellow]
execute at @s run playsound minecraft:entity.player.teleport master @s