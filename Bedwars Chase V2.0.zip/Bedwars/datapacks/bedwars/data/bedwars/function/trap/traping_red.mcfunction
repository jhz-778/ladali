execute as @a[team=red] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.5
scoreboard players remove #red_trap trap 1