execute as @a[team=yellow] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.5
scoreboard players remove #yellow_trap trap 1