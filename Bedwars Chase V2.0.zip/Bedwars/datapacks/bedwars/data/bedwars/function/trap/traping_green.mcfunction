execute as @a[team=green] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.5
scoreboard players remove #green_trap trap 1