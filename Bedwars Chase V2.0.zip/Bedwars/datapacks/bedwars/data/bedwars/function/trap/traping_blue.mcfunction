execute as @a[team=blue] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.5
scoreboard players remove #blue_trap trap 1