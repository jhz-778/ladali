scoreboard players set #red_trap trap 45
title @a[team=red] times 10 30 5
execute if score #red_trap_slow tick matches 1 run title @a[team=red] title [{"translate":"effect.minecraft.blindness","color":"red"},{"translate":"gui.trap"}]
execute if score #red_trap_slow tick matches 1 run effect give @a[distance=..15,team=!red,limit=1,scores={trap=0},nbt=!{active_effects:[{id:"minecraft:unluck"}]}] minecraft:blindness 5 0 true
execute if score #red_trap_mining tick matches 1 run title @a[team=red] title [{"translate":"effect.minecraft.mining_fatigue","color":"red"},{"translate":"gui.trap"}]
execute if score #red_trap_mining tick matches 1 run effect give @a[distance=..15,team=!red,limit=1,scores={trap=0},nbt=!{active_effects:[{id:"minecraft:unluck"}]}] minecraft:mining_fatigue 10 0 true
execute if score #red_trap_speed tick matches 1 run title @a[team=red] title [{"translate":"gui.trap.speed","color":"red"}]
execute if score #red_trap_speed tick matches 1 run effect give @a[distance=..15,team=red] minecraft:speed 5 2 false
execute if score #red_trap_warning tick matches 1 run title @a[team=red] title [{"translate":"gui.trap.warning","color":"red"}]
execute if score #red_trap_warning tick matches 1 run effect give @a[distance=..15,team=!red,limit=1,scores={trap=0},nbt=!{active_effects:[{id:"minecraft:unluck"}]}] minecraft:glowing 10 0 true
execute if score #red_trap_warning tick matches 1 as @a[distance=..15,team=!red,limit=1,scores={trap=0},nbt=!{active_effects:[{id:"minecraft:unluck"}]},nbt={active_effects:[{id:"invisibility"}]}] run effect clear @s minecraft:invisibility
execute if score #red_trap_tp tick matches 1 run title @a[team=red] title [{"translate":"gui.trap.tp","color":"red"}]
execute if score #red_trap_tp tick matches 1 as @a[distance=..15,team=!red,limit=1,scores={trap=0},nbt=!{active_effects:[{id:"minecraft:unluck"}]}] run function bedwars:trap/tp
title @a[team=red] subtitle [{"translate":"gui.trap.subtitle","color":"white"}]
execute if score #red_trap_warning tick matches 1 run title @a[team=red] subtitle [{"selector":"@a[distance=..15,team=!red,limit=1,scores={trap=0},nbt=!{active_effects:[{id:'minecraft:unluck'}]}]"},{"translate":"warn.trap.touch","color":"white"}]
scoreboard players set @a[distance=..15,scores={trap=0},nbt=!{active_effects:[{id:"minecraft:unluck"}]},team=!red,limit=1] trap 200
scoreboard players remove #red_trap tick 1
execute if score #red_trap_slow tick matches 1.. run scoreboard players remove #red_trap_slow tick 1
execute if score #red_trap_mining tick matches 1.. run scoreboard players remove #red_trap_mining tick 1
execute if score #red_trap_speed tick matches 1.. run scoreboard players remove #red_trap_speed tick 1
execute if score #red_trap_warning tick matches 1.. run scoreboard players remove #red_trap_warning tick 1
execute if score #red_trap_tp tick matches 1.. run scoreboard players remove #red_trap_tp tick 1
execute as @a[team=red,scores={gui=100}] run function gui:normal/team_list