scoreboard players set #green_trap trap 45
title @a[team=green] times 10 30 5
execute if score #green_trap_slow tick matches 1 run title @a[team=green] title [{"translate":"effect.minecraft.blindness","color":"red"},{"translate":"gui.trap"}]
execute if score #green_trap_slow tick matches 1 run effect give @a[distance=..15,team=!green,limit=1,scores={trap=0},nbt=!{active_effects:[{id:"minecraft:unluck"}]}] minecraft:blindness 5 0 true
execute if score #green_trap_mining tick matches 1 run title @a[team=green] title [{"translate":"effect.minecraft.mining_fatigue","color":"red"},{"translate":"gui.trap"}]
execute if score #green_trap_mining tick matches 1 run effect give @a[distance=..15,team=!green,limit=1,scores={trap=0},nbt=!{active_effects:[{id:"minecraft:unluck"}]}] minecraft:mining_fatigue 10 0 true
execute if score #green_trap_speed tick matches 1 run title @a[team=green] title [{"translate":"gui.trap.speed","color":"red"}]
execute if score #green_trap_speed tick matches 1 run effect give @a[distance=..15,team=green] minecraft:speed 5 2 false
execute if score #green_trap_warning tick matches 1 run title @a[team=green] title [{"translate":"gui.trap.warning","color":"red"}]
execute if score #green_trap_warning tick matches 1 run effect give @a[distance=..15,team=!green,limit=1,scores={trap=0},nbt=!{active_effects:[{id:"minecraft:unluck"}]}] minecraft:glowing 10 0 true
execute if score #green_trap_warning tick matches 1 as @a[distance=..15,team=!green,limit=1,scores={trap=0},nbt=!{active_effects:[{id:"minecraft:unluck"}]},nbt={active_effects:[{id:"invisibility"}]}] run effect clear @s minecraft:invisibility
execute if score #green_trap_tp tick matches 1 run title @a[team=green] title [{"translate":"gui.trap.tp","color":"red"}]
execute if score #green_trap_tp tick matches 1 as @a[distance=..15,team=!green,limit=1,scores={trap=0},nbt=!{active_effects:[{id:"minecraft:unluck"}]}] run function bedwars:trap/tp
title @a[team=green] subtitle [{"translate":"gui.trap.subtitle","color":"white"}]
execute if score #green_trap_warning tick matches 1 run title @a[team=green] subtitle [{"selector":"@a[distance=..15,team=!green,limit=1,scores={trap=0},nbt=!{active_effects:[{id:'minecraft:unluck'}]}]"},{"translate":"warn.trap.touch","color":"white"}]
scoreboard players set @a[distance=..15,scores={trap=0},nbt=!{active_effects:[{id:"minecraft:unluck"}]},team=!green,limit=1] trap 200
scoreboard players remove #green_trap tick 1
execute if score #green_trap_slow tick matches 1.. run scoreboard players remove #green_trap_slow tick 1
execute if score #green_trap_mining tick matches 1.. run scoreboard players remove #green_trap_mining tick 1
execute if score #green_trap_speed tick matches 1.. run scoreboard players remove #green_trap_speed tick 1
execute if score #green_trap_warning tick matches 1.. run scoreboard players remove #green_trap_warning tick 1
execute if score #green_trap_tp tick matches 1.. run scoreboard players remove #green_trap_tp tick 1
execute as @a[team=green,scores={gui=100}] run function gui:normal/team_list