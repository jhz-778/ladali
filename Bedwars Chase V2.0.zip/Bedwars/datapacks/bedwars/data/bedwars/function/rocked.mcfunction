tag @s add rocking
execute as @a if score @s uid = @e[type=minecraft:armor_stand,tag=rocking,limit=1] uid run tag @s add rocking
execute if entity @s[tag=red] positioned ~ ~-1.5 ~ as @a[distance=..2,team=!red,gamemode=!spectator] run damage @s 0.00001 minecraft:arrow by @a[limit=1,tag=rocking]
execute if entity @s[tag=blue] positioned ~ ~-1.5 ~ as @a[distance=..2,team=!blue,gamemode=!spectator] run damage @s 0.00001 minecraft:arrow by @a[limit=1,tag=rocking]
execute if entity @s[tag=green] positioned ~ ~-1.5 ~ as @a[distance=..2,team=!green,gamemode=!spectator] run damage @s 0.00001 minecraft:arrow by @a[limit=1,tag=rocking]
execute if entity @s[tag=yellow] positioned ~ ~-1.5 ~ as @a[distance=..2,team=!yellow,gamemode=!spectator] run damage @s 0.00001 minecraft:arrow by @a[limit=1,tag=rocking]
particle item{item: "minecraft:clay_ball"} ~ ~ ~ 0 0 0 0.1 5 normal
tag @a remove rocking
kill @s