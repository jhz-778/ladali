effect clear @s minecraft:strength
execute if score #store_potion_strength uid matches 1 run effect give @s minecraft:strength 5 0 false
execute if score #store_potion_strength uid matches 2 run effect give @s minecraft:strength 10 0 false
execute if score #store_potion_strength uid matches 3 run effect give @s minecraft:strength 15 0 false
execute if score #store_potion_strength uid matches 4 run effect give @s minecraft:strength 20 0 false
execute if score #store_potion_strength uid matches 5 run effect give @s minecraft:strength 25 0 false
execute if score #store_potion_strength uid matches 6 run effect give @s minecraft:strength 30 0 false
execute if score #store_potion_strength uid matches 7 run effect give @s minecraft:strength 35 0 false
execute if score #store_potion_strength uid matches 8 run effect give @s minecraft:strength 40 0 false
execute if score #store_potion_strength uid matches 9 run effect give @s minecraft:strength 45 0 false
execute if score #store_potion_strength uid matches 10 run effect give @s minecraft:strength 50 0 false
execute if score #store_potion_strength uid matches 11 run effect give @s minecraft:strength 55 0 false
execute if score #store_potion_strength uid matches 12 run effect give @s minecraft:strength 60 0 false
execute if score #store_potion_strength uid matches 13 run effect give @s minecraft:strength 65 0 false
execute if score #store_potion_strength uid matches 14 run effect give @s minecraft:strength 70 0 false
execute if score #store_potion_strength uid matches 15 run effect give @s minecraft:strength 75 0 false
execute if score #store_potion_strength uid matches 16 run effect give @s minecraft:strength 80 0 false
execute if score #store_potion_strength uid matches 17 run effect give @s minecraft:strength 85 0 false
execute if score #store_potion_strength uid matches 18 run effect give @s minecraft:strength 90 0 false
advancement revoke @s only bedwars:potion/strength