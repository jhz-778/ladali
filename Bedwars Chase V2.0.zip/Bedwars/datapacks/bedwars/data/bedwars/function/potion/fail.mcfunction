function bedwars:potion/clear
scoreboard players set @s hurt 100
advancement revoke @s only bedwars:potion/fail