item replace entity @s armor.chest with minecraft:air
item replace entity @s armor.legs with minecraft:air
item replace entity @s armor.feet with minecraft:air
execute if entity @s[team=red] run scoreboard players operation @s math = #red_protection tick
execute if entity @s[team=blue] run scoreboard players operation @s math = #blue_protection tick
execute if entity @s[team=green] run scoreboard players operation @s math = #green_protection tick
execute if entity @s[team=yellow] run scoreboard players operation @s math = #yellow_protection tick
loot replace entity @s armor.head loot bedwars:invisible