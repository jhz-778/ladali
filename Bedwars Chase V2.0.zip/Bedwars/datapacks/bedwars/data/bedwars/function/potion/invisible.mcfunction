#药效
effect clear @s minecraft:invisibility
execute if score #store_potion_invisible uid matches 1 run effect give @s minecraft:invisibility 5 0 false
execute if score #store_potion_invisible uid matches 2 run effect give @s minecraft:invisibility 10 0 false
execute if score #store_potion_invisible uid matches 3 run effect give @s minecraft:invisibility 15 0 false
execute if score #store_potion_invisible uid matches 4 run effect give @s minecraft:invisibility 20 0 false
execute if score #store_potion_invisible uid matches 5 run effect give @s minecraft:invisibility 25 0 false
execute if score #store_potion_invisible uid matches 6 run effect give @s minecraft:invisibility 30 0 false
execute if score #store_potion_invisible uid matches 7 run effect give @s minecraft:invisibility 35 0 false
execute if score #store_potion_invisible uid matches 8 run effect give @s minecraft:invisibility 40 0 false
execute if score #store_potion_invisible uid matches 9 run effect give @s minecraft:invisibility 45 0 false
execute if score #store_potion_invisible uid matches 10 run effect give @s minecraft:invisibility 50 0 false
execute if score #store_potion_invisible uid matches 11 run effect give @s minecraft:invisibility 55 0 false
execute if score #store_potion_invisible uid matches 12 run effect give @s minecraft:invisibility 60 0 false
execute if score #store_potion_invisible uid matches 13 run effect give @s minecraft:invisibility 65 0 false
execute if score #store_potion_invisible uid matches 14 run effect give @s minecraft:invisibility 70 0 false
execute if score #store_potion_invisible uid matches 15 run effect give @s minecraft:invisibility 75 0 false
execute if score #store_potion_invisible uid matches 16 run effect give @s minecraft:invisibility 80 0 false
execute if score #store_potion_invisible uid matches 17 run effect give @s minecraft:invisibility 85 0 false
execute if score #store_potion_invisible uid matches 18 run effect give @s minecraft:invisibility 90 0 false
#清除
function bedwars:potion/restore
advancement revoke @s only bedwars:potion/invisible