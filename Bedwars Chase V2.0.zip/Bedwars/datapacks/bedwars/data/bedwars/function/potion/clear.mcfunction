loot replace entity @s armor.head loot bedwars:helmet
loot replace entity @s armor.chest loot bedwars:chestplate
loot replace entity @s armor.legs loot bedwars:leggings
loot replace entity @s armor.feet loot bedwars:boots
execute if score @s armor matches 1 run loot replace entity @s armor.legs loot gui:store/chainmail_leggings
execute if score @s armor matches 1 run loot replace entity @s armor.feet loot gui:store/chainmail_boots
execute if score @s armor matches 2 run loot replace entity @s armor.legs loot gui:store/iron_leggings
execute if score @s armor matches 2 run loot replace entity @s armor.feet loot gui:store/iron_boots
execute if score @s armor matches 3 run loot replace entity @s armor.legs loot gui:store/diamond_leggings
execute if score @s armor matches 3 run loot replace entity @s armor.feet loot gui:store/diamond_boots
execute if score @s armor matches 4.. run loot replace entity @s armor.legs loot gui:store/netherite_leggings
execute if score @s armor matches 4.. run loot replace entity @s armor.feet loot gui:store/netherite_boots