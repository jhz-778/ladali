effect clear @s minecraft:water_breathing
execute if score #store_potion_breath uid matches 1 run effect give @s minecraft:water_breathing 5 0 false
execute if score #store_potion_breath uid matches 2 run effect give @s minecraft:water_breathing 10 0 false
execute if score #store_potion_breath uid matches 3 run effect give @s minecraft:water_breathing 15 0 false
execute if score #store_potion_breath uid matches 4 run effect give @s minecraft:water_breathing 20 0 false
execute if score #store_potion_breath uid matches 5 run effect give @s minecraft:water_breathing 25 0 false
execute if score #store_potion_breath uid matches 6 run effect give @s minecraft:water_breathing 30 0 false
execute if score #store_potion_breath uid matches 7 run effect give @s minecraft:water_breathing 35 0 false
execute if score #store_potion_breath uid matches 8 run effect give @s minecraft:water_breathing 40 0 false
execute if score #store_potion_breath uid matches 9 run effect give @s minecraft:water_breathing 45 0 false
execute if score #store_potion_breath uid matches 10 run effect give @s minecraft:water_breathing 50 0 false
execute if score #store_potion_breath uid matches 11 run effect give @s minecraft:water_breathing 55 0 false
execute if score #store_potion_breath uid matches 12 run effect give @s minecraft:water_breathing 60 0 false
execute if score #store_potion_breath uid matches 13 run effect give @s minecraft:water_breathing 65 0 false
execute if score #store_potion_breath uid matches 14 run effect give @s minecraft:water_breathing 70 0 false
execute if score #store_potion_breath uid matches 15 run effect give @s minecraft:water_breathing 75 0 false
execute if score #store_potion_breath uid matches 16 run effect give @s minecraft:water_breathing 80 0 false
execute if score #store_potion_breath uid matches 17 run effect give @s minecraft:water_breathing 85 0 false
execute if score #store_potion_breath uid matches 18 run effect give @s minecraft:water_breathing 90 0 false
advancement revoke @s only bedwars:potion/water_breath