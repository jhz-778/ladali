effect clear @s minecraft:jump_boost
execute if score #store_potion_jump uid matches 1 run effect give @s minecraft:jump_boost 5 4 false
execute if score #store_potion_jump uid matches 2 run effect give @s minecraft:jump_boost 10 4 false
execute if score #store_potion_jump uid matches 3 run effect give @s minecraft:jump_boost 15 4 false
execute if score #store_potion_jump uid matches 4 run effect give @s minecraft:jump_boost 20 4 false
execute if score #store_potion_jump uid matches 5 run effect give @s minecraft:jump_boost 25 4 false
execute if score #store_potion_jump uid matches 6 run effect give @s minecraft:jump_boost 30 4 false
execute if score #store_potion_jump uid matches 7 run effect give @s minecraft:jump_boost 35 4 false
execute if score #store_potion_jump uid matches 8 run effect give @s minecraft:jump_boost 40 4 false
execute if score #store_potion_jump uid matches 9 run effect give @s minecraft:jump_boost 45 4 false
execute if score #store_potion_jump uid matches 10 run effect give @s minecraft:jump_boost 50 4 false
execute if score #store_potion_jump uid matches 11 run effect give @s minecraft:jump_boost 55 4 false
execute if score #store_potion_jump uid matches 12 run effect give @s minecraft:jump_boost 60 4 false
execute if score #store_potion_jump uid matches 13 run effect give @s minecraft:jump_boost 65 4 false
execute if score #store_potion_jump uid matches 14 run effect give @s minecraft:jump_boost 70 4 false
execute if score #store_potion_jump uid matches 15 run effect give @s minecraft:jump_boost 75 4 false
execute if score #store_potion_jump uid matches 16 run effect give @s minecraft:jump_boost 80 4 false
execute if score #store_potion_jump uid matches 17 run effect give @s minecraft:jump_boost 85 4 false
execute if score #store_potion_jump uid matches 18 run effect give @s minecraft:jump_boost 90 4 false
advancement revoke @s only bedwars:potion/jump