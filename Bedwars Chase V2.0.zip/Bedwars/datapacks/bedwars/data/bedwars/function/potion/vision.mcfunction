effect clear @s minecraft:night_vision
execute if score #store_potion_vision uid matches 1 run effect give @s minecraft:night_vision 5 1 false
execute if score #store_potion_vision uid matches 2 run effect give @s minecraft:night_vision 10 1 false
execute if score #store_potion_vision uid matches 3 run effect give @s minecraft:night_vision 15 1 false
execute if score #store_potion_vision uid matches 4 run effect give @s minecraft:night_vision 20 1 false
execute if score #store_potion_vision uid matches 5 run effect give @s minecraft:night_vision 25 1 false
execute if score #store_potion_vision uid matches 6 run effect give @s minecraft:night_vision 30 1 false
execute if score #store_potion_vision uid matches 7 run effect give @s minecraft:night_vision 35 1 false
execute if score #store_potion_vision uid matches 8 run effect give @s minecraft:night_vision 40 1 false
execute if score #store_potion_vision uid matches 9 run effect give @s minecraft:night_vision 45 1 false
execute if score #store_potion_vision uid matches 10 run effect give @s minecraft:night_vision 50 1 false
execute if score #store_potion_vision uid matches 11 run effect give @s minecraft:night_vision 55 1 false
execute if score #store_potion_vision uid matches 12 run effect give @s minecraft:night_vision 60 1 false
execute if score #store_potion_vision uid matches 13 run effect give @s minecraft:night_vision 65 1 false
execute if score #store_potion_vision uid matches 14 run effect give @s minecraft:night_vision 70 1 false
execute if score #store_potion_vision uid matches 15 run effect give @s minecraft:night_vision 75 1 false
execute if score #store_potion_vision uid matches 16 run effect give @s minecraft:night_vision 80 1 false
execute if score #store_potion_vision uid matches 17 run effect give @s minecraft:night_vision 85 1 false
execute if score #store_potion_vision uid matches 18 run effect give @s minecraft:night_vision 90 1 false
advancement revoke @s only bedwars:potion/vision