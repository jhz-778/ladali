effect clear @s minecraft:raid_omen
attribute @s minecraft:attack_damage base set 1
attribute @s minecraft:block_break_speed base set 1
attribute @s minecraft:knockback_resistance base set 0
execute if data entity @s {active_effects:[{id:"minecraft:invisibility"}]} if score @s armor matches 4.. run attribute @s minecraft:knockback_resistance base set 0.2
execute if data storage minecraft:bedwars {combat:0b} run attribute @s minecraft:attack_speed base set 4.0
execute if data storage minecraft:bedwars {combat:1b} run attribute @s minecraft:attack_speed base set 10.0
attribute @s minecraft:movement_speed base set 0.1
execute unless data entity @s {active_effects:[{id:"minecraft:luck"}]} run attribute @s minecraft:entity_interaction_range base set 3
execute if data storage minecraft:bedwars {mode:3b} run function mode:super_chase/attribute