effect clear @s minecraft:speed
execute if score #store_potion_speed uid matches 1 run effect give @s minecraft:speed 5 1 false
execute if score #store_potion_speed uid matches 2 run effect give @s minecraft:speed 10 1 false
execute if score #store_potion_speed uid matches 3 run effect give @s minecraft:speed 15 1 false
execute if score #store_potion_speed uid matches 4 run effect give @s minecraft:speed 20 1 false
execute if score #store_potion_speed uid matches 5 run effect give @s minecraft:speed 25 1 false
execute if score #store_potion_speed uid matches 6 run effect give @s minecraft:speed 30 1 false
execute if score #store_potion_speed uid matches 7 run effect give @s minecraft:speed 35 1 false
execute if score #store_potion_speed uid matches 8 run effect give @s minecraft:speed 40 1 false
execute if score #store_potion_speed uid matches 9 run effect give @s minecraft:speed 45 1 false
execute if score #store_potion_speed uid matches 10 run effect give @s minecraft:speed 50 1 false
execute if score #store_potion_speed uid matches 11 run effect give @s minecraft:speed 55 1 false
execute if score #store_potion_speed uid matches 12 run effect give @s minecraft:speed 60 1 false
execute if score #store_potion_speed uid matches 13 run effect give @s minecraft:speed 65 1 false
execute if score #store_potion_speed uid matches 14 run effect give @s minecraft:speed 70 1 false
execute if score #store_potion_speed uid matches 15 run effect give @s minecraft:speed 75 1 false
execute if score #store_potion_speed uid matches 16 run effect give @s minecraft:speed 80 1 false
execute if score #store_potion_speed uid matches 17 run effect give @s minecraft:speed 85 1 false
execute if score #store_potion_speed uid matches 18 run effect give @s minecraft:speed 90 1 false
advancement revoke @s only bedwars:potion/speed