effect clear @s minecraft:luck
attribute @s minecraft:scale base set 1
attribute @s minecraft:jump_strength base set 0.42
attribute @s minecraft:step_height base set 0.6
attribute @s minecraft:max_health base set 20
attribute @s minecraft:safe_fall_distance base set 3
attribute @s minecraft:block_interaction_range base set 4.5
execute unless data entity @s {active_effects:[{id:"minecraft:raid_omen"}]} run attribute @s minecraft:entity_interaction_range base set 3
execute if data entity @s {active_effects:[{id:"minecraft:raid_omen"}]} run attribute @s minecraft:entity_interaction_range base set 3.75
damage @s 0.00001
stopsound @s player minecraft:entity.player.hurt
execute if data storage minecraft:bedwars {mode:3b} run function mode:super_chase/attribute