execute if data storage minecraft:bedwars {combat:0b} run attribute @s minecraft:attack_speed base reset
execute if data storage minecraft:bedwars {combat:1b} run attribute @s minecraft:attack_speed base set 10.0
attribute @s minecraft:attack_damage base reset
attribute @s minecraft:block_break_speed base reset
attribute @s minecraft:movement_speed base reset
attribute @s minecraft:scale base reset
attribute @s minecraft:jump_strength base reset
attribute @s minecraft:step_height base reset
attribute @s minecraft:max_health base reset
attribute @s minecraft:safe_fall_distance base reset
attribute @s minecraft:block_interaction_range base reset
attribute @s minecraft:entity_interaction_range base reset
attribute @s minecraft:armor base reset
attribute @s minecraft:armor_toughness base reset
attribute @s minecraft:knockback_resistance base reset
execute if data storage minecraft:bedwars {mode:3b} run function mode:super_chase/attribute