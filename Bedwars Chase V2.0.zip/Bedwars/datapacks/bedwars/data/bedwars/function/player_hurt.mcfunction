execute on attacker run scoreboard players operation #hid hid = @s uid
scoreboard players operation @s hid = #hid hid
execute unless score @s uid = @s hid run function bedwars:hurted
scoreboard players set @s phdi 10
execute if data storage minecraft:bedwars {combat:1b} run scoreboard players set @s phdi 6
advancement revoke @s only bedwars:game/hurt