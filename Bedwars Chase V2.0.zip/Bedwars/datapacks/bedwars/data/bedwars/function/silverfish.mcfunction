execute if data storage minecraft:bedwars {mode:2b} as @e[type=minecraft:snowball,sort=nearest,limit=1,tag=!snowball] store result entity @s Motion[0] double 0.000000075 run data get entity @s Motion[0] 10000000
execute if data storage minecraft:bedwars {mode:2b} as @e[type=minecraft:snowball,sort=nearest,limit=1,tag=!snowball] store result entity @s Motion[1] double 0.000000075 run data get entity @s Motion[1] 10000000
execute if data storage minecraft:bedwars {mode:2b} as @e[type=minecraft:snowball,sort=nearest,limit=1,tag=!snowball] store result entity @s Motion[2] double 0.000000075 run data get entity @s Motion[2] 10000000
summon minecraft:armor_stand ~ ~ ~ {Marker:1b,Invisible:1b,Tags:["tick_ride","silverfish","motion"]}
ride @e[type=minecraft:armor_stand,sort=nearest,limit=1,tag=motion] mount @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[4.0f]}}}},sort=nearest,limit=1,tag=!snowball]
execute if entity @s[team=red] run tag @e[type=minecraft:armor_stand,sort=nearest,limit=1,tag=motion] add silverfish_red
execute if entity @s[team=blue] run tag @e[type=minecraft:armor_stand,sort=nearest,limit=1,tag=motion] add silverfish_blue
execute if entity @s[team=green] run tag @e[type=minecraft:armor_stand,sort=nearest,limit=1,tag=motion] add silverfish_green
execute if entity @s[team=yellow] run tag @e[type=minecraft:armor_stand,sort=nearest,limit=1,tag=motion] add silverfish_yellow
tag @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[4.0f]}}}},sort=nearest,limit=1,tag=!snowball] add snowball
tag @e[type=minecraft:armor_stand] remove motion