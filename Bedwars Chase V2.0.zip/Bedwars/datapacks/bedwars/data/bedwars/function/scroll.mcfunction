function bedwars:trap/tp
advancement revoke @s only bedwars:prop/scroll