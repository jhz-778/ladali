effect give @a minecraft:resistance 5 4 true
effect give @a[scores={food=..19}] minecraft:saturation 1 0 true