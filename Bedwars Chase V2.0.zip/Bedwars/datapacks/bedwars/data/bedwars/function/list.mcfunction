#绿队
scoreboard players reset §a绿队§a-G：§a✔
scoreboard players reset §a绿队§a-G：§a✔§r§7（You）
scoreboard players reset §a绿队§a-G：§e4§9+
scoreboard players reset §a绿队§a-G：§e4§9+§r§7（You）
scoreboard players reset §a绿队§a-G：§e4
scoreboard players reset §a绿队§a-G：§e4§r§7（You）
scoreboard players reset §a绿队§a-G：§e3
scoreboard players reset §a绿队§a-G：§e3§r§7（You）
scoreboard players reset §a绿队§a-G：§e2
scoreboard players reset §a绿队§a-G：§e2§r§7（You）
scoreboard players reset §a绿队§a-G：§e1
scoreboard players reset §a绿队§a-G：§e1§r§7（You）
scoreboard players reset §a绿队§a-G：§c✘
scoreboard players reset §a绿队§a-G：§c✘§r§7（You）
execute store result score #green tick if entity @a[team=green,gamemode=!spectator]
execute store result score #green dummy if entity @a[team=green,gamemode=spectator,scores={revive=1..}]
scoreboard players operation #green tick += #green dummy
execute if data storage minecraft:green {bed:1b} run function bedwars:list/green_
execute if data storage minecraft:green {bed:0b} if score #green tick matches 5.. run function bedwars:list/green_5
execute if data storage minecraft:green {bed:0b} if score #green tick matches 4 run function bedwars:list/green_4
execute if data storage minecraft:green {bed:0b} if score #green tick matches 3 run function bedwars:list/green_3
execute if data storage minecraft:green {bed:0b} if score #green tick matches 2 run function bedwars:list/green_2
execute if data storage minecraft:green {bed:0b} if score #green tick matches 1 run function bedwars:list/green_1
execute if data storage minecraft:green {bed:0b} if score #green tick matches 0 run function team:out/green
#黄队
scoreboard players reset §e黄队§e-Y：§a✔
scoreboard players reset §e黄队§e-Y：§a✔§r§7（You）
scoreboard players reset §e黄队§e-Y：§e4§9+
scoreboard players reset §e黄队§e-Y：§e4§9+§r§7（You）
scoreboard players reset §e黄队§e-Y：§e4
scoreboard players reset §e黄队§e-Y：§e4§r§7（You）
scoreboard players reset §e黄队§e-Y：§e3
scoreboard players reset §e黄队§e-Y：§e3§r§7（You）
scoreboard players reset §e黄队§e-Y：§e2
scoreboard players reset §e黄队§e-Y：§e2§r§7（You）
scoreboard players reset §e黄队§e-Y：§e1
scoreboard players reset §e黄队§e-Y：§e1§r§7（You）
scoreboard players reset §e黄队§e-Y：§c✘
scoreboard players reset §e黄队§e-Y：§c✘§r§7（You）
execute store result score #yellow tick if entity @a[team=yellow,gamemode=!spectator]
execute store result score #yellow dummy if entity @a[team=yellow,gamemode=spectator,scores={revive=1..}]
scoreboard players operation #yellow tick += #yellow dummy
execute if data storage minecraft:yellow {bed:1b} run function bedwars:list/yellow_
execute if data storage minecraft:yellow {bed:0b} if score #yellow tick matches 5.. run function bedwars:list/yellow_5
execute if data storage minecraft:yellow {bed:0b} if score #yellow tick matches 4 run function bedwars:list/yellow_4
execute if data storage minecraft:yellow {bed:0b} if score #yellow tick matches 3 run function bedwars:list/yellow_3
execute if data storage minecraft:yellow {bed:0b} if score #yellow tick matches 2 run function bedwars:list/yellow_2
execute if data storage minecraft:yellow {bed:0b} if score #yellow tick matches 1 run function bedwars:list/yellow_1
execute if data storage minecraft:yellow {bed:0b} if score #yellow tick matches 0 run function team:out/yellow