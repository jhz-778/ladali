execute store result score @s u0 run data get entity @s Thrower[0]
execute store result score @s u1 run data get entity @s Thrower[1]
execute store result score @s u2 run data get entity @s Thrower[2]
execute store result score @s u3 run data get entity @s Thrower[3]
execute if score @s u0 = @a[tag=looting,limit=1] u0 if score @s u1 = @a[tag=looting,limit=1] u1 if score @s u2 = @a[tag=looting,limit=1] u2 if score @s u3 = @a[tag=looting,limit=1] u3 run function bedwars:loot_void_math
scoreboard players reset @s u0
scoreboard players reset @s u1
scoreboard players reset @s u2
scoreboard players reset @s u3