#数据重置
data merge storage minecraft:bedwars {win:0b,settings:1b}
function minecraft:sign
function minecraft:author
data remove storage minecraft:bedwars settings
schedule clear bedwars:schedule/second
schedule clear bedwars:schedule/healing
schedule clear bedwars:schedule/red_bed
schedule clear bedwars:schedule/blue_bed
schedule clear bedwars:schedule/green_bed
schedule clear bedwars:schedule/yellow_bed
schedule clear mode:super_chase/colddown
time set noon
weather clear
gamerule mobGriefing false
bossbar set minecraft:dragon players
team empty spectator
team empty red
team empty blue
team empty green
team empty yellow
execute as @a run function bedwars:clear_back
scoreboard objectives remove red_ui
scoreboard objectives remove blue_ui
scoreboard objectives remove green_ui
scoreboard objectives remove yellow_ui
scoreboard objectives remove spectator_ui
scoreboard players reset @a invul
spawnpoint @a 2019 89 2005
setworldspawn 2019 89 2005
#后勤处理
worldborder center 0.5 0.5
tp @a 2018 80.1 2019
gamemode adventure @a
setblock 2018 81 2034 minecraft:lever[face=wall,facing=north,powered=false] replace
execute as @e[type=minecraft:marker,tag=platform] at @s run function bedwars:platform_clear
execute as @e[type=minecraft:iron_golem,tag=npc] run tp @s 2025.5 90.0 1997.6 0 0
tp @e[type=minecraft:axolotl,tag=npc] 2030.0 94.0 2019.0
item replace entity @e[type=minecraft:item_frame,tag=tracker,limit=1] container.0 with minecraft:compass[minecraft:enchantment_glint_override=true]
kill @e[tag=!npc,type=!minecraft:player]