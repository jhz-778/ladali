#时间
scoreboard players add #second tick 1
execute if score #second tick matches 60.. run scoreboard players add #minute tick 1
execute if score #second tick matches 60.. run scoreboard players set #second tick 0
#其它
execute if data storage minecraft:bedwars {mode:1b} run function mode:chase/loop
execute if data storage minecraft:bedwars {mode:2b} run function mode:ocean/loop
execute if data storage minecraft:bedwars {mode:3b} run function mode:super_chase/loop
execute if score #plan tick matches 6.. if data storage minecraft:detail {rain_plan:1b} run function bedwars:glowing
execute as @a[scores={revive=1..}] run function bedwars:_revive
execute if data storage minecraft:detail {satiety:0b} run effect give @a[scores={food=..19}] minecraft:saturation 1 0 true
execute as @a if data entity @s {TicksFrozen:140} run damage @s 5 minecraft:frozen
execute if score #store_mining tick matches 0 as @a run function bedwars:mining
scoreboard players remove #diamond tick 1
scoreboard players remove #emerald tick 1
scoreboard players remove #second number 1
scoreboard players remove @a[scores={platcd=1..}] platcd 1
scoreboard players remove @a[scores={backcd=1..}] backcd 1
scoreboard players remove @a[scores={tpcd=1..}] tpcd 1
execute if score #store_elytra tick matches 0 as @a[gamemode=!spectator] if items entity @s armor.chest elytra[minecraft:damage=100] at @s run function bedwars:elytra
execute if score #red_trap tick matches 1.. as @e[type=minecraft:marker,tag=team_red] at @s run advancement grant @a[team=!red,distance=..15,scores={trap=0},nbt={active_effects:[{id:"minecraft:unluck"}]}] only bedwars:bedwars/magic_milk
execute if score #blue_trap tick matches 1.. as @e[type=minecraft:marker,tag=team_blue] at @s run advancement grant @a[team=!blue,distance=..15,scores={trap=0},nbt={active_effects:[{id:"minecraft:unluck"}]}] only bedwars:bedwars/magic_milk
execute if score #green_trap tick matches 1.. as @e[type=minecraft:marker,tag=team_green] at @s run advancement grant @a[team=!green,distance=..15,scores={trap=0},nbt={active_effects:[{id:"minecraft:unluck"}]}] only bedwars:bedwars/magic_milk
execute if score #yellow_trap tick matches 1.. as @e[type=minecraft:marker,tag=team_yellow] at @s run advancement grant @a[team=!yellow,distance=..15,scores={trap=0},nbt={active_effects:[{id:"minecraft:unluck"}]}] only bedwars:bedwars/magic_milk
execute if score #second number matches ..-1 run scoreboard players remove #minute number 1
execute if score #second number matches ..-1 run scoreboard players set #second number 59
function bedwars:resource/diamond
function bedwars:resource/emerald
execute unless entity @e[type=minecraft:wither] run scoreboard players remove #withers tick 1
execute unless entity @e[type=minecraft:wither] if score #plan tick matches 3.. as @e[type=minecraft:text_display,tag=wither] run function bedwars:withers
execute as @a[predicate=bedwars:compass] at @s run function bedwars:track_mainhand
execute as @a[predicate=bedwars:compass_off] at @s run function bedwars:track_offhand
execute as @e[type=minecraft:iron_golem] unless data entity @s AngryAt at @s run function bedwars:golem
execute if data storage minecraft:detail {tool:1b} as @a unless predicate minecraft:inventory run function bedwars:item/tools
execute as @a store result score @s number run clear @s #minecraft:sword 0
execute as @a if score @s number matches 1.. run clear @s minecraft:wooden_sword
execute as @a if score @s number matches 1.. run clear @s minecraft:wooden_hoe
execute as @a unless predicate minecraft:inventory unless score @s number matches 1.. run function bedwars:item/wooden_sword
execute as @a unless predicate minecraft:inventory if score @s shears matches 1.. run function bedwars:item/shears
execute as @a unless predicate minecraft:inventory if score @s spyglass matches 1.. run function bedwars:item/spyglass
execute as @a unless predicate minecraft:inventory run function bedwars:item/compass
execute as @e[type=minecraft:falling_block,nbt={OnGround:1b}] at @s if block ~ ~ ~ minecraft:moving_piston run kill @s
execute as @e[tag=invul,type=minecraft:item] run data modify entity @s Age set value 0
execute as @e[type=minecraft:chicken,tag=cxk] at @s run function bedwars:chicken
execute if data storage minecraft:bedwars {start:1b} run schedule function bedwars:schedule/second 20t replace