scoreboard players add @s tick 1
execute if score @s tick matches 8.. run fill ~1 ~ ~1 ~-1 ~ ~-1 minecraft:air replace minecraft:ice
execute if score @s tick matches 8.. run kill @s