kill @e[type=minecraft:experience_bottle,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[10.0f]}}}},limit=1]
execute if data entity @s {OnGround:1b} run function bedwars:ice_pass
execute unless data entity @s {OnGround:1b} run function bedwars:ice_fail