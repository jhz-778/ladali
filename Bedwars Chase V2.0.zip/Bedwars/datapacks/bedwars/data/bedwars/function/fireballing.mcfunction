execute if score @s tick matches 2.. if data entity @s {Motion:[0.0d,0.0d,0.0d]} run function bedwars:fireballed
kill @e[type=minecraft:snowball,scores={tick=2..}]
scoreboard players add @e[type=minecraft:snowball,tag=fireball] tick 1
tag @s[scores={tick=2..}] add fired
scoreboard players add @s tick 1