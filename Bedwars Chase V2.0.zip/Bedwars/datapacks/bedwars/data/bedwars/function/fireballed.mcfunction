execute store result entity @s Motion[0] double 0.000001 on passengers run scoreboard players get @s u0
execute store result entity @s Motion[1] double 0.000001 on passengers run scoreboard players get @s u1
execute store result entity @s Motion[2] double 0.000001 on passengers run scoreboard players get @s u2
data modify entity @s acceleration_power set value 0.1d