execute if score @s phdi matches 1.. run scoreboard players remove @s phdi 1
execute if data entity @s {HurtTime:10s} run scoreboard players set @s phdi 8