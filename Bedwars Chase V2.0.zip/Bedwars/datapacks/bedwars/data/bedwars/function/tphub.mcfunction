tp @s 2018 80.1 2019
playsound minecraft:entity.player.teleport master @s 2018 80 2019
advancement revoke @s only bedwars:game/tphub