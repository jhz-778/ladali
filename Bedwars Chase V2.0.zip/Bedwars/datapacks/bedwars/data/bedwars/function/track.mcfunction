execute if score @s compass matches 1 run function bedwars:track/red
execute if score @s compass matches 2 run function bedwars:track/blue
execute if score @s compass matches 3 run function bedwars:track/green
execute if score @s compass matches 4 run function bedwars:track/yellow