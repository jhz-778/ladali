data merge storage minecraft:bedwars {pass:0b}
execute if entity @a[team=red] if entity @a[team=blue] run data merge storage minecraft:bedwars {pass:1b}
execute if entity @a[team=red] if entity @a[team=green] run data merge storage minecraft:bedwars {pass:1b}
execute if entity @a[team=red] if entity @a[team=yellow] run data merge storage minecraft:bedwars {pass:1b}
execute if entity @a[team=blue] if entity @a[team=green] run data merge storage minecraft:bedwars {pass:1b}
execute if entity @a[team=blue] if entity @a[team=yellow] run data merge storage minecraft:bedwars {pass:1b}
execute if entity @a[team=green] if entity @a[team=yellow] run data merge storage minecraft:bedwars {pass:1b}