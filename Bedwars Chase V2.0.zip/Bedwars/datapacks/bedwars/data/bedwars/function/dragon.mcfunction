execute if entity @e[type=minecraft:ender_dragon] run bossbar set minecraft:dragon players @a
execute store result bossbar minecraft:dragon value run data get entity @e[type=minecraft:ender_dragon,limit=1] Health
execute unless entity @e[type=minecraft:ender_dragon] run bossbar set minecraft:dragon players