execute if entity @s[team=red,gamemode=!spectator] if data storage minecraft:red {bed:0b} run tag @s add out
execute if entity @s[team=blue,gamemode=!spectator] if data storage minecraft:blue {bed:0b} run tag @s add out
execute if entity @s[team=green,gamemode=!spectator] if data storage minecraft:green {bed:0b} run tag @s add out
execute if entity @s[team=yellow,gamemode=!spectator] if data storage minecraft:yellow {bed:0b} run tag @s add out
function bedwars:dead
function bedwars:clear
execute if data storage minecraft:bedwars {mode:2b} run function mode:ocean/trident_clear
execute if entity @s[team=!spectator] run scoreboard players remove @s[scores={pickaxe=2..}] pickaxe 1
execute if entity @s[team=!spectator] run scoreboard players remove @s[scores={axe=2..}] axe 1
execute if entity @s[team=!spectator] run scoreboard players remove @s[scores={shovel=2..}] shovel 1
execute if entity @s[team=!spectator] run scoreboard players remove @s[scores={hoe=2..}] hoe 1
execute if entity @s[team=red,gamemode=!spectator] if data storage minecraft:red {bed:1b} run scoreboard players set @s revive 6
execute if entity @s[team=blue,gamemode=!spectator] if data storage minecraft:blue {bed:1b} run scoreboard players set @s revive 6
execute if entity @s[team=green,gamemode=!spectator] if data storage minecraft:green {bed:1b} run scoreboard players set @s revive 6
execute if entity @s[team=yellow,gamemode=!spectator] if data storage minecraft:yellow {bed:1b} run scoreboard players set @s revive 6
execute if entity @s[team=red,gamemode=!spectator] if data storage minecraft:red {respawn:1b,bed:1b} run scoreboard players set @s revive 3
execute if entity @s[team=blue,gamemode=!spectator] if data storage minecraft:blue {respawn:1b,bed:1b} run scoreboard players set @s revive 3
execute if entity @s[team=green,gamemode=!spectator] if data storage minecraft:green {respawn:1b,bed:1b} run scoreboard players set @s revive 3
execute if entity @s[team=yellow,gamemode=!spectator] if data storage minecraft:yellow {respawn:1b,bed:1b} run scoreboard players set @s revive 3
title @s[scores={revive=1..},gamemode=!spectator] title [{"translate":"warn.title.death","color":"red"}]
title @s[scores={revive=1..},gamemode=!spectator] subtitle [{"translate":"warn.revive.will","color":"white"},{"score":{"name":"@s","objective":"revive"},"color":"red"},{"translate":"warn.revive.ed","color":"white"}]
execute if entity @s[gamemode=!spectator,tag=!out,tag=die_void] unless score @s hurt matches 2.. run tellraw @a [{"selector":"@s"},{"translate":"fell.void","color":"white"},{"text":"!"}]
execute if entity @s[gamemode=!spectator,tag=out,tag=die_void] unless score @s hurt matches 2.. run tellraw @a [{"selector":"@s"},{"translate":"fell.void","color":"white"},{"text":"!"},{"text":" "},{"translate":"warn.death.last","color":"aqua"}]
execute if entity @s[gamemode=!spectator,tag=!out,tag=!die_void] unless score @s hurt matches 2.. run tellraw @a [{"selector":"@s"},{"translate":"died.other","color":"white"},{"text":"!"}]
execute if entity @s[gamemode=!spectator,tag=out,tag=!die_void] unless score @s hurt matches 2.. run tellraw @a [{"selector":"@s"},{"translate":"died.other","color":"white"},{"text":"!"},{"text":" "},{"translate":"warn.death.last","color":"aqua"}]
execute if entity @s[tag=out] run function bedwars:twice
execute if entity @s[tag=out] run function bedwars:death
gamemode spectator @s
scoreboard players set @a[gamemode=!spectator,scores={revive=1..}] revive 0
tag @s add respawn
execute as @e[type=minecraft:armor_stand,tag=pearl] if score @s uid = @a[tag=respawn,limit=1] uid run kill @s
execute as @e[type=minecraft:snowball,tag=pearl] unless predicate bedwars:rider run kill @s
schedule function bedwars:respawn 1t replace
scoreboard players set @s death 0