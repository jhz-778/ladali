playsound minecraft:entity.chicken.egg master @a ~ ~ ~ 0.5
execute if entity @s[tag=egg_red] run fill ^0.5 ^-0.5 ^-2 ^-0.5 ^-0.5 ^-2 minecraft:red_wool keep
execute if entity @s[tag=egg_blue] run fill ^0.5 ^-0.5 ^-2 ^-0.5 ^-0.5 ^-2 minecraft:blue_wool keep
execute if entity @s[tag=egg_green] run fill ^0.5 ^-0.5 ^-2 ^-0.5 ^-0.5 ^-2 minecraft:lime_wool keep
execute if entity @s[tag=egg_yellow] run fill ^0.5 ^-0.5 ^-2 ^-0.5 ^-0.5 ^-2 minecraft:yellow_wool keep