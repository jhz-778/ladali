kill @e[type=minecraft:experience_bottle,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[12.0f]}}}}]
execute if predicate bedwars:empty run tag @s add mainhand_empty
execute unless data entity @s {OnGround:0b} run function bedwars:platform_fail
execute as @a store result score @s void run data get entity @s Pos[1]
execute if block ~ ~-1 ~ minecraft:air if score @s void matches 65..112 if data entity @s {OnGround:0b} run function bedwars:platform_pass
execute if block ~ ~-1 ~ minecraft:air unless score @s void matches 65..111 if data entity @s {OnGround:0b} run tag @s add platform_give
execute unless block ~ ~-1 ~ minecraft:air if score @s void matches 65..111 if data entity @s {OnGround:0b} run tag @s add platform_give
execute if entity @s[tag=platform_give,tag=!mainhand_empty] run loot give @s loot gui:store/platform
execute if entity @s[tag=platform_give,tag=mainhand_empty] run loot replace entity @s weapon.mainhand loot gui:store/platform
tag @s remove mainhand_empty
tag @s remove platform_give