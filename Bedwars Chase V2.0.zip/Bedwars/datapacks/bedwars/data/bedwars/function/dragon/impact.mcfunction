execute facing entity @p[gamemode=!spectator,gamemode=!creative] feet run tp @s ~ ~ ~ ~ ~
tp @s 0.0 0.0 0.0
execute at @s run tp @s ^ ^-0.5 ^5
data modify entity @e[type=minecraft:ender_dragon,limit=1] Motion set from entity @s Pos
kill @s