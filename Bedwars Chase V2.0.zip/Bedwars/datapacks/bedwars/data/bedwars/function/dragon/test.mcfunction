schedule function bedwars:dragon/death 1t replace
advancement revoke @s only bedwars:game/dragon