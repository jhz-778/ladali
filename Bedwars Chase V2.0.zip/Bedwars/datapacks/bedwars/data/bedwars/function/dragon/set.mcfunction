team join spectator @s
data merge entity @s {Health:100.0f,DragonPhase:0}
attribute @s minecraft:max_health base set 100