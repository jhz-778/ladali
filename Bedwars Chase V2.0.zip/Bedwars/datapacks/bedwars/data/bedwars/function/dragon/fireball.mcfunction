execute facing entity @p[gamemode=!spectator,gamemode=!creative] feet run tp @s ~ ~ ~ ~ ~
summon minecraft:dragon_fireball ~ ~ ~ {Tags:["dfm"]}
data modify entity @e[type=minecraft:dragon_fireball,limit=1,tag=dfm] Owner set from entity @e[type=minecraft:ender_dragon,limit=1] UUID
tp @s 0.0 0.0 0.0
execute at @s run tp @s ^ ^ ^1.0
data modify entity @e[type=minecraft:dragon_fireball,limit=1,tag=dfm] Motion set from entity @s Pos
data modify entity @e[type=minecraft:dragon_fireball,limit=1,tag=dfm] acceleration_power set value 0.1d
tag @e[type=minecraft:dragon_fireball] remove dfm
kill @s