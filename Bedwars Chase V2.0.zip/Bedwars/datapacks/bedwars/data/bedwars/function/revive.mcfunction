gamemode adventure @s
execute if data storage minecraft:bedwars {dragon:1b} run gamemode survival @s
effect give @s minecraft:resistance 5 4 true
execute if data storage minecraft:bedwars {combat:1b} as @a run attribute @s minecraft:attack_speed base set 10
execute if data storage minecraft:bedwars {mode:2b} run attribute @s minecraft:jump_strength base set 0.44
execute unless data storage minecraft:bedwars {mode:2b} run attribute @s minecraft:jump_strength base set 0.42
execute if entity @s[team=red] run tp @s @e[type=minecraft:marker,limit=1,tag=team_red]
execute if entity @s[team=blue] run tp @s @e[type=minecraft:marker,limit=1,tag=team_blue]
execute if entity @s[team=green] run tp @s @e[type=minecraft:marker,limit=1,tag=team_green]
execute if entity @s[team=yellow] run tp @s @e[type=minecraft:marker,limit=1,tag=team_yellow]