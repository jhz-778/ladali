kill @e[type=minecraft:experience_bottle,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[11.0f]}}}},limit=1]
summon minecraft:marker ~ ~ ~ {Tags:["motion"]}
tag @s add tntmotion
execute as @e[type=minecraft:marker,tag=motion] run tp @s 0.0 0.0 0.0
execute as @e[type=minecraft:marker,tag=motion] at @s rotated as @a[tag=tntmotion,limit=1] run tp ^ ^ ^0.75
execute if data storage minecraft:bedwars {mode:2b} as @e[type=minecraft:marker,tag=motion] at @s rotated as @a[tag=tntmotion,limit=1] run tp ^ ^ ^-0.15
tag @s remove tntmotion
function bedwars:minecart_motion with entity @e[type=minecraft:marker,limit=1,tag=motion]
execute anchored eyes positioned ^ ^ ^ run summon minecraft:item_display ~ ~ ~ {item:{id:"minecraft:tnt",components:{"minecraft:custom_model_data":{floats:[1.0f]}}},Invulnerable:0b,Tags:["tntminecart","tntmarker"],DisplayOffset:6,CustomDisplayTile:true,DisplayState:{Name:"minecraft:tnt"}}
scoreboard players operation @e[type=minecraft:item_display,limit=1,tag=tntmarker] uid = @s uid
execute as @e[type=minecraft:item_display,limit=1,tag=tntmarker] at @s run ride @s mount @e[type=minecraft:arrow,limit=1,sort=nearest,tag=tntminecart]
data modify entity @e[type=minecraft:item_display,limit=1,tag=tntmarker] transformation.translation[1] set value -0.5f
data modify entity @e[type=minecraft:arrow,limit=1,tag=tntminecart] Owner set from entity @s UUID
tag @e[type=minecraft:arrow] remove tntminecart
tag @e[type=minecraft:item_display] remove tntmarker
kill @e[type=minecraft:marker,tag=motion]