#红队
scoreboard players reset §c红队§c-R：§a✔✔✔✔✔§r§7（You）
scoreboard players reset §c红队§c-R：§a✔✔✔✔✔
scoreboard players reset §c红队§c-R：§a✔✔✔✔§r§7（You）
scoreboard players reset §c红队§c-R：§a✔✔✔✔
scoreboard players reset §c红队§c-R：§a✔✔✔§r§7（You）
scoreboard players reset §c红队§c-R：§a✔✔✔
scoreboard players reset §c红队§c-R：§a✔✔§r§7（You）
scoreboard players reset §c红队§c-R：§a✔✔
scoreboard players reset §c红队§c-R：§a✔
scoreboard players reset §c红队§c-R：§a✔§r§7（You）
scoreboard players reset §c红队§c-R：§e4§9+
scoreboard players reset §c红队§c-R：§e4§9+§r§7（You）
scoreboard players reset §c红队§c-R：§e4
scoreboard players reset §c红队§c-R：§e4§r§7（You）
scoreboard players reset §c红队§c-R：§e3
scoreboard players reset §c红队§c-R：§e3§r§7（You）
scoreboard players reset §c红队§c-R：§e2
scoreboard players reset §c红队§c-R：§e2§r§7（You）
scoreboard players reset §c红队§c-R：§e1
scoreboard players reset §c红队§c-R：§e1§r§7（You）
scoreboard players reset §c红队§c-R：§c✘
scoreboard players reset §c红队§c-R：§c✘§r§7（You）
execute store result score #red tick if entity @a[team=red,gamemode=!spectator]
execute store result score #red dummy if entity @a[team=red,gamemode=spectator,scores={revive=1..}]
scoreboard players operation #red tick += #red dummy
execute unless data storage minecraft:bedwars {mode:1b} unless data storage minecraft:bedwars {mode:3b} if data storage minecraft:red {bed:1b} run function bedwars:list/red_
execute if data storage minecraft:bedwars {mode:1b} if data storage minecraft:red {bed:1b} run function bedwars:list/red_chase
execute if data storage minecraft:bedwars {mode:3b} if data storage minecraft:red {bed:1b} run function bedwars:list/red_chase
execute if data storage minecraft:red {bed:0b} if score #red tick matches 5.. run function bedwars:list/red_5
execute if data storage minecraft:red {bed:0b} if score #red tick matches 4 run function bedwars:list/red_4
execute if data storage minecraft:red {bed:0b} if score #red tick matches 3 run function bedwars:list/red_3
execute if data storage minecraft:red {bed:0b} if score #red tick matches 2 run function bedwars:list/red_2
execute if data storage minecraft:red {bed:0b} if score #red tick matches 1 run function bedwars:list/red_1
execute if data storage minecraft:red {bed:0b} if score #red tick matches 0 run function team:out/red
#蓝队
scoreboard players reset §9蓝队§9-B：§a✔✔✔✔✔§r§7（You）
scoreboard players reset §9蓝队§9-B：§a✔✔✔✔✔
scoreboard players reset §9蓝队§9-B：§a✔✔✔✔§r§7（You）
scoreboard players reset §9蓝队§9-B：§a✔✔✔✔
scoreboard players reset §9蓝队§9-B：§a✔✔✔§r§7（You）
scoreboard players reset §9蓝队§9-B：§a✔✔✔
scoreboard players reset §9蓝队§9-B：§a✔✔§r§7（You）
scoreboard players reset §9蓝队§9-B：§a✔✔
scoreboard players reset §9蓝队§9-B：§a✔
scoreboard players reset §9蓝队§9-B：§a✔§r§7（You）
scoreboard players reset §9蓝队§9-B：§e4§9+
scoreboard players reset §9蓝队§9-B：§e4§9+§r§7（You）
scoreboard players reset §9蓝队§9-B：§e4
scoreboard players reset §9蓝队§9-B：§e4§r§7（You）
scoreboard players reset §9蓝队§9-B：§e3
scoreboard players reset §9蓝队§9-B：§e3§r§7（You）
scoreboard players reset §9蓝队§9-B：§e2
scoreboard players reset §9蓝队§9-B：§e2§r§7（You）
scoreboard players reset §9蓝队§9-B：§e1
scoreboard players reset §9蓝队§9-B：§e1§r§7（You）
scoreboard players reset §9蓝队§9-B：§c✘
scoreboard players reset §9蓝队§9-B：§c✘§r§7（You）
execute store result score #blue tick if entity @a[team=blue,gamemode=!spectator]
execute store result score #blue dummy if entity @a[team=blue,gamemode=spectator,scores={revive=1..}]
scoreboard players operation #blue tick += #blue dummy
execute unless data storage minecraft:bedwars {mode:1b} unless data storage minecraft:bedwars {mode:3b} if data storage minecraft:blue {bed:1b} run function bedwars:list/blue_
execute if data storage minecraft:bedwars {mode:1b} if data storage minecraft:blue {bed:1b} run function bedwars:list/blue_chase
execute if data storage minecraft:bedwars {mode:3b} if data storage minecraft:blue {bed:1b} run function bedwars:list/blue_chase
execute if data storage minecraft:blue {bed:0b} if score #blue tick matches 5.. run function bedwars:list/blue_5
execute if data storage minecraft:blue {bed:0b} if score #blue tick matches 4 run function bedwars:list/blue_4
execute if data storage minecraft:blue {bed:0b} if score #blue tick matches 3 run function bedwars:list/blue_3
execute if data storage minecraft:blue {bed:0b} if score #blue tick matches 2 run function bedwars:list/blue_2
execute if data storage minecraft:blue {bed:0b} if score #blue tick matches 1 run function bedwars:list/blue_1
execute if data storage minecraft:blue {bed:0b} if score #blue tick matches 0 run function team:out/blue
#绿队，黄队
execute if data storage minecraft:bedwars {teams:0b} unless data storage minecraft:bedwars {mode:1b} unless data storage minecraft:bedwars {mode:3b} run function bedwars:list