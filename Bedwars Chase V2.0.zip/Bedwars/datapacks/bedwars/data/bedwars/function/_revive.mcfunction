scoreboard players remove @s revive 1
execute if score @s revive matches 0 run function bedwars:revive
title @s[scores={revive=1..}] times 0 20 20
title @s[scores={revive=1..}] subtitle [{"translate":"warn.revive.will","color":"white"},{"score":{"name":"@s","objective":"revive"},"color":"red"},{"translate":"warn.revive.ed","color":"white"}]