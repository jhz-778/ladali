execute at @s run playsound minecraft:item.armor.equip_elytra master @s ~ ~ ~ 2 1
loot replace entity @s armor.chest loot bedwars:chestplate
clear @s minecraft:elytra[minecraft:custom_model_data={floats:[0.0f]}]