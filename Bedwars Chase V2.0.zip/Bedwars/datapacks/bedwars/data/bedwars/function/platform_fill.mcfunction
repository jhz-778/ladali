tag @s add platm
scoreboard players set @s platcd 5
summon minecraft:marker ~ ~-1 ~ {Tags:["platform","plat"]}
execute as @e[type=minecraft:marker,tag=plat] at @s run function bedwars:platform_data