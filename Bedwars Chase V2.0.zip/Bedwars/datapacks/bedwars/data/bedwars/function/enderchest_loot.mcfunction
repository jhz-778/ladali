#判定
execute if entity @s[team=red] at @e[type=minecraft:marker,tag=resource_red,limit=1] run summon minecraft:chest_minecart ~ ~ ~ {Tags:["ecloot"]}
execute if entity @s[team=blue] at @e[type=minecraft:marker,tag=resource_blue,limit=1] run summon minecraft:chest_minecart ~ ~ ~ {Tags:["ecloot"]}
execute if entity @s[team=green] at @e[type=minecraft:marker,tag=resource_green,limit=1] run summon minecraft:chest_minecart ~ ~ ~ {Tags:["ecloot"]}
execute if entity @s[team=yellow] at @e[type=minecraft:marker,tag=resource_yellow,limit=1] run summon minecraft:chest_minecart ~ ~ ~ {Tags:["ecloot"]}
#掉落
execute if score @s gui matches 0 run function gui:ender_chest
tag @s add ecloot
execute as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[limit=1,tag=ecloot] uid run data modify entity @e[type=minecraft:chest_minecart,limit=1,tag=ecloot] Items set from entity @s data.EnderItems
tag @s remove ecloot
kill @e[type=minecraft:chest_minecart,limit=1,tag=ecloot]