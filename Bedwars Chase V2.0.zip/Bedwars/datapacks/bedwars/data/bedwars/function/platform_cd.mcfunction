playsound minecraft:block.anvil.place block @s ~ ~ ~ 1 1.5
tag @s add platform_give
tellraw @s [{"translate":"warn.platcd.up","color":"red"},{"score":{"name":"@s","objective":"platcd"},"color":"yellow"},{"text":"s","color":"yellow"},{"translate":"warn.platcd.down"}]