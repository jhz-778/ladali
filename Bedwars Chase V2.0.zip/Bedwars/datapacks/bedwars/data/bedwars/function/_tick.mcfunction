#格式化
function bedwars:player_attribute
gamemode adventure @s
recipe take @s *
advancement grant @s only bedwars:bedwars/root
scoreboard players set @s title 0
scoreboard players set @s trap 0
scoreboard players set @s gui -1
execute if data storage minecraft:bedwars {start:1b} run scoreboard players set @s gui 0
scoreboard players set @s bed 0
scoreboard players set @s kill 0
scoreboard players set @s last_kill 0
#数据储存
execute unless score #uid uid = #uid uid run function gui:_control/_reset
scoreboard players add #uid uid 1
scoreboard players operation @s uid = #uid uid
execute positioned 2019 64 2019 summon minecraft:marker run function bedwars:initial
execute store result score @s u0 run data get entity @s UUID[0]
execute store result score @s u1 run data get entity @s UUID[1]
execute store result score @s u2 run data get entity @s UUID[2]
execute store result score @s u3 run data get entity @s UUID[3]
#资源包问题
tellraw @s [{"text":"-----------------------------------------------------","color":"white"}]
tellraw @s [{"text":"地图需要装载指定资源包来获取最好的游玩体验（若已装载请忽略此消息与下一条英文提示）","color":"yellow"},{"text":"【点击此处下载】","color":"green","hoverEvent":{"action":"show_text","value":"蓝奏云网盘"},"clickEvent":{"action":"open_url","value":"https://wwma.lanzoub.com/iymHa2ha4yra"}}]
tellraw @s [{"text":"-----------------------------------------------------","color":"white"}]
tellraw @s [{"text":"The map needs to be loaded with the specified Resource Pack to get the best play experience (Please ignore this message and the previous Chinese prompt if resources pack is loaded) ","color":"yellow"},{"text":"[Click Here to Download]","color":"green","hoverEvent":{"action":"show_text","value":"Github"},"clickEvent":{"action":"open_url","value":"https://github.com/Plants-Ticks/Project/blob/main/Bedwars%20Chase%20V2.0%20RP.zip"}}]
tellraw @s [{"text":"-----------------------------------------------------","color":"white"}]