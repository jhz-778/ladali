tag @s add twicing
execute as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[limit=1,tag=twicing] uid store result score @a[limit=1,tag=twicing] limit run data get entity @s data.Limit.twice
execute if entity @s[team=red,scores={limit=0}] if data storage minecraft:red {twice:1b} run scoreboard players set @s revive 60
execute if entity @s[team=blue,scores={limit=0}] if data storage minecraft:blue {twice:1b} run scoreboard players set @s revive 60
execute if entity @s[team=green,scores={limit=0}] if data storage minecraft:green {twice:1b} run scoreboard players set @s revive 60
execute if entity @s[team=yellow,scores={limit=0}] if data storage minecraft:yellow {twice:1b} run scoreboard players set @s revive 60
title @s[scores={revive=1..}] title [{"translate":"warn.title.death","color":"red"}]
title @s[scores={revive=1..}] subtitle [{"translate":"warn.revive.will","color":"white"},{"score":{"name":"@s","objective":"revive"},"color":"red"},{"translate":"warn.revive.ed","color":"white"}]
execute if score @s revive matches 1.. as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[limit=1,tag=twicing] uid run data merge entity @s {data:{Limit:{twice:1}}}
execute if score @s revive matches 1.. run tellraw @s [{"text":">--","bold":true,"color":"yellow"},{"translate":"warn.twice.running","color":"gold","bold":false},{"text":"--<"}]
execute if score @s revive matches 1.. run tag @s remove out
tag @s remove twicing