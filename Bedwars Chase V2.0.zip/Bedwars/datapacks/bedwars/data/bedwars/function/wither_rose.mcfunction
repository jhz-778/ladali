execute store result score @s count run clear @s minecraft:wither_rose[!minecraft:consumable]
loot give @s loot bedwars:wither_rose
advancement revoke @s only bedwars:game/wither_rose