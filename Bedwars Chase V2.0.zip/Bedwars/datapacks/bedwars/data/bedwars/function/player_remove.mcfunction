scoreboard objectives remove quit
scoreboard objectives add quit dummy
scoreboard players set @a quit 0
execute if data storage minecraft:bedwars {start:1b} run function bedwars:player_remove_start