scoreboard players add @s tick 1
execute if score @s tick matches 2 run fill ~ ~1 ~ ~ ~1 ~ minecraft:air replace minecraft:cobweb
execute if score @s tick matches 200.. run function bedwars:platform_clear