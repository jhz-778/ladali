execute if data storage minecraft:detail {satiety:0b} as @a[tag=respawn] run damage @s 0.00001 minecraft:hunger_2
stopsound @a[tag=respawn] player minecraft:entity.player.hurt
tp @a[tag=respawn,gamemode=spectator] 0 112 0
tag @a remove respawn