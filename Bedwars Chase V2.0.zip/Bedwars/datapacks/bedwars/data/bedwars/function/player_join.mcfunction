gamemode spectator @s
effect clear @s
function bedwars:player_attribute
execute if data storage minecraft:bedwars {Special:{exper:1b}} run function mode:exper/half
effect give @s minecraft:instant_health 1 4 true
execute if entity @s[team=!red,team=!blue,team=!green,team=!yellow,team=!spectator] run function bedwars:player_spectator
execute if entity @s[team=!spectator] run function bedwars:player_team
scoreboard players set @s quit 0
function bedwars:_list