scoreboard players set #ranking tick 0
scoreboard players operation #ranking tick > @a[scores={tick=0..},team=!spectator] tick
execute as @a[team=!spectator] if score @s tick = #ranking tick run tag @s add 2nd
tellraw @a [{"text":"   "},{"text":"2nd-","color":"yellow","bold":true},{"selector":"@a[tag=2nd]"},{"text":":","bold":true},{"score":{"name":"#ranking","objective":"tick"},"color":"red"}]
scoreboard players set @a[tag=2nd] tick -1
tag @a remove 2nd
execute if entity @a[scores={tick=0..},team=!spectator] run function bedwars:ranked