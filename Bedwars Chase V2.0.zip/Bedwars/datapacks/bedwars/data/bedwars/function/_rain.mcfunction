execute if entity @e[type=minecraft:lightning_bolt] run effect give @a minecraft:night_vision 2 1 false
execute if entity @e[type=minecraft:lightning_bolt] run effect clear @a minecraft:blindness
effect give @a[nbt=!{active_effects:[{id:"minecraft:night_vision"}]},gamemode=!spectator,team=!spectator] minecraft:blindness 2 0 true