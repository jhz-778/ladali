execute store result score @s tick run random value 0..4
execute if score @s tick matches 1 run data modify entity @s FireworksItem.components."minecraft:fireworks".explosions[0].shape set value large_ball
execute if score @s tick matches 2 run data modify entity @s FireworksItem.components."minecraft:fireworks".explosions[0].shape set value star
execute if score @s tick matches 3 run data modify entity @s FireworksItem.components."minecraft:fireworks".explosions[0].shape set value creeper
execute if score @s tick matches 4 run data modify entity @s FireworksItem.components."minecraft:fireworks".explosions[0].shape set value burst
execute if predicate minecraft:chance50 run data modify entity @s FireworksItem.components."minecraft:fireworks".explosions[0].has_trail set value 1
execute if predicate minecraft:chance50 run data modify entity @s FireworksItem.components."minecraft:fireworks".explosions[0].has_twinkle set value 1
tag @s remove fring