scoreboard players set @a title 200
execute if entity @a[team=!spectator] run function bedwars:rank
effect give @a minecraft:resistance 11 124 true
effect give @a minecraft:instant_health 1 124 true
title @a times 20 100 20
gamemode spectator @a
title @a title [{"translate":"warn.game.draw","color":"yellow"},{"text":"！"}]
title @a subtitle [{"text":""}]
tellraw @a [{"text":"> ","color":"gold","bold":true},{"translate":"warn.game.tie","color":"yellow"},{"text":","},{"translate":"warn.game.drawed","color":"yellow"},{"text":"！"}]
data merge storage minecraft:bedwars {win:5b,start:-1b}
kill @e[type=minecraft:ender_dragon]
schedule function bedwars:_end 10s replace