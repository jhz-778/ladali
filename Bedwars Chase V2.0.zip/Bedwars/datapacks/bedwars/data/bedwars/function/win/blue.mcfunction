scoreboard players set @a title 200
execute if entity @a[team=!spectator] run function bedwars:rank
advancement grant @a[team=blue] only bedwars:bedwars/winner
effect give @a minecraft:resistance 11 124 true
effect give @a minecraft:instant_health 1 124 true
title @a times 20 100 20
title @a[team=blue] title [{"translate":"warn.game.win","color":"gold"},{"text":"！"}]
title @a[team=!blue] title [{"translate":"warn.game.over","color":"red"},{"text":"!"}]
title @a subtitle [{"text":""}]
tellraw @a [{"text":"> ","color":"gold","bold":true},{"translate":"blue.team","color":"blue"},{"text":" "},{"translate":"warn.game.win","color":"yellow"},{"text":"！"}]
tellraw @a [{"translate":"winner","color":"yellow"},{"text":":"},{"selector":"@a[team=blue]"}]
data merge storage minecraft:bedwars {win:2b,start:-1b}
function bedwars:schedule/firework
kill @e[type=minecraft:ender_dragon]
schedule function bedwars:_end 10s replace