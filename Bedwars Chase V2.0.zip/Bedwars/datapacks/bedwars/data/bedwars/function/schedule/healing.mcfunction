#一级
execute if score #red_healing tick matches 1 at @e[type=minecraft:marker,tag=team_red,limit=1] run effect give @a[distance=..15,team=red] minecraft:regeneration 3 0 false
execute if score #blue_healing tick matches 1 at @e[type=minecraft:marker,tag=team_blue,limit=1] run effect give @a[distance=..15,team=blue] minecraft:regeneration 3 0 false
execute if score #green_healing tick matches 1 at @e[type=minecraft:marker,tag=team_green,limit=1] run effect give @a[distance=..15,team=green] minecraft:regeneration 3 0 false
execute if score #yellow_healing tick matches 1 at @e[type=minecraft:marker,tag=team_yellow,limit=1] run effect give @a[distance=..15,team=yellow] minecraft:regeneration 3 0 false
#二级
execute if score #red_healing tick matches 2 at @e[type=minecraft:marker,tag=team_red,limit=1] run effect give @a[distance=..15,team=red] minecraft:regeneration 3 1 false
execute if score #blue_healing tick matches 2 at @e[type=minecraft:marker,tag=team_blue,limit=1] run effect give @a[distance=..15,team=blue] minecraft:regeneration 3 1 false
execute if score #green_healing tick matches 2 at @e[type=minecraft:marker,tag=team_green,limit=1] run effect give @a[distance=..15,team=green] minecraft:regeneration 3 1 false
execute if score #yellow_healing tick matches 2 at @e[type=minecraft:marker,tag=team_yellow,limit=1] run effect give @a[distance=..15,team=yellow] minecraft:regeneration 3 1 false
#三级
execute if score #red_healing tick matches 3 at @e[type=minecraft:marker,tag=team_red,limit=1] run effect give @a[distance=..15,team=red] minecraft:regeneration 3 2 false
execute if score #blue_healing tick matches 3 at @e[type=minecraft:marker,tag=team_blue,limit=1] run effect give @a[distance=..15,team=blue] minecraft:regeneration 3 2 false
execute if score #green_healing tick matches 3 at @e[type=minecraft:marker,tag=team_green,limit=1] run effect give @a[distance=..15,team=green] minecraft:regeneration 3 2 false
execute if score #yellow_healing tick matches 3 at @e[type=minecraft:marker,tag=team_yellow,limit=1] run effect give @a[distance=..15,team=yellow] minecraft:regeneration 3 2 false
#四级
execute if score #red_healing tick matches 4 at @e[type=minecraft:marker,tag=team_red,limit=1] run effect give @a[distance=..15,team=red] minecraft:regeneration 3 3 false
execute if score #blue_healing tick matches 4 at @e[type=minecraft:marker,tag=team_blue,limit=1] run effect give @a[distance=..15,team=blue] minecraft:regeneration 3 3 false
execute if score #green_healing tick matches 4 at @e[type=minecraft:marker,tag=team_green,limit=1] run effect give @a[distance=..15,team=green] minecraft:regeneration 3 3 false
execute if score #yellow_healing tick matches 4 at @e[type=minecraft:marker,tag=team_yellow,limit=1] run effect give @a[distance=..15,team=yellow] minecraft:regeneration 3 3 false
schedule function bedwars:schedule/healing 59t replace