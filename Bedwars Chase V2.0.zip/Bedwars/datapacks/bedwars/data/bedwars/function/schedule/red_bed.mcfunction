execute at @e[type=minecraft:marker,tag=redbed,limit=1] run fill ^ ^ ^ ^ ^ ^1 minecraft:air
data merge storage minecraft:red {bed:0b}
function bedwars:_list
function bedwars:_test