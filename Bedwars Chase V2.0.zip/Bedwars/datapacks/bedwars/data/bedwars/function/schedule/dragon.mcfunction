execute unless entity @e[type=minecraft:ender_dragon] run scoreboard players add #dragon cd 1
execute if score #dragon cd matches 10.. positioned 0 80 0 summon minecraft:ender_dragon run function bedwars:dragon/set
execute if score #dragon cd matches 10.. run scoreboard players reset #dragon cd
data modify entity @e[type=minecraft:ender_dragon,limit=1] DragonPhase set value 0
execute as @e[type=minecraft:ender_dragon,limit=1] store result score #dragon tick run data get entity @s Pos[1]
execute if score #dragon tick matches ..99 if entity @a[gamemode=!spectator,gamemode=!creative] at @e[type=minecraft:ender_dragon,limit=1] summon minecraft:marker run function bedwars:dragon/fireball
execute positioned 0 50 0 run kill @e[type=minecraft:dragon_fireball,distance=128..]
execute if score #dragon tick matches 100.. if entity @a[gamemode=!spectator,gamemode=!creative] at @e[type=minecraft:ender_dragon,limit=1] summon minecraft:marker run function bedwars:dragon/impact
execute if data storage minecraft:bedwars {start:1b} run schedule function bedwars:schedule/dragon 100t replace