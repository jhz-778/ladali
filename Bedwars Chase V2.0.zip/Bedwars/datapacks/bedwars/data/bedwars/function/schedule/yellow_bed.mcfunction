execute at @e[type=minecraft:marker,tag=yellowbed,limit=1] run fill ^ ^ ^ ^ ^ ^1 minecraft:air
data merge storage minecraft:yellow {bed:0b}
function bedwars:_list
function bedwars:_test