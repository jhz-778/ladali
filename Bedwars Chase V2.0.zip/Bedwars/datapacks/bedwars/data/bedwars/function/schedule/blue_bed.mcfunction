execute at @e[type=minecraft:marker,tag=bluebed,limit=1] run fill ^ ^ ^ ^ ^ ^1 minecraft:air
data merge storage minecraft:blue {bed:0b}
function bedwars:_list
function bedwars:_test