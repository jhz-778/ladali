function bedwars:win/firework
execute if data storage minecraft:bedwars {start:-1b} run schedule function bedwars:schedule/firework 20t replace