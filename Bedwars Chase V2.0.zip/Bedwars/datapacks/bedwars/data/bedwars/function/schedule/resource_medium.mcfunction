function bedwars:resource/summon
execute if data storage minecraft:bedwars {start:1b} run schedule function bedwars:schedule/resource_medium 20t