execute as @e[type=minecraft:marker,tag=ice] at @s run function bedwars:iceing
execute as @a[gamemode=!spectator] at @s if block ~ ~-0.5 ~ minecraft:ice run summon minecraft:marker ~ ~-0.5 ~ {Tags:["endclear","iced"]}
execute if data storage minecraft:bedwars {start:1b} run schedule function bedwars:schedule/ice 3t replace