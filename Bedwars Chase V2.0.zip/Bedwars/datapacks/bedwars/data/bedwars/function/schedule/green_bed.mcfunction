execute at @e[type=minecraft:marker,tag=greenbed,limit=1] run fill ^ ^ ^ ^ ^ ^1 minecraft:air
data merge storage minecraft:green {bed:0b}
function bedwars:_list
function bedwars:_test