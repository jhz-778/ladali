execute if entity @s[team=red] if entity @a[sort=nearest,limit=1,team=!red,distance=..15,gamemode=!spectator] run tag @s add cxk_pass
execute if entity @s[team=blue] if entity @a[sort=nearest,limit=1,team=!blue,distance=..15,gamemode=!spectator] run tag @s add cxk_pass
execute if entity @s[team=green] if entity @a[sort=nearest,limit=1,team=!green,distance=..15,gamemode=!spectator] run tag @s add cxk_pass
execute if entity @s[team=yellow] if entity @a[sort=nearest,limit=1,team=!yellow,distance=..15,gamemode=!spectator] run tag @s add cxk_pass
execute if entity @s[tag=cxk_pass] run function bedwars:chicken_pass