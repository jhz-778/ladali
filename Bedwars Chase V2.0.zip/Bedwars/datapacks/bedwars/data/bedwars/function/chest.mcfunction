execute if data storage minecraft:bedwars {start:0b} run return run function gui:normal/menu
execute if block ^ ^ ^ minecraft:ender_chest run function bedwars:chested
execute as @s[distance=..7.5] unless block ^ ^ ^ minecraft:ender_chest positioned ^ ^ ^0.25 run function bedwars:chest
execute as @s[distance=7.5..] run scoreboard players set @s chest 0