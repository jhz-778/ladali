data merge entity @s {damage:0.1d,life:1200s,Tags:["fishing"],SoundEvent:"minecraft:block.lily_pad.place"}
scoreboard players operation @e[type=minecraft:fishing_bobber,limit=1,sort=nearest,tag=!fishing] uid = @p[scores={fish=1..}] uid
ride @e[type=minecraft:fishing_bobber,limit=1,sort=nearest,tag=!fishing] mount @s
tag @e[type=minecraft:fishing_bobber,limit=1,sort=nearest,tag=!fishing] add fishing
tag @s remove fishm