execute if data storage minecraft:bedwars {Special:{exper:1b}} run function mode:exper/half
execute if data storage minecraft:bedwars {mode:3b} run function mode:super_chase/asskill
execute if score @s hurt matches 2.. run function bedwars:loot
tag @a remove die_bomb
tag @a remove die_fish
execute if entity @s[tag=!die_test,tag=!die_void] at @s run function bedwars:dead_loot
tag @a remove die_test