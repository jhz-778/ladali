execute if data storage minecraft:bedwars {mode:2b} as @e[type=minecraft:egg,sort=nearest,limit=1,tag=!egg] store result entity @s Motion[0] double 0.000000075 run data get entity @s Motion[0] 10000000
execute if data storage minecraft:bedwars {mode:2b} as @e[type=minecraft:egg,sort=nearest,limit=1,tag=!egg] store result entity @s Motion[1] double 0.000000075 run data get entity @s Motion[1] 10000000
execute if data storage minecraft:bedwars {mode:2b} as @e[type=minecraft:egg,sort=nearest,limit=1,tag=!egg] store result entity @s Motion[2] double 0.000000075 run data get entity @s Motion[2] 10000000
summon minecraft:armor_stand ~ ~ ~ {ArmorItems:[{},{},{id:"minecraft:egg",Count:1b,components:{"minecraft:custom_data":{Owner:[I;0,0,0,0]}}},{}],Marker:1b,Invisible:1b,Tags:["egg","egging"]}
data modify entity @e[type=minecraft:armor_stand,sort=nearest,limit=1,tag=egging] ArmorItems[2].components."minecraft:custom_data".Owner set from entity @s UUID
ride @e[type=minecraft:armor_stand,sort=nearest,limit=1,tag=egging] mount @e[type=egg,limit=1,sort=nearest,tag=!egg]
data modify entity @e[type=minecraft:armor_stand,sort=nearest,limit=1,tag=egging] Rotation[0] set from entity @s Rotation[0]
execute if entity @s[team=red] run tag @e[type=minecraft:armor_stand,sort=nearest,limit=1,tag=egging] add egg_red
execute if entity @s[team=blue] run tag @e[type=minecraft:armor_stand,sort=nearest,limit=1,tag=egging] add egg_blue
execute if entity @s[team=green] run tag @e[type=minecraft:armor_stand,sort=nearest,limit=1,tag=egging] add egg_green
execute if entity @s[team=yellow] run tag @e[type=minecraft:armor_stand,sort=nearest,limit=1,tag=egging] add egg_yellow
tag @e[type=minecraft:armor_stand] remove egging
tag @e[type=minecraft:egg] add egg
scoreboard players set @s egg 0