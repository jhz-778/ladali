#手持
execute if items entity @s weapon.mainhand #minecraft:weapon run item modify entity @s weapon.mainhand bedwars:hand_add
execute if items entity @s weapon.offhand #minecraft:weapon run item modify entity @s weapon.offhand bedwars:hand_add
#木剑
clear @s minecraft:wooden_sword[!minecraft:custom_data={hand:1b}]
clear @s minecraft:wooden_hoe[!minecraft:custom_data={hand:1b}]
execute unless items entity @s container.* minecraft:wooden_sword unless items entity @s container.* #minecraft:sword run loot give @s loot bedwars:wooden_sword
#石剑
execute store result score @s custom run clear @s #minecraft:stone_sword[!minecraft:custom_data={hand:1b}]
loot give @s loot bedwars:weapon/stone_sword
execute store result score @s dummy run clear @s #minecraft:stone_sword[!minecraft:custom_data={hand:1b}] 0
scoreboard players operation @s custom -= @s dummy
execute if score @s custom matches 1.. at @s run loot spawn ~ ~ ~ loot bedwars:weapon/stone_sword
#铁剑
execute store result score @s custom run clear @s #minecraft:iron_sword[!minecraft:custom_data={hand:1b},!minecraft:custom_data={gui:1b}]
loot give @s loot bedwars:weapon/iron_sword
execute store result score @s dummy run clear @s #minecraft:iron_sword[!minecraft:custom_data={hand:1b}] 0
scoreboard players operation @s custom -= @s dummy
execute if score @s custom matches 1.. at @s run loot spawn ~ ~ ~ loot bedwars:weapon/iron_sword
#钻石剑
execute store result score @s custom run clear @s #minecraft:diamond_sword[!minecraft:custom_data={hand:1b}]
loot give @s loot bedwars:weapon/diamond_sword
execute store result score @s dummy run clear @s #minecraft:diamond_sword[!minecraft:custom_data={hand:1b}] 0
scoreboard players operation @s custom -= @s dummy
execute if score @s custom matches 1.. at @s run loot spawn ~ ~ ~ loot bedwars:weapon/diamond_sword
#下界合金剑
execute store result score @s custom run clear @s #minecraft:netherite_sword[!minecraft:custom_data={hand:1b}]
loot give @s loot bedwars:weapon/netherite_sword
execute store result score @s dummy run clear @s #minecraft:netherite_sword[!minecraft:custom_data={hand:1b}] 0
scoreboard players operation @s custom -= @s dummy
execute if score @s custom matches 1.. at @s run loot spawn ~ ~ ~ loot bedwars:weapon/netherite_sword
#击退棒
execute store result score @s custom run clear @s minecraft:stick[!minecraft:custom_data={hand:1b}]
loot give @s loot bedwars:weapon/stick
execute store result score @s dummy run clear @s minecraft:stick[!minecraft:custom_data={hand:1b}] 0
scoreboard players operation @s custom -= @s dummy
execute if score @s custom matches 1.. at @s run loot spawn ~ ~ ~ loot bedwars:weapon/stick
#钓鱼竿
execute store result score @s custom run clear @s minecraft:fishing_rod[!minecraft:custom_data={hand:1b},!minecraft:custom_data~{super:1b}]
loot give @s loot bedwars:weapon/fishing_rod
execute store result score @s dummy run clear @s minecraft:fishing_rod[!minecraft:custom_data~{hand:1b},!minecraft:custom_data~{super:1b}] 0
scoreboard players operation @s custom -= @s dummy
execute if score @s custom matches 1.. at @s run loot spawn ~ ~ ~ loot bedwars:weapon/fishing_rod
#重锤
execute store result score @s custom run clear @s minecraft:mace[!minecraft:custom_data={hand:1b}]
loot give @s loot bedwars:weapon/mace
execute store result score @s dummy run clear @s minecraft:mace[!minecraft:custom_data={hand:1b}] 0
scoreboard players operation @s custom -= @s dummy
execute if score @s custom matches 1.. at @s run loot spawn ~ ~ ~ loot bedwars:weapon/mace
#处理
execute if items entity @s weapon.mainhand #minecraft:weapon run item modify entity @s weapon.mainhand bedwars:hand_remove
execute if items entity @s weapon.offhand #minecraft:weapon run item modify entity @s weapon.offhand bedwars:hand_remove