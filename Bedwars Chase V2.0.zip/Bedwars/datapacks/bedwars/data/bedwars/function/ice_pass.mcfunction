summon minecraft:marker ~ ~ ~ {Tags:["ice","icem"]}
data modify entity @e[type=minecraft:marker,tag=icem,limit=1] Rotation[0] set from entity @s Rotation[0]
tag @e[type=minecraft:marker] remove icem