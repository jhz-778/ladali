execute store result entity @s Pos[0] double 1 run data get entity @s Pos[0]
execute store result entity @s Pos[1] double 1 run data get entity @s Pos[1]
execute store result entity @s Pos[2] double 1 run data get entity @s Pos[2]
fill ~1 ~ ~1 ~-1 ~ ~-1 minecraft:slime_block keep
fill ~-2 ~ ~1 ~2 ~ ~1 minecraft:slime_block keep
fill ~-2 ~ ~-1 ~2 ~ ~-1 minecraft:slime_block keep
fill ~-1 ~ ~2 ~-1 ~ ~-2 minecraft:slime_block keep
fill ~1 ~ ~2 ~1 ~ ~-2 minecraft:slime_block keep
setblock ~ ~1 ~ minecraft:cobweb keep
execute positioned ~ ~1 ~ run tp @a[tag=platm,limit=1,sort=nearest] ~ ~ ~
tag @a remove platm
tag @s remove plat