execute store result score @s u0 run data get entity @s Pos[0]
execute store result score @s u2 run data get entity @s Pos[2]
playsound minecraft:block.glass.break master @a ~ ~ ~ 0.5 1
execute unless data storage minecraft:bedwars {mode:1b} if score @s u0 matches -98..98 if score @s u2 matches -98..98 run fill ~0.5 ~-1 ~0.5 ~-0.5 ~-1 ~-0.5 minecraft:ice keep
execute if data storage minecraft:bedwars {mode:1b} if score @s u0 matches -60..60 if score @s u2 matches -185..185 run fill ~0.5 ~-1 ~0.5 ~-0.5 ~-1 ~-0.5 minecraft:ice keep
scoreboard players add @s count 1
tp @s ^ ^ ^1
execute if score @s count matches 30.. run kill @s