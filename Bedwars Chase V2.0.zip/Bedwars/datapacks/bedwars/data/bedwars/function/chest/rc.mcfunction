tellraw @s [{"translate":"tip.chest.fail","color":"red"},{"translate":"red.team","color":"red","bold":true},{"translate":"tip.chest.fails","color":"red"}]
execute as @e[type=minecraft:marker,tag=team_red] at @s as @n[type=minecraft:marker,tag=chestlock,limit=1] at @s run data modify storage minecraft:red Items set from block ~ ~ ~ Items
execute as @e[type=minecraft:marker,tag=team_red] at @s as @n[type=minecraft:marker,tag=chestlock,limit=1] at @s run setblock ~ ~ ~ minecraft:air replace
schedule function bedwars:chest/red 2t replace