tellraw @s [{"translate":"tip.chest.fail","color":"red"},{"translate":"blue.team","color":"blue","bold":true},{"translate":"tip.chest.fails","color":"red"}]
execute as @e[type=minecraft:marker,tag=team_blue] at @s as @n[type=minecraft:marker,tag=chestlock,limit=1] at @s run data modify storage minecraft:blue Items set from block ~ ~ ~ Items
execute as @e[type=minecraft:marker,tag=team_blue] at @s as @n[type=minecraft:marker,tag=chestlock,limit=1] at @s run setblock ~ ~ ~ minecraft:air replace
schedule function bedwars:chest/blue 2t replace