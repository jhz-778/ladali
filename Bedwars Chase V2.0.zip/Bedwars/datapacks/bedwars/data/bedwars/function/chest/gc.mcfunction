tellraw @s [{"translate":"tip.chest.fail","color":"red"},{"translate":"green.team","color":"green","bold":true},{"translate":"tip.chest.fails","color":"red"}]
execute as @e[type=minecraft:marker,tag=team_green] at @s as @n[type=minecraft:marker,tag=chestlock,limit=1] at @s run data modify storage minecraft:green Items set from block ~ ~ ~ Items
execute as @e[type=minecraft:marker,tag=team_green] at @s as @n[type=minecraft:marker,tag=chestlock,limit=1] at @s run setblock ~ ~ ~ minecraft:air replace
schedule function bedwars:chest/green 2t replace