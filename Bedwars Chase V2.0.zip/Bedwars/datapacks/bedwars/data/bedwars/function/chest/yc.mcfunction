tellraw @s [{"translate":"tip.chest.fail","color":"red"},{"translate":"yellow.team","color":"yellow","bold":true},{"translate":"tip.chest.fails","color":"red"}]
execute as @e[type=minecraft:marker,tag=team_yellow] at @s as @n[type=minecraft:marker,tag=chestlock,limit=1] at @s run data modify storage minecraft:yellow Items set from block ~ ~ ~ Items
execute as @e[type=minecraft:marker,tag=team_yellow] at @s as @n[type=minecraft:marker,tag=chestlock,limit=1] at @s run setblock ~ ~ ~ minecraft:air replace
schedule function bedwars:chest/yellow 2t replace