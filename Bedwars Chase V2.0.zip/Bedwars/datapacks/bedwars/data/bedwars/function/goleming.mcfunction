attribute @s minecraft:max_absorption base set 29
data merge entity @s {ArmorDropChances:[0.0f,0.0f,0.0f,0.0f],Health:1.0f,AbsorptionAmount:29.0f}
attribute @s minecraft:max_health base set 1
tag @s add iron_golem
function bedwars:golem
item replace entity @s armor.head with minecraft:iron_ingot[minecraft:enchantments={levels:{"bedwars:red":1,"bedwars:phdi":1,"bedwars:mob":1}}]
execute if entity @s[team=blue] run return run item replace entity @s armor.head with minecraft:iron_ingot[minecraft:enchantments={levels:{"bedwars:blue":1,"bedwars:phdi":1,"bedwars:mob":1}}]
execute if entity @s[team=green] run return run item replace entity @s armor.head with minecraft:iron_ingot[minecraft:enchantments={levels:{"bedwars:green":1,"bedwars:phdi":1,"bedwars:mob":1}}]
execute if entity @s[team=yellow] run return run item replace entity @s armor.head with minecraft:iron_ingot[minecraft:enchantments={levels:{"bedwars:yellow":1,"bedwars:phdi":1,"bedwars:mob":1}}]