scoreboard players reset @s
particle minecraft:explosion ~ ~ ~ 0 0 0 1 1 normal
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 0.5 1.5
kill @s