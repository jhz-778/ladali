title @s times 15 200 20
title @s title [{"translate":"warn.title.dead","color":"red"}]
title @s subtitle [{"translate":"warn.sub.dead","color":"white"}]