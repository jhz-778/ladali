execute anchored eyes run summon minecraft:fireball ^ ^ ^1.85 {Tags:["motion"],ExplosionPower:2}
data modify entity @e[type=minecraft:fireball,limit=1,tag=motion,sort=nearest] Owner set from entity @s UUID
summon minecraft:armor_stand ~ ~ ~ {Marker:1b,Invisible:1b,Tags:["motion","fireball","tick_ride"]}
scoreboard players operation @e[type=minecraft:armor_stand,limit=1,tag=motion,sort=nearest] uid = @s uid
execute as @e[type=minecraft:armor_stand,tag=motion] at @s run tp 0.0 0.0 0.0
execute as @e[type=minecraft:armor_stand,tag=motion] at @s rotated as @p[scores={snowball=1..}] run tp ^ ^ ^0.1
execute as @e[type=minecraft:armor_stand,tag=motion] store result score @s u0 run data get entity @s Pos[0] 1000000
execute as @e[type=minecraft:armor_stand,tag=motion] store result score @s u1 run data get entity @s Pos[1] 1000000
execute as @e[type=minecraft:armor_stand,tag=motion] store result score @s u2 run data get entity @s Pos[2] 1000000
tp @e[type=minecraft:armor_stand,tag=motion,limit=1] @s
ride @e[type=minecraft:armor_stand,tag=motion,limit=1] mount @e[type=minecraft:fireball,limit=1,tag=motion]
tag @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[5.0f]}}}},sort=nearest,limit=1,tag=!snowball] add fireball
tag @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[5.0f]}}}},sort=nearest,limit=1,tag=!snowball] add snowball
tag @e[type=minecraft:armor_stand,tag=motion] remove motion
tag @e[type=minecraft:fireball] remove motion