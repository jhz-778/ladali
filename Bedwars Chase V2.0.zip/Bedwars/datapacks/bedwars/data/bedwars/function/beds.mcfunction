execute as @a if score @s bed_red matches 1.. run function bedwars:beds/red_bed
execute as @a if score @s bed_blue matches 1.. run function bedwars:beds/blue_bed
execute as @a if score @s bed_lime matches 1.. run function bedwars:beds/lime_bed
execute as @a if score @s bed_yellow matches 1.. run function bedwars:beds/yellow_bed