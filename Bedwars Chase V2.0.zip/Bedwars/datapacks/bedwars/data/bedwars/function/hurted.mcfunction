scoreboard players set @s hurt 200
execute if data entity @s {active_effects:[{id:"minecraft:invisibility"}]} run scoreboard players set @s hurt 100
execute if data entity @s {active_effects:[{id:"minecraft:invisibility"}]} run function bedwars:potion/clear