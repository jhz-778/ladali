#战利品与数据
execute store result score @s dummy run clear @a[tag=looting] minecraft:nether_star
execute store result score @s number run clear @a[tag=looting] minecraft:emerald
execute store result score @s custom run clear @a[tag=looting] minecraft:diamond
execute store result score @s amount run clear @a[tag=looting] minecraft:gold_ingot
execute store result score @s count run clear @a[tag=looting] minecraft:iron_ingot
execute if entity @a[tag=looting,tag=die_void] run function bedwars:loot_void
loot give @s[gamemode=!spectator] loot bedwars:loot
execute as @a[tag=looting] store result score @s math run experience query @s levels
scoreboard players set @s math 0
scoreboard players operation @s math += @a[tag=looting] math
execute store result storage minecraft:bedwars EXPER int 1 run scoreboard players get @s math
execute if data storage minecraft:bedwars {Special:{exper:1b}} run function mode:exper/add with storage minecraft:bedwars
scoreboard players reset @a[tag=looting] hid
scoreboard players reset @s tick
execute if entity @s[team=!red] if data storage minecraft:red {bed:0b} store result score @s tick if entity @a[tag=looting,team=red]
scoreboard players operation @s last_kill += @s tick
scoreboard players reset @s tick
execute if entity @s[team=!blue] if data storage minecraft:blue {bed:0b} store result score @s tick if entity @a[tag=looting,team=blue]
scoreboard players operation @s last_kill += @s tick
scoreboard players reset @s tick
execute if entity @s[team=!green] if data storage minecraft:green {bed:0b} store result score @s tick if entity @a[tag=looting,team=green]
scoreboard players operation @s last_kill += @s tick
scoreboard players reset @s tick
execute if entity @s[team=!yellow] if data storage minecraft:yellow {bed:0b} store result score @s tick if entity @a[tag=looting,team=yellow]
scoreboard players operation @s last_kill += @s tick
execute store result score @s tick if entity @a[tag=looting]
scoreboard players operation @s kill += @s tick
execute if score @s kill matches 15.. run advancement grant @s only bedwars:bedwars/killer
#普通击杀
execute if entity @a[tag=looting,tag=die_void,tag=!out] run tellraw @a [{"selector":"@a[tag=looting,tag=die_void,tag=!out]"},{"translate":"title.has","color":"white"},{"selector":"@s"},{"translate":"title.drop.void","color":"white"}]
execute if entity @a[tag=looting,tag=die_bomb,tag=!out] run tellraw @a [{"selector":"@a[tag=looting,tag=die_bomb,tag=!out]"},{"translate":"title.has","color":"white"},{"selector":"@s"},{"translate":"title.bomb","color":"white"}]
execute if entity @a[tag=looting,tag=!die_bomb,tag=!die_void,tag=!die_fish,tag=!out] run tellraw @a [{"selector":"@a[tag=looting,tag=!die_bomb,tag=!die_void,tag=!die_fish,tag=!out]"},{"translate":"title.has","color":"white"},{"selector":"@s"},{"translate":"title.killed","color":"white"}]
#最终击杀
execute if entity @a[tag=looting,tag=die_void,tag=out] run tellraw @a [{"selector":"@a[tag=looting,tag=die_void,tag=out]"},{"translate":"title.has","color":"white"},{"selector":"@s"},{"translate":"title.drop.void","color":"white"},{"text":"   "},{"translate":"warn.death.last","color":"aqua"}]
execute if entity @a[tag=looting,tag=die_bomb,tag=out] run tellraw @a [{"selector":"@a[tag=looting,tag=die_bomb,tag=out]"},{"translate":"title.has","color":"white"},{"selector":"@s"},{"translate":"title.bomb","color":"white"},{"text":"   "},{"translate":"warn.death.last","color":"aqua"}]
execute if entity @a[tag=looting,tag=!die_bomb,tag=!die_void,tag=!die_fish,tag=out] run tellraw @a [{"selector":"@a[tag=looting,tag=!die_bomb,tag=!die_void,tag=!die_fish,tag=out]"},{"translate":"title.has","color":"white"},{"selector":"@s"},{"translate":"title.killed","color":"white"},{"text":"   "},{"translate":"warn.death.last","color":"aqua"}]
#处理
execute if entity @a[tag=looting,tag=die_bomb] run advancement grant @s only bedwars:bedwars/firelord
execute if data storage minecraft:bedwars {Special:{exper:1b}} if score @s math matches 1.. run tellraw @s [{"translate":"argument.entity.options.level.description","color":"green","bold":true},{"text":"*","color":"white"},{"score":{"name":"@s","objective":"math"},"color":"green"}]
execute if score @s dummy matches 1.. run tellraw @s [{"translate":"item.minecraft.nether_star","color":"dark_purple"},{"text":"*","color":"white"},{"score":{"name":"@s","objective":"dummy"},"color":"white"}]
execute if score @s number matches 1.. run tellraw @s [{"translate":"item.minecraft.emerald","color":"dark_green"},{"text":"*","color":"white"},{"score":{"name":"@s","objective":"number"},"color":"white"}]
execute if score @s custom matches 1.. run tellraw @s [{"translate":"item.minecraft.diamond","color":"aqua"},{"text":"*","color":"white"},{"score":{"name":"@s","objective":"custom"},"color":"white"}]
execute if score @s amount matches 1.. run tellraw @s [{"translate":"item.minecraft.gold_ingot","color":"gold"},{"text":"*","color":"white"},{"score":{"name":"@s","objective":"amount"},"color":"white"}]
execute if score @s count matches 1.. run tellraw @s [{"translate":"item.minecraft.iron_ingot","color":"white"},{"text":"*","color":"white"},{"score":{"name":"@s","objective":"count"},"color":"white"}]
tag @a[tag=looting] add die_test
tag @s remove looter