tellraw @s [{"translate":"warn.platform.fail","color":"yellow"}]
tag @s add platform_give