data modify block 2011 82 2022 front_text.messages[2] set value '{"translate":"setting.double","clickEvent":{"action":"run_command","value":"function bedwars:teams_fours"}}'
execute if data storage minecraft:bedwars {team:1b} run setblock 2011 81 2023 minecraft:air destroy
execute if data storage minecraft:bedwars {team:1b} run setblock 2011 81 2019 minecraft:air destroy
execute if data storage minecraft:bedwars {team:1b} run team empty green
execute if data storage minecraft:bedwars {team:1b} run team empty yellow
data merge storage minecraft:bedwars {teams:1b}
playsound minecraft:block.note_block.hat master @a ~ ~ ~ 2 1