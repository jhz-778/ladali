#执行
attribute @s minecraft:scale base set 1.65
attribute @s minecraft:jump_strength base set 0.58
attribute @s minecraft:step_height base set 1
attribute @s minecraft:max_health base set 30
attribute @s minecraft:safe_fall_distance base set 5
attribute @s minecraft:block_interaction_range base set 6
attribute @s minecraft:entity_interaction_range base set 4
effect give @s[nbt=!{active_effects:[{id:"minecraft:luck"}]}] minecraft:instant_health 1 2 true
execute at @s[nbt=!{active_effects:[{id:"minecraft:luck"}]}] run playsound minecraft:entity.player.levelup master @a ~ ~ ~ 0.5 1.5
#时长
execute if score #store_growth_mushroom uid matches 1 run effect give @s minecraft:luck 5 0 false
execute if score #store_growth_mushroom uid matches 2 run effect give @s minecraft:luck 10 0 false
execute if score #store_growth_mushroom uid matches 3 run effect give @s minecraft:luck 15 0 false
execute if score #store_growth_mushroom uid matches 4 run effect give @s minecraft:luck 20 0 false
execute if score #store_growth_mushroom uid matches 5 run effect give @s minecraft:luck 25 0 false
execute if score #store_growth_mushroom uid matches 6 run effect give @s minecraft:luck 30 0 false
execute if score #store_growth_mushroom uid matches 7 run effect give @s minecraft:luck 35 0 false
execute if score #store_growth_mushroom uid matches 8 run effect give @s minecraft:luck 40 0 false
execute if score #store_growth_mushroom uid matches 9 run effect give @s minecraft:luck 45 0 false
execute if score #store_growth_mushroom uid matches 10 run effect give @s minecraft:luck 50 0 false
execute if score #store_growth_mushroom uid matches 11 run effect give @s minecraft:luck 55 0 false
execute if score #store_growth_mushroom uid matches 12 run effect give @s minecraft:luck 60 0 false
execute if score #store_growth_mushroom uid matches 13 run effect give @s minecraft:luck 65 0 false
execute if score #store_growth_mushroom uid matches 14 run effect give @s minecraft:luck 70 0 false
execute if score #store_growth_mushroom uid matches 15 run effect give @s minecraft:luck 75 0 false
execute if score #store_growth_mushroom uid matches 16 run effect give @s minecraft:luck 80 0 false
execute if score #store_growth_mushroom uid matches 17 run effect give @s minecraft:luck 85 0 false
execute if score #store_growth_mushroom uid matches 18 run effect give @s minecraft:luck 90 0 false
execute if data storage minecraft:bedwars {mode:3b} run function mode:super_chase/attribute
advancement revoke @s only bedwars:prop/mushroom_growth