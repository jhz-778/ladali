execute store result score @s u0 run data get entity @s Pos[0]
execute store result score @s u2 run data get entity @s Pos[2]
execute unless data storage minecraft:bedwars {mode:1b} unless entity @a[distance=..4,gamemode=!spectator] if score @s u0 matches -99..99 if score @s u2 matches -99..99 run function bedwars:egg_wool
execute if data storage minecraft:bedwars {mode:1b} unless entity @a[distance=..4,gamemode=!spectator] if score @s u0 matches -60..60 if score @s u2 matches -185..185 run function bedwars:egg_wool
execute unless predicate bedwars:egg at @s run function bedwars:egg_chicken