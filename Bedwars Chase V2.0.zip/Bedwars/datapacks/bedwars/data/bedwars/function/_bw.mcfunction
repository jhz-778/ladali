execute as @a unless score @s uid = @s uid run function bedwars:_tick
execute store result score #player tick if entity @a
execute unless score #player tick = #player amount run function bedwars:_player
scoreboard players remove @a[scores={title=1..}] title 1
execute as @a[scores={fish=1..}] at @s run function bedwars:fish
execute as @e[type=minecraft:arrow,tag=fishing] unless predicate bedwars:fishing run kill @s
execute as @a[scores={ice=1..}] run function bedwars:iced
execute as @a[scores={egg=1..}] at @s run function bedwars:egg
execute as @a[scores={snowball=1..}] at @s run function bedwars:snowball
execute as @a[scores={exp=1..}] at @s run function bedwars:exper
scoreboard players remove @a[scores={phdi=1..}] phdi 1
execute as @a[scores={chest=1..}] at @s anchored eyes run function bedwars:chest
execute unless data storage minecraft:bedwars {start:1b} as @a[scores={woodchest=1..}] run scoreboard players set @s gui -100
scoreboard players set @a[scores={woodchest=1..}] woodchest 0
execute unless data storage minecraft:bedwars {start:1b} as @a if score @s gui matches -100 run function gui:_control/_set
execute as @a run function gui:_gui
execute if data storage minecraft:bedwars {start:1b} run function bedwars:_game
scoreboard players set @a[scores={throw=1..}] throw 0
scoreboard players remove @a[scores={hurt=1..}] hurt 1
execute as @a if score @s hurt matches 1 run function bedwars:hurt
execute as @e[type=minecraft:marker,tag=iced] at @s run function bedwars:iceding
execute as @e[type=minecraft:marker,tag=pearl] run function bedwars:pearl_test
execute as @e[type=minecraft:armor_stand,tag=tick_ride] unless predicate bedwars:ride at @s run function bedwars:tick_ride
execute as @e[type=minecraft:armor_stand,tag=egg] at @s run function bedwars:egg_build
execute as @e[type=minecraft:armor_stand,tag=basketball] unless predicate bedwars:arrow run kill @s