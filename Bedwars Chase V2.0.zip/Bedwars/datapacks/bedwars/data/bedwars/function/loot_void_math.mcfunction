execute store result score @s count run data get entity @s Item.count
execute if data entity @s {Item:{id:"minecraft:nether_star"}} run scoreboard players operation @a[tag=looter,limit=1] dummy += @s count
execute if data entity @s {Item:{id:"minecraft:emerald"}} run scoreboard players operation @a[tag=looter,limit=1] number += @s count
execute if data entity @s {Item:{id:"minecraft:diamond"}} run scoreboard players operation @a[tag=looter,limit=1] custom += @s count
execute if data entity @s {Item:{id:"minecraft:gold_ingot"}} run scoreboard players operation @a[tag=looter,limit=1] amount += @s count
execute if data entity @s {Item:{id:"minecraft:iron_ingot"}} run scoreboard players operation @a[tag=looter,limit=1] count += @s count
kill @s