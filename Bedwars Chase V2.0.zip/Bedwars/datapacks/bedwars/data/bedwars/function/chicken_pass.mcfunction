execute if entity @s[team=red] facing entity @a[sort=nearest,limit=1,team=!red,distance=..15,gamemode=!spectator] eyes run tp @s ~ ~ ~ ~ ~
execute if entity @s[team=blue] facing entity @a[sort=nearest,limit=1,team=!blue,distance=..15,gamemode=!spectator] eyes run tp @s ~ ~ ~ ~ ~
execute if entity @s[team=green] facing entity @a[sort=nearest,limit=1,team=!green,distance=..15,gamemode=!spectator] eyes run tp @s ~ ~ ~ ~ ~
execute if entity @s[team=yellow] facing entity @a[sort=nearest,limit=1,team=!yellow,distance=..15,gamemode=!spectator] eyes run tp @s ~ ~ ~ ~ ~
summon minecraft:arrow ~ ~0.25 ~ {damage:0.1d,Tags:["motion"]}
data modify entity @e[type=minecraft:arrow,limit=1,tag=motion] Owner set from entity @s ArmorItems[3].components."minecraft:custom_data".Owner
summon minecraft:marker ~ ~ ~ {Tags:["motion"]}
tag @s add eggmotion
execute as @e[type=minecraft:marker,tag=motion] run tp @s 0.0 0.0 0.0
execute as @e[type=minecraft:marker,tag=motion] at @s rotated as @e[type=minecraft:chicken,tag=eggmotion,limit=1,sort=nearest] run tp @s ^ ^ ^1.5
tag @s remove eggmotion
data modify entity @e[type=minecraft:arrow,limit=1,tag=motion] Motion set from entity @e[type=minecraft:marker,limit=1,tag=motion] Pos
tag @e[type=minecraft:arrow] remove motion
kill @e[type=minecraft:marker,tag=motion]
scoreboard players add @s egg 1
tag @s remove cxk_pass
execute if score @s egg matches 15.. run function bedwars:chicken_bomb