scoreboard players remove @s block 1
execute if score @s block matches 0 run tag @s remove blocking