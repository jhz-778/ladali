execute if data storage minecraft:bedwars {start:1b} run damage @s[gamemode=!spectator] 1024 minecraft:generic_kill by @e[type=minecraft:iron_golem,limit=1,tag=npc]
execute if data storage minecraft:bedwars {start:1b} run tag @s add die_void
effect give @s minecraft:slow_falling 2 0 true
execute if data storage minecraft:bedwars {win:0b} unless data storage minecraft:bedwars {start:0b} run function bedwars:_death
tag @s remove die_void
execute unless data storage minecraft:bedwars {win:0b} unless data storage minecraft:bedwars {start:0b} run tp @s 0 112 0
execute if data storage minecraft:bedwars {start:0b} run tp @s 2019 89 2005