scoreboard players set @s tip 0
execute if entity @e[tag=team_red,type=minecraft:marker,distance=..25] if entity @s[team=!red] if data storage minecraft:red {out:0b} run function bedwars:chest/rc
execute if entity @e[tag=team_blue,type=minecraft:marker,distance=..25] if entity @s[team=!blue] if data storage minecraft:blue {out:0b} run function bedwars:chest/bc
execute if entity @e[tag=team_green,type=minecraft:marker,distance=..25] if entity @s[team=!green] if data storage minecraft:green {out:0b} run function bedwars:chest/gc
execute if entity @e[tag=team_yellow,type=minecraft:marker,distance=..25] if entity @s[team=!yellow] if data storage minecraft:yellow {out:0b} run function bedwars:chest/yc