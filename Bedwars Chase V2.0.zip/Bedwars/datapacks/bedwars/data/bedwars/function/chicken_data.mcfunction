attribute @s minecraft:max_health base set 15
data merge entity @s {Age:-9999999,ArmorDropChances:[0.0f,0.0f,0.0f,0.0f],Health:15.0f}
tag @s add endclear
tag @s add cxk