function bedwars:resource/resource_red
function bedwars:resource/resource_blue
execute if data storage minecraft:bedwars {teams:0b} run function bedwars:resource/resource_green
execute if data storage minecraft:bedwars {teams:0b} run function bedwars:resource/resource_yellow