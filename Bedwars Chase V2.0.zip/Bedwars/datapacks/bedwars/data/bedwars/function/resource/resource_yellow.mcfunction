#计时
scoreboard players add #yellow_resource count 1
scoreboard players add #yellow_resource amount 1
scoreboard players add #yellow_resource custom 1
#计数
scoreboard players set #yellow_point count 0
scoreboard players set #yellow_point amount 0
scoreboard players set #yellow_point custom 0
execute at @e[type=minecraft:marker,tag=resource_yellow] as @e[type=minecraft:item,distance=..3,nbt={Item:{components:{"minecraft:custom_data":{resource:1b}}}}] store result score @s math run data get entity @s Item.count
execute at @e[type=minecraft:marker,tag=resource_yellow] run scoreboard players operation #yellow_point count += @e[type=minecraft:item,distance=..3,nbt={Item:{id:"minecraft:iron_ingot",components:{"minecraft:custom_data":{resource:1b}}}}] math
execute at @e[type=minecraft:marker,tag=resource_yellow] run scoreboard players operation #yellow_point amount += @e[type=minecraft:item,distance=..3,nbt={Item:{id:"minecraft:gold_ingot",components:{"minecraft:custom_data":{resource:1b}}}}] math
execute at @e[type=minecraft:marker,tag=resource_yellow] run scoreboard players operation #yellow_point custom += @e[type=minecraft:item,distance=..3,nbt={Item:{id:"minecraft:emerald",components:{"minecraft:custom_data":{resource:1b}}}}] math
#生成
execute unless score #yellow_resource tick matches 1.. if score #yellow_point count matches ..71 if score #yellow_resource count matches 2.. at @e[type=minecraft:marker,tag=resource_yellow] run loot spawn ~ ~ ~ loot bedwars:resource/iron_ingot
execute if score #yellow_resource tick matches 1.. if score #yellow_point count matches ..71 at @e[type=minecraft:marker,tag=resource_yellow] run loot spawn ~ ~ ~ loot bedwars:resource/iron_ingot
execute unless score #yellow_resource tick matches 2.. if score #yellow_point amount matches ..11 if score #yellow_resource amount matches 12.. at @e[type=minecraft:marker,tag=resource_yellow] run loot spawn ~ ~ ~ loot bedwars:resource/gold_ingot
execute if score #yellow_resource tick matches 2.. if score #yellow_point amount matches ..11 if score #yellow_resource amount matches 6.. at @e[type=minecraft:marker,tag=resource_yellow] run loot spawn ~ ~ ~ loot bedwars:resource/gold_ingot
execute if score #yellow_resource tick matches 3 if score #yellow_point custom matches ..1 if score #yellow_resource custom matches 80.. at @e[type=minecraft:marker,tag=resource_yellow] run loot spawn ~ ~ ~ loot bedwars:resource/emerald
execute if score #yellow_resource tick matches 4.. if score #yellow_point custom matches ..1 if score #yellow_resource custom matches 50.. at @e[type=minecraft:marker,tag=resource_yellow] run loot spawn ~ ~ ~ loot bedwars:resource/emerald
#处理
execute if score #yellow_resource count matches 2.. run scoreboard players set #yellow_resource count 0
execute unless score #yellow_resource tick matches 2.. if score #yellow_resource amount matches 12.. run scoreboard players set #yellow_resource amount 0
execute if score #yellow_resource tick matches 2.. if score #yellow_resource amount matches 6.. run scoreboard players set #yellow_resource amount 0
execute if score #yellow_resource tick matches 3 if score #yellow_resource custom matches 80.. run scoreboard players set #yellow_resource custom 0
execute if score #yellow_resource tick matches 4.. if score #yellow_resource custom matches 50.. run scoreboard players set #yellow_resource custom 0