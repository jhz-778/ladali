execute if score #diamond_tier tick matches 1 run scoreboard players set #diamond tick 40
execute if score #diamond_tier tick matches 2 run scoreboard players set #diamond tick 30
execute if score #diamond_tier tick matches 3 run scoreboard players set #diamond tick 20
execute as @e[type=minecraft:armor_stand,tag=diamond] at @s store result score @s number run data get entity @e[type=minecraft:item,sort=nearest,limit=1,distance=..3,nbt={Item:{id:"minecraft:diamond",components:{"minecraft:custom_data":{resource:1b}}}}] Item.count
execute as @e[type=minecraft:armor_stand,tag=diamond] if score @s number matches ..3 at @s run summon minecraft:item ~ ~1.4 ~ {PickupDelay:10s,Invulnerable:1b,Item:{id:"minecraft:diamond",count:1b,components:{"minecraft:custom_data":{resource:1b}}}}