execute unless data storage minecraft:bedwars {Special:{exper:1b}} run function bedwars:resource/normal
execute if data storage minecraft:bedwars {Special:{exper:1b}} run function mode:exper/loot
advancement revoke @s only bedwars:game/resource