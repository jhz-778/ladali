execute if score #emerald_tier tick matches 1 run scoreboard players set #emerald tick 60
execute if score #emerald_tier tick matches 2 run scoreboard players set #emerald tick 45
execute if score #emerald_tier tick matches 3 run scoreboard players set #emerald tick 30
execute as @e[type=minecraft:armor_stand,tag=emerald] at @s store result score @s number run data get entity @e[type=minecraft:item,sort=nearest,limit=1,distance=..3,nbt={Item:{id:"minecraft:emerald",components:{"minecraft:custom_data":{resource:1b}}}}] Item.count
execute as @e[type=minecraft:armor_stand,tag=emerald] if score @s number matches ..1 at @s run summon minecraft:item ~ ~1.4 ~ {PickupDelay:10s,Invulnerable:1b,Item:{id:"minecraft:emerald",count:1b,components:{"minecraft:custom_data":{resource:1b}}}}
execute as @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_data":{resource:1b}}}}] run data modify entity @s Age set value 0s