execute store result score @s count run clear @s minecraft:iron_ingot[minecraft:custom_data={resource:1b}]
execute store result score @s amount run clear @s minecraft:gold_ingot[minecraft:custom_data={resource:1b}]
scoreboard players operation @a[distance=..1.5] count = @s count
scoreboard players operation @a[distance=..1.5] amount = @s amount
loot give @a[distance=..1.5] loot bedwars:resource/loot
execute store result score @s count run clear @s minecraft:diamond[minecraft:custom_data={resource:1b}]
execute store result score @s amount run clear @s minecraft:emerald[minecraft:custom_data={resource:1b}]
execute store result score @s number run clear @s minecraft:nether_star[minecraft:custom_data={resource:1b}]
loot give @s loot bedwars:resource/loots