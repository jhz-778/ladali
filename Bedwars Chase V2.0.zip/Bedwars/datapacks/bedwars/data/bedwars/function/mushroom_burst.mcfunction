#时长
execute if score #store_burst_mushroom uid matches 1 run effect give @s minecraft:raid_omen 5 0 false
execute if score #store_burst_mushroom uid matches 2 run effect give @s minecraft:raid_omen 10 0 false
execute if score #store_burst_mushroom uid matches 3 run effect give @s minecraft:raid_omen 15 0 false
execute if score #store_burst_mushroom uid matches 4 run effect give @s minecraft:raid_omen 20 0 false
execute if score #store_burst_mushroom uid matches 5 run effect give @s minecraft:raid_omen 25 0 false
execute if score #store_burst_mushroom uid matches 6 run effect give @s minecraft:raid_omen 30 0 false
execute if score #store_burst_mushroom uid matches 7 run effect give @s minecraft:raid_omen 35 0 false
execute if score #store_burst_mushroom uid matches 8 run effect give @s minecraft:raid_omen 40 0 false
execute if score #store_burst_mushroom uid matches 9 run effect give @s minecraft:raid_omen 45 0 false
execute if score #store_burst_mushroom uid matches 10 run effect give @s minecraft:raid_omen 50 0 false
execute if score #store_burst_mushroom uid matches 11 run effect give @s minecraft:raid_omen 55 0 false
execute if score #store_burst_mushroom uid matches 12 run effect give @s minecraft:raid_omen 60 0 false
execute if score #store_burst_mushroom uid matches 13 run effect give @s minecraft:raid_omen 65 0 false
execute if score #store_burst_mushroom uid matches 14 run effect give @s minecraft:raid_omen 70 0 false
execute if score #store_burst_mushroom uid matches 15 run effect give @s minecraft:raid_omen 75 0 false
execute if score #store_burst_mushroom uid matches 16 run effect give @s minecraft:raid_omen 80 0 false
execute if score #store_burst_mushroom uid matches 17 run effect give @s minecraft:raid_omen 85 0 false
execute if score #store_burst_mushroom uid matches 18 run effect give @s minecraft:raid_omen 90 0 false
#执行
attribute @s minecraft:attack_damage base set 2.25
attribute @s minecraft:block_break_speed base set 1.5
attribute @s minecraft:knockback_resistance base set 0.5
execute if data storage minecraft:bedwars {combat:0b} run attribute @s minecraft:attack_speed base set 5.0
execute if data storage minecraft:bedwars {combat:1b} run attribute @s minecraft:attack_speed base set 20.0
attribute @s minecraft:movement_speed base set 0.13
execute unless data entity @s {active_effects:[{id:"minecraft:luck"}]} run attribute @s minecraft:entity_interaction_range base set 3.75
execute if data storage minecraft:bedwars {mode:3b} run function mode:super_chase/attribute
advancement revoke @s only bedwars:prop/mushroom_burst