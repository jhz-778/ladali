execute if entity @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[4.0f]}}}},sort=nearest,limit=1,tag=!snowball] at @s run function bedwars:silverfish
execute if entity @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[5.0f]}}}},sort=nearest,limit=1,tag=!snowball] at @s run function bedwars:fireball
execute if entity @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[6.0f]}}}},sort=nearest,limit=1,tag=!snowball] at @s run function bedwars:pearl/ender
execute if entity @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[7.0f]}}}},sort=nearest,limit=1,tag=!snowball] at @s run function bedwars:pearl/back
execute if entity @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[8.0f]}}}},sort=nearest,limit=1,tag=!snowball] at @s run function bedwars:pearl/move
execute if entity @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[9.0f]}}}},sort=nearest,limit=1,tag=!snowball] at @s run function bedwars:pearl/teleport
execute if entity @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_model_data":{floats:[13.0f]}}}},sort=nearest,limit=1,tag=!snowball] at @s run function bedwars:rock
scoreboard players set @s snowball 0