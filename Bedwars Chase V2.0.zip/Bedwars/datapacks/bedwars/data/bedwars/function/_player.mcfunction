execute if score #player tick > #player amount run function bedwars:player_add
execute if score #player tick < #player amount run function bedwars:player_remove
scoreboard players operation #player amount = #player tick
execute if data storage minecraft:bedwars {start:1b} run function bedwars:_list