tellraw @s [{"translate":"warn.ice.fail","color":"yellow"}]
execute unless predicate bedwars:empty run loot give @s loot gui:store/ice
execute if predicate bedwars:empty run loot replace entity @s weapon.mainhand loot gui:store/ice