tag @s add die_fish
advancement revoke @s only bedwars:game/fish