execute as @a at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 0.5
tellraw @a [{"translate":"text.start.fail","color":"red","bold":true}]
setblock 2018 81 2034 minecraft:air replace
setblock 2018 81 2034 minecraft:lever[face=wall,facing=north,powered=false] replace