item replace entity @s enderchest.26 from entity @s enderchest.11
execute if data entity @s {EnderItems:[{Slot:26b}]} run function gui:item_replace
clear @s *[minecraft:custom_data={gui:1b}]
kill @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_data":{gui:1b}}}}]
loot replace entity @s enderchest.26 loot gui:gui_pane
execute if score @s gui matches -1 run loot replace entity @s enderchest.26 loot gui:gui_pane_visible
loot replace entity @s enderchest.11 loot gui:gui_pane
tag @s add fix