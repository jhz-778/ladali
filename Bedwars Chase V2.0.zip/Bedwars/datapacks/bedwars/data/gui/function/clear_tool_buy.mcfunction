#镐类
loot replace block 2012 75 2004 container.0 loot gui:gui_pane
loot replace block 2012 75 2004 container.1 loot gui:gui_pane
loot replace block 2012 75 2004 container.2 loot gui:gui_pane
loot replace block 2012 75 2004 container.3 loot gui:gui_pane
loot replace block 2012 75 2004 container.4 loot gui:gui_pane
#镐类
loot replace block 2014 75 2004 container.0 loot gui:gui_pane
loot replace block 2014 75 2004 container.1 loot gui:gui_pane
loot replace block 2014 75 2004 container.2 loot gui:gui_pane
loot replace block 2014 75 2004 container.3 loot gui:gui_pane
loot replace block 2014 75 2004 container.4 loot gui:gui_pane
#镐类
loot replace block 2016 75 2004 container.0 loot gui:gui_pane
loot replace block 2016 75 2004 container.1 loot gui:gui_pane
loot replace block 2016 75 2004 container.2 loot gui:gui_pane
loot replace block 2016 75 2004 container.3 loot gui:gui_pane
loot replace block 2016 75 2004 container.4 loot gui:gui_pane