execute if score #store dummy matches -1 run item modify block 2026 99 1997 container.0 gui:money/diamond
execute if score #store dummy matches 0 run item modify block 2026 99 1997 container.0 gui:money/nether_star
execute if score #store dummy matches 1 run item modify block 2026 99 1997 container.0 gui:money/iron_ingot
execute if score #store dummy matches 2 run item modify block 2026 99 1997 container.0 gui:money/gold_ingot
execute if score #store dummy matches 3 run item modify block 2026 99 1997 container.0 gui:money/emerald
execute if score #store limit matches 1.. run item modify block 2026 99 1997 container.0 gui:money/limit