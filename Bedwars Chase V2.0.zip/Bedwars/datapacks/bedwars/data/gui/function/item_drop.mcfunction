summon minecraft:item ~ ~ ~ {Owner:[I;0,0,0,0],Item:{id:"minecraft:stone",count:1b},Tags:["drop"],PickupDelay:0s}
data modify entity @e[type=minecraft:item,sort=nearest,limit=1,tag=drop] Item.id set from entity @s EnderItems[26].id
data modify entity @e[type=minecraft:item,sort=nearest,limit=1,tag=drop] Item.components set from entity @s EnderItems[26].components
data modify entity @e[type=minecraft:item,sort=nearest,limit=1,tag=drop] Item.count set from entity @s EnderItems[26].count
data modify entity @e[type=minecraft:item,sort=nearest,limit=1,tag=drop] Owner set from entity @s UUID
tag @e[type=minecraft:item] remove drop