#石剑
loot replace block 2026 99 1997 container.0 loot gui:normal/stone_sword
execute if score #store_stone_sword tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_stone_sword number
scoreboard players operation #store dummy = #store_stone_sword dummy
scoreboard players operation #store limit = #store_stone_sword limit
execute unless score #store_stone_sword tick matches 1 run function gui:_exper
item replace block 2016 77 2008 container.0 from block 2026 99 1997 container.0
#铁剑
loot replace block 2026 99 1997 container.0 loot gui:normal/iron_sword
execute if score #store_iron_sword tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_iron_sword number
scoreboard players operation #store dummy = #store_iron_sword dummy
scoreboard players operation #store limit = #store_iron_sword limit
execute unless score #store_iron_sword tick matches 1 run function gui:_exper
item replace block 2016 77 2008 container.1 from block 2026 99 1997 container.0
#钻石剑
loot replace block 2026 99 1997 container.0 loot gui:normal/diamond_sword
execute if score #store_diamond_sword tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_diamond_sword number
scoreboard players operation #store dummy = #store_diamond_sword dummy
scoreboard players operation #store limit = #store_diamond_sword limit
execute unless score #store_diamond_sword tick matches 1 run function gui:_exper
item replace block 2016 77 2008 container.2 from block 2026 99 1997 container.0
#下界合金剑
loot replace block 2026 99 1997 container.0 loot gui:normal/netherite_sword
execute if score #store_netherite_sword tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_netherite_sword number
scoreboard players operation #store dummy = #store_netherite_sword dummy
scoreboard players operation #store limit = #store_netherite_sword limit
execute unless score #store_netherite_sword tick matches 1 run function gui:_exper
item replace block 2016 77 2008 container.3 from block 2026 99 1997 container.0
#击退棒
loot replace block 2026 99 1997 container.0 loot gui:normal/knockback_stick
execute if score #store_knockback_stick tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_knockback_stick number
scoreboard players operation #store dummy = #store_knockback_stick dummy
scoreboard players operation #store limit = #store_knockback_stick limit
execute unless score #store_knockback_stick tick matches 1 run function gui:_exper
item replace block 2016 77 2008 container.4 from block 2026 99 1997 container.0
#重锤
loot replace block 2026 99 1997 container.0 loot gui:normal/mace
execute if score #store_mace tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_mace number
scoreboard players operation #store dummy = #store_mace dummy
scoreboard players operation #store limit = #store_mace limit
execute unless score #store_mace tick matches 1 run function gui:_exper
item replace block 2016 77 2008 container.9 from block 2026 99 1997 container.0
#钓鱼竿
loot replace block 2026 99 1997 container.0 loot gui:normal/fishing_rod
execute if score #store_fishing_rod tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_fishing_rod number
scoreboard players operation #store dummy = #store_fishing_rod dummy
scoreboard players operation #store limit = #store_fishing_rod limit
execute unless score #store_fishing_rod tick matches 1 run function gui:_exper
item replace block 2016 77 2008 container.10 from block 2026 99 1997 container.0
#秒人斧
loot replace block 2026 99 1997 container.0 loot gui:normal/miaoren_axe
execute if score #store_miaoren_axe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_miaoren_axe number
scoreboard players operation #store dummy = #store_miaoren_axe dummy
scoreboard players operation #store limit = #store_miaoren_axe limit
execute unless score #store_miaoren_axe tick matches 1 run function gui:_exper
item replace block 2016 77 2008 container.11 from block 2026 99 1997 container.0

#普通弓
loot replace block 2026 99 1997 container.0 loot gui:normal/bow1
execute if score #store_bow1 tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_bow1 number
scoreboard players operation #store dummy = #store_bow1 dummy
scoreboard players operation #store limit = #store_bow1 limit
execute unless score #store_bow1 tick matches 1 run function gui:_exper
item replace block 2014 77 2008 container.0 from block 2026 99 1997 container.0
#力量弓
loot replace block 2026 99 1997 container.0 loot gui:normal/bow2
execute if score #store_bow2 tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_bow2 number
scoreboard players operation #store dummy = #store_bow2 dummy
scoreboard players operation #store limit = #store_bow2 limit
execute unless score #store_bow2 tick matches 1 run function gui:_exper
item replace block 2014 77 2008 container.1 from block 2026 99 1997 container.0
#冲击弓
loot replace block 2026 99 1997 container.0 loot gui:normal/bow3
execute if score #store_bow3 tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_bow3 number
scoreboard players operation #store dummy = #store_bow3 dummy
scoreboard players operation #store limit = #store_bow3 limit
execute unless score #store_bow3 tick matches 1 run function gui:_exper
item replace block 2014 77 2008 container.2 from block 2026 99 1997 container.0
#普通弩
loot replace block 2026 99 1997 container.0 loot gui:normal/crossbow1
execute if score #store_crossbow1 tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_crossbow1 number
scoreboard players operation #store dummy = #store_crossbow1 dummy
scoreboard players operation #store limit = #store_crossbow1 limit
execute unless score #store_crossbow1 tick matches 1 run function gui:_exper
item replace block 2014 77 2008 container.3 from block 2026 99 1997 container.0
#迅捷弩
loot replace block 2026 99 1997 container.0 loot gui:normal/crossbow2
execute if score #store_crossbow2 tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_crossbow2 number
scoreboard players operation #store dummy = #store_crossbow2 dummy
scoreboard players operation #store limit = #store_crossbow2 limit
execute unless score #store_crossbow2 tick matches 1 run function gui:_exper
item replace block 2014 77 2008 container.4 from block 2026 99 1997 container.0
#穿透弩
loot replace block 2026 99 1997 container.0 loot gui:normal/crossbow3
execute if score #store_crossbow3 tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_crossbow3 number
scoreboard players operation #store dummy = #store_crossbow3 dummy
scoreboard players operation #store limit = #store_crossbow3 limit
execute unless score #store_crossbow3 tick matches 1 run function gui:_exper
item replace block 2014 77 2008 container.5 from block 2026 99 1997 container.0
#多重弩
loot replace block 2026 99 1997 container.0 loot gui:normal/crossbow4
execute if score #store_crossbow4 tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_crossbow4 number
scoreboard players operation #store dummy = #store_crossbow4 dummy
scoreboard players operation #store limit = #store_crossbow4 limit
execute unless score #store_crossbow4 tick matches 1 run function gui:_exper
item replace block 2014 77 2008 container.6 from block 2026 99 1997 container.0
#普通箭
loot replace block 2026 99 1997 container.0 loot gui:normal/arrow
execute if score #store_arrow tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_arrow number
scoreboard players operation #store dummy = #store_arrow dummy
scoreboard players operation #store limit = #store_arrow limit
execute unless score #store_arrow tick matches 1 run function gui:_exper
item replace block 2014 77 2008 container.9 from block 2026 99 1997 container.0
#光灵箭
loot replace block 2026 99 1997 container.0 loot gui:normal/arrow_spectral
execute if score #store_arrow_spectral tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_arrow_spectral number
scoreboard players operation #store dummy = #store_arrow_spectral dummy
scoreboard players operation #store limit = #store_arrow_spectral limit
execute unless score #store_arrow_spectral tick matches 1 run function gui:_exper
item replace block 2014 77 2008 container.10 from block 2026 99 1997 container.0
#药箭
loot replace block 2026 99 1997 container.0 loot gui:normal/arrow_potion
execute if score #store_arrow_potion tick matches 7 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_arrow_potion number
scoreboard players operation #store dummy = #store_arrow_potion dummy
scoreboard players operation #store limit = #store_arrow_potion limit
execute unless score #store_arrow_potion tick matches 7 run function gui:_exper
item replace block 2014 77 2008 container.11 from block 2026 99 1997 container.0
#烟花火箭
loot replace block 2026 99 1997 container.0 loot gui:normal/firework
execute if score #store_firework tick matches 3 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_firework number
scoreboard players operation #store dummy = #store_firework dummy
scoreboard players operation #store limit = #store_firework limit
execute unless score #store_firework tick matches 3 run function gui:_exper
item replace block 2014 77 2008 container.12 from block 2026 99 1997 container.0
#飞镖
loot replace block 2026 99 1997 container.0 loot gui:normal/dart
execute if score #store_dart tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_dart number
scoreboard players operation #store dummy = #store_dart dummy
scoreboard players operation #store limit = #store_dart limit
execute unless score #store_dart tick matches 1 run function gui:_exper
item replace block 2014 77 2008 container.13 from block 2026 99 1997 container.0

#剪刀
loot replace block 2026 99 1997 container.0 loot gui:normal/shears
execute if score #store_shears tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_shears number
scoreboard players operation #store dummy = #store_shears dummy
scoreboard players operation #store limit = #store_shears limit
execute unless score #store_shears tick matches 1 run function gui:_exper
item replace block 2014 77 2004 container.0 from block 2026 99 1997 container.0
#不死图腾
loot replace block 2026 99 1997 container.0 loot gui:normal/totem
execute if score #store_totem tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_totem number
scoreboard players operation #store dummy = #store_totem dummy
scoreboard players operation #store limit = #store_totem limit
execute unless score #store_totem tick matches 1 run function gui:_exper
item replace block 2014 77 2004 container.1 from block 2026 99 1997 container.0
#望远镜
loot replace block 2026 99 1997 container.0 loot gui:normal/spyglass
execute if score #store_spyglass tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_spyglass number
scoreboard players operation #store dummy = #store_spyglass dummy
scoreboard players operation #store limit = #store_spyglass limit
execute unless score #store_spyglass tick matches 1 run function gui:_exper
item replace block 2014 77 2004 container.2 from block 2026 99 1997 container.0
#打火石
loot replace block 2026 99 1997 container.0 loot gui:normal/flint
execute if score #store_flint tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_flint number
scoreboard players operation #store dummy = #store_flint dummy
scoreboard players operation #store limit = #store_flint limit
execute unless score #store_flint tick matches 1 run function gui:_exper
item replace block 2014 77 2004 container.3 from block 2026 99 1997 container.0
#鞘翅
loot replace block 2026 99 1997 container.0 loot gui:normal/elytra
execute if score #store_elytra tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_elytra number
scoreboard players operation #store dummy = #store_elytra dummy
scoreboard players operation #store limit = #store_elytra limit
execute unless score #store_elytra tick matches 1 run function gui:_exper
item replace block 2014 77 2004 container.4 from block 2026 99 1997 container.0

#羊毛
loot replace block 2026 99 1997 container.0 loot gui:normal/wool
execute if score #store_wool tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_wool number
scoreboard players operation #store dummy = #store_wool dummy
scoreboard players operation #store limit = #store_wool limit
execute unless score #store_wool tick matches 1 run function gui:_exper
item replace block 2012 77 2008 container.0 from block 2026 99 1997 container.0
#木板
loot replace block 2026 99 1997 container.0 loot gui:normal/planks
execute if score #store_planks tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_planks number
scoreboard players operation #store dummy = #store_planks dummy
scoreboard players operation #store limit = #store_planks limit
execute unless score #store_planks tick matches 1 run function gui:_exper
item replace block 2012 77 2008 container.1 from block 2026 99 1997 container.0
#混凝沙
loot replace block 2026 99 1997 container.0 loot gui:normal/powder
execute if score #store_powder tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_powder number
scoreboard players operation #store dummy = #store_powder dummy
scoreboard players operation #store limit = #store_powder limit
execute unless score #store_powder tick matches 1 run function gui:_exper
item replace block 2012 77 2008 container.2 from block 2026 99 1997 container.0
#混凝土
loot replace block 2026 99 1997 container.0 loot gui:normal/concrete
execute if score #store_concrete tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_concrete number
scoreboard players operation #store dummy = #store_concrete dummy
scoreboard players operation #store limit = #store_concrete limit
execute unless score #store_concrete tick matches 1 run function gui:_exper
item replace block 2012 77 2008 container.3 from block 2026 99 1997 container.0
#深板岩圆石
loot replace block 2026 99 1997 container.0 loot gui:normal/deepslate
execute if score #store_deepslate tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_deepslate number
scoreboard players operation #store dummy = #store_deepslate dummy
scoreboard players operation #store limit = #store_deepslate limit
execute unless score #store_deepslate tick matches 1 run function gui:_exper
item replace block 2012 77 2008 container.4 from block 2026 99 1997 container.0
#防爆玻璃
loot replace block 2026 99 1997 container.0 loot gui:normal/glass
execute if score #store_glass tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_glass number
scoreboard players operation #store dummy = #store_glass dummy
scoreboard players operation #store limit = #store_glass limit
execute unless score #store_glass tick matches 1 run function gui:_exper
item replace block 2012 77 2008 container.5 from block 2026 99 1997 container.0
#梯子
loot replace block 2026 99 1997 container.0 loot gui:normal/ladder
execute if score #store_ladder tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_ladder number
scoreboard players operation #store dummy = #store_ladder dummy
scoreboard players operation #store limit = #store_ladder limit
execute unless score #store_ladder tick matches 1 run function gui:_exper
item replace block 2012 77 2008 container.6 from block 2026 99 1997 container.0
#黑曜石
loot replace block 2026 99 1997 container.0 loot gui:normal/obsidian
execute if score #store_obsidian tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_obsidian number
scoreboard players operation #store dummy = #store_obsidian dummy
scoreboard players operation #store limit = #store_obsidian limit
execute unless score #store_obsidian tick matches 1 run function gui:_exper
item replace block 2012 77 2008 container.7 from block 2026 99 1997 container.0
#强化深板岩
loot replace block 2026 99 1997 container.0 loot gui:normal/reinforced
execute if score #store_reinforced tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_reinforced number
scoreboard players operation #store dummy = #store_reinforced dummy
scoreboard players operation #store limit = #store_reinforced limit
execute unless score #store_reinforced tick matches 1 run function gui:_exper
item replace block 2012 77 2008 container.8 from block 2026 99 1997 container.0
#蜘蛛网
loot replace block 2026 99 1997 container.0 loot gui:normal/cobweb
execute if score #store_cobweb tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_cobweb number
scoreboard players operation #store dummy = #store_cobweb dummy
scoreboard players operation #store limit = #store_cobweb limit
execute unless score #store_cobweb tick matches 1 run function gui:_exper
item replace block 2012 77 2008 container.9 from block 2026 99 1997 container.0
#箱子
loot replace block 2026 99 1997 container.0 loot gui:normal/chest
execute if score #store_chest tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_chest number
scoreboard players operation #store dummy = #store_chest dummy
scoreboard players operation #store limit = #store_chest limit
execute unless score #store_chest tick matches 1 run function gui:_exper
item replace block 2012 77 2008 container.10 from block 2026 99 1997 container.0
#宝藏桶
loot replace block 2026 99 1997 container.0 loot gui:normal/barrel
execute if score #store_barrel tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_barrel number
scoreboard players operation #store dummy = #store_barrel dummy
scoreboard players operation #store limit = #store_barrel limit
execute unless score #store_barrel tick matches 1 run function gui:_exper
item replace block 2012 77 2008 container.11 from block 2026 99 1997 container.0

#食物
loot replace block 2026 99 1997 container.0 loot gui:normal/eat
execute if score #store_eat tick matches 3 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_eat number
scoreboard players operation #store dummy = #store_eat dummy
scoreboard players operation #store limit = #store_eat limit
execute unless score #store_eat tick matches 3 run function gui:_exper
item replace block 2012 77 2004 container.0 from block 2026 99 1997 container.0
#紫颂果
loot replace block 2026 99 1997 container.0 loot gui:normal/fruit
execute if score #store_fruit tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_fruit number
scoreboard players operation #store dummy = #store_fruit dummy
scoreboard players operation #store limit = #store_fruit limit
execute unless score #store_fruit tick matches 1 run function gui:_exper
item replace block 2012 77 2004 container.1 from block 2026 99 1997 container.0
#金苹果
loot replace block 2026 99 1997 container.0 loot gui:normal/golden_apple
execute if score #store_golden_apple tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_golden_apple number
scoreboard players operation #store dummy = #store_golden_apple dummy
scoreboard players operation #store limit = #store_golden_apple limit
execute unless score #store_golden_apple tick matches 1 run function gui:_exper
item replace block 2012 77 2004 container.2 from block 2026 99 1997 container.0
#附魔金苹果
loot replace block 2026 99 1997 container.0 loot gui:normal/enchanted_golden_apple
execute if score #store_enchanted_golden_apple tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_enchanted_golden_apple number
scoreboard players operation #store dummy = #store_enchanted_golden_apple dummy
scoreboard players operation #store limit = #store_enchanted_golden_apple limit
execute unless score #store_enchanted_golden_apple tick matches 1 run function gui:_exper
item replace block 2012 77 2004 container.3 from block 2026 99 1997 container.0
#力量药水
loot replace block 2026 99 1997 container.0 loot gui:normal/potion_strength
execute if score #store_potion_strength tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_potion_strength number
scoreboard players operation #store dummy = #store_potion_strength dummy
scoreboard players operation #store limit = #store_potion_strength limit
execute unless score #store_potion_strength tick matches 1 run function gui:_exper
item replace block 2012 77 2004 container.4 from block 2026 99 1997 container.0
#速度药水
loot replace block 2026 99 1997 container.0 loot gui:normal/potion_speed
execute if score #store_potion_speed tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_potion_speed number
scoreboard players operation #store dummy = #store_potion_speed dummy
scoreboard players operation #store limit = #store_potion_speed limit
execute unless score #store_potion_speed tick matches 1 run function gui:_exper
item replace block 2012 77 2004 container.5 from block 2026 99 1997 container.0
#隐身药水
loot replace block 2026 99 1997 container.0 loot gui:normal/potion_invisible
execute if score #store_potion_invisible tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_potion_invisible number
scoreboard players operation #store dummy = #store_potion_invisible dummy
scoreboard players operation #store limit = #store_potion_invisible limit
execute unless score #store_potion_invisible tick matches 1 run function gui:_exper
item replace block 2012 77 2004 container.6 from block 2026 99 1997 container.0
#跳跃药水
loot replace block 2026 99 1997 container.0 loot gui:normal/potion_jump
execute if score #store_potion_jump tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_potion_jump number
scoreboard players operation #store dummy = #store_potion_jump dummy
scoreboard players operation #store limit = #store_potion_jump limit
execute unless score #store_potion_jump tick matches 1 run function gui:_exper
item replace block 2012 77 2004 container.7 from block 2026 99 1997 container.0
#夜视药水
loot replace block 2026 99 1997 container.0 loot gui:normal/potion_vision
execute if score #store_potion_vision tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_potion_vision number
scoreboard players operation #store dummy = #store_potion_vision dummy
scoreboard players operation #store limit = #store_potion_vision limit
execute unless score #store_potion_vision tick matches 1 run function gui:_exper
item replace block 2012 77 2004 container.8 from block 2026 99 1997 container.0
#魔法曲奇
loot replace block 2026 99 1997 container.0 loot gui:normal/cookie
execute if score #store_cookie tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_cookie number
scoreboard players operation #store dummy = #store_cookie dummy
scoreboard players operation #store limit = #store_cookie limit
execute unless score #store_cookie tick matches 1 run function gui:_exper
item replace block 2012 77 2004 container.9 from block 2026 99 1997 container.0
#毒帽菇
loot replace block 2026 99 1997 container.0 loot gui:normal/burst_mushroom
execute if score #store_burst_mushroom tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_burst_mushroom number
scoreboard players operation #store dummy = #store_burst_mushroom dummy
scoreboard players operation #store limit = #store_burst_mushroom limit
execute unless score #store_burst_mushroom tick matches 1 run function gui:_exper
item replace block 2012 77 2004 container.10 from block 2026 99 1997 container.0
#马里奥蘑菇
loot replace block 2026 99 1997 container.0 loot gui:normal/growth_mushroom
execute if score #store_growth_mushroom tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_growth_mushroom number
scoreboard players operation #store dummy = #store_growth_mushroom dummy
scoreboard players operation #store limit = #store_growth_mushroom limit
execute unless score #store_growth_mushroom tick matches 1 run function gui:_exper
item replace block 2012 77 2004 container.11 from block 2026 99 1997 container.0
#水肺药水
loot replace block 2026 99 1997 container.0 loot gui:normal/potion_breath
execute if score #store_potion_breath tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_potion_breath number
scoreboard players operation #store dummy = #store_potion_breath dummy
scoreboard players operation #store limit = #store_potion_breath limit
execute unless score #store_potion_breath tick matches 1 run function gui:_exper
item replace block 2012 77 2004 container.12 from block 2026 99 1997 container.0

#海绵
loot replace block 2026 99 1997 container.0 loot gui:normal/sponge
execute if score #store_sponge tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_sponge number
scoreboard players operation #store dummy = #store_sponge dummy
scoreboard players operation #store limit = #store_sponge limit
execute unless score #store_sponge tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.0 from block 2026 99 1997 container.0
#TNT
loot replace block 2026 99 1997 container.0 loot gui:normal/tnt
execute if score #store_tnt tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_tnt number
scoreboard players operation #store dummy = #store_tnt dummy
scoreboard players operation #store limit = #store_tnt limit
execute unless score #store_tnt tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.1 from block 2026 99 1997 container.0
#铁傀儡
loot replace block 2026 99 1997 container.0 loot gui:normal/iron_golem
execute if score #store_iron_golem tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_iron_golem number
scoreboard players operation #store dummy = #store_iron_golem dummy
scoreboard players operation #store limit = #store_iron_golem limit
execute unless score #store_iron_golem tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.2 from block 2026 99 1997 container.0
#蠹虫
loot replace block 2026 99 1997 container.0 loot gui:normal/silverfish
execute if score #store_silverfish tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_silverfish number
scoreboard players operation #store dummy = #store_silverfish dummy
scoreboard players operation #store limit = #store_silverfish limit
execute unless score #store_silverfish tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.3 from block 2026 99 1997 container.0
#火球
loot replace block 2026 99 1997 container.0 loot gui:normal/fireball
execute if score #store_fireball tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_fireball number
scoreboard players operation #store dummy = #store_fireball dummy
scoreboard players operation #store limit = #store_fireball limit
execute unless score #store_fireball tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.4 from block 2026 99 1997 container.0
#末影珍珠
loot replace block 2026 99 1997 container.0 loot gui:normal/ender_pearl
execute if score #store_ender_pearl tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_ender_pearl number
scoreboard players operation #store dummy = #store_ender_pearl dummy
scoreboard players operation #store limit = #store_ender_pearl limit
execute unless score #store_ender_pearl tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.5 from block 2026 99 1997 container.0
#折越珍珠
loot replace block 2026 99 1997 container.0 loot gui:normal/back_pearl
execute if score #store_back_pearl tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_back_pearl number
scoreboard players operation #store dummy = #store_back_pearl dummy
scoreboard players operation #store limit = #store_back_pearl limit
execute unless score #store_back_pearl tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.6 from block 2026 99 1997 container.0
#迁移之眼
loot replace block 2026 99 1997 container.0 loot gui:normal/move_pearl
execute if score #store_move_pearl tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_move_pearl number
scoreboard players operation #store dummy = #store_move_pearl dummy
scoreboard players operation #store limit = #store_move_pearl limit
execute unless score #store_move_pearl tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.7 from block 2026 99 1997 container.0
#传送之眼
loot replace block 2026 99 1997 container.0 loot gui:normal/tp_pearl
execute if score #store_tp_pearl tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_tp_pearl number
scoreboard players operation #store dummy = #store_tp_pearl dummy
scoreboard players operation #store limit = #store_tp_pearl limit
execute unless score #store_tp_pearl tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.8 from block 2026 99 1997 container.0
#冰桥
loot replace block 2026 99 1997 container.0 loot gui:normal/ice
execute if score #store_ice tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_ice number
scoreboard players operation #store dummy = #store_ice dummy
scoreboard players operation #store limit = #store_ice limit
execute unless score #store_ice tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.9 from block 2026 99 1997 container.0
#TNT矿车
loot replace block 2026 99 1997 container.0 loot gui:normal/tnt_minecart
execute if score #store_tnt_minecart tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_tnt_minecart number
scoreboard players operation #store dummy = #store_tnt_minecart dummy
scoreboard players operation #store limit = #store_tnt_minecart limit
execute unless score #store_tnt_minecart tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.10 from block 2026 99 1997 container.0
#救援平台
loot replace block 2026 99 1997 container.0 loot gui:normal/platform
execute if score #store_platform tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_platform number
scoreboard players operation #store dummy = #store_platform dummy
scoreboard players operation #store limit = #store_platform limit
execute unless score #store_platform tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.11 from block 2026 99 1997 container.0
#小石头
loot replace block 2026 99 1997 container.0 loot gui:normal/rock
execute if score #store_rock tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_rock number
scoreboard players operation #store dummy = #store_rock dummy
scoreboard players operation #store limit = #store_rock limit
execute unless score #store_rock tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.12 from block 2026 99 1997 container.0
#风弹
loot replace block 2026 99 1997 container.0 loot gui:normal/wind_charge
execute if score #store_wind_charge tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_wind_charge number
scoreboard players operation #store dummy = #store_wind_charge dummy
scoreboard players operation #store limit = #store_wind_charge limit
execute unless score #store_wind_charge tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.13 from block 2026 99 1997 container.0
#搭桥蛋
loot replace block 2026 99 1997 container.0 loot gui:normal/egg
execute if score #store_egg tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_egg number
scoreboard players operation #store dummy = #store_egg dummy
scoreboard players operation #store limit = #store_egg limit
execute unless score #store_egg tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.14 from block 2026 99 1997 container.0
#水桶
loot replace block 2026 99 1997 container.0 loot gui:normal/water
execute if score #store_water tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_water number
scoreboard players operation #store dummy = #store_water dummy
scoreboard players operation #store limit = #store_water limit
execute unless score #store_water tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.15 from block 2026 99 1997 container.0
#魔法牛奶
loot replace block 2026 99 1997 container.0 loot gui:normal/milk
execute if score #store_milk tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_milk number
scoreboard players operation #store dummy = #store_milk dummy
scoreboard players operation #store limit = #store_milk limit
execute unless score #store_milk tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.16 from block 2026 99 1997 container.0
#细雪
loot replace block 2026 99 1997 container.0 loot gui:normal/snow
execute if score #store_snow tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_snow number
scoreboard players operation #store dummy = #store_snow dummy
scoreboard players operation #store limit = #store_snow limit
execute unless score #store_snow tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.17 from block 2026 99 1997 container.0
#回城卷轴
loot replace block 2026 99 1997 container.0 loot gui:normal/scroll
execute if score #store_scroll tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_scroll number
scoreboard players operation #store dummy = #store_scroll dummy
scoreboard players operation #store limit = #store_scroll limit
execute unless score #store_scroll tick matches 1 run function gui:_exper
item replace block 2018 77 2004 container.18 from block 2026 99 1997 container.0
#水下TNT
loot replace block 2026 99 1997 container.0 loot gui:normal/tnt_water
execute if score #store_tnt_water tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_tnt_water number
scoreboard players operation #store dummy = #store_tnt_water dummy
scoreboard players operation #store limit = #store_tnt_water limit
execute unless score #store_tnt_water tick matches 1 run function gui:_exper
item replace block 2018 75 2004 container.0 from block 2026 99 1997 container.0
#岩浆块
loot replace block 2026 99 1997 container.0 loot gui:normal/magma_block
execute if score #store_magma_block tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_magma_block number
scoreboard players operation #store dummy = #store_magma_block dummy
scoreboard players operation #store limit = #store_magma_block limit
execute unless score #store_magma_block tick matches 1 run function gui:_exper
item replace block 2018 75 2004 container.1 from block 2026 99 1997 container.0
#灵魂沙
loot replace block 2026 99 1997 container.0 loot gui:normal/soul_sand
execute if score #store_soul_sand tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_soul_sand number
scoreboard players operation #store dummy = #store_soul_sand dummy
scoreboard players operation #store limit = #store_soul_sand limit
execute unless score #store_soul_sand tick matches 1 run function gui:_exper
item replace block 2018 75 2004 container.2 from block 2026 99 1997 container.0
#岩浆桶
loot replace block 2026 99 1997 container.0 loot gui:normal/lava
execute if score #store_lava tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_lava number
scoreboard players operation #store dummy = #store_lava dummy
scoreboard players operation #store limit = #store_lava limit
execute unless score #store_lava tick matches 1 run function gui:_exper
item replace block 2018 75 2004 container.3 from block 2026 99 1997 container.0
#河豚桶
loot replace block 2026 99 1997 container.0 loot gui:normal/pufferfish
execute if score #store_pufferfish tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_pufferfish number
scoreboard players operation #store dummy = #store_pufferfish dummy
scoreboard players operation #store limit = #store_pufferfish limit
execute unless score #store_pufferfish tick matches 1 run function gui:_exper
item replace block 2018 75 2004 container.4 from block 2026 99 1997 container.0

#锁链装备
loot replace block 2026 99 1997 container.0 loot gui:normal/chainmail_armor
execute if score #store_chainmail_armor tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_chainmail_armor number
scoreboard players operation #store dummy = #store_chainmail_armor dummy
scoreboard players operation #store limit = #store_chainmail_armor limit
execute unless score #store_chainmail_armor tick matches 1 run function gui:_exper
item replace block 2016 77 2004 container.0 from block 2026 99 1997 container.0
#铁装备
loot replace block 2026 99 1997 container.0 loot gui:normal/iron_armor
execute if score #store_iron_armor tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_iron_armor number
scoreboard players operation #store dummy = #store_iron_armor dummy
scoreboard players operation #store limit = #store_iron_armor limit
execute unless score #store_iron_armor tick matches 1 run function gui:_exper
item replace block 2016 77 2004 container.1 from block 2026 99 1997 container.0
#钻石装备
loot replace block 2026 99 1997 container.0 loot gui:normal/diamond_armor
execute if score #store_diamond_armor tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_diamond_armor number
scoreboard players operation #store dummy = #store_diamond_armor dummy
scoreboard players operation #store limit = #store_diamond_armor limit
execute unless score #store_diamond_armor tick matches 1 run function gui:_exper
item replace block 2016 77 2004 container.2 from block 2026 99 1997 container.0
#下界合金装备
loot replace block 2026 99 1997 container.0 loot gui:normal/netherite_armor
execute if score #store_netherite_armor tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_netherite_armor number
scoreboard players operation #store dummy = #store_netherite_armor dummy
scoreboard players operation #store limit = #store_netherite_armor limit
execute unless score #store_netherite_armor tick matches 1 run function gui:_exper
item replace block 2016 77 2004 container.3 from block 2026 99 1997 container.0
#盾牌
loot replace block 2026 99 1997 container.0 loot gui:normal/shield
execute if score #store_shield tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_shield number
scoreboard players operation #store dummy = #store_shield dummy
scoreboard players operation #store limit = #store_shield limit
execute unless score #store_shield tick matches 1 run function gui:_exper
item replace block 2016 77 2004 container.4 from block 2026 99 1997 container.0

#木镐
scoreboard players set #store limit 0
scoreboard players operation #store tick = #store_wooden_pickaxe tick
scoreboard players set #store_wooden_pickaxe tick 0
loot replace block 2026 99 1997 container.0 loot gui:normal/wooden_pickaxe
scoreboard players operation #store_wooden_pickaxe tick = #store tick
scoreboard players operation #store number = #store_wooden_pickaxe number
scoreboard players operation #store dummy = #store_wooden_pickaxe dummy
execute unless score #store_wooden_pickaxe tick matches 1 run function gui:_exper
execute if score #store_wooden_pickaxe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
item replace block 2012 75 2004 container.0 from block 2026 99 1997 container.0
loot replace block 2026 99 1997 container.0 loot gui:normal/wooden_pickaxe
execute if score #store_wooden_pickaxe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_wooden_pickaxe custom
scoreboard players operation #store dummy = #store_wooden_pickaxe cd
scoreboard players operation #store limit = #store_wooden_pickaxe limit
execute unless score #store_wooden_pickaxe tick matches 1 run function gui:_exper
item replace block 2012 75 2004 container.9 from block 2026 99 1997 container.0
#铁镐
scoreboard players set #store limit 0
scoreboard players operation #store tick = #store_iron_pickaxe tick
scoreboard players set #store_iron_pickaxe tick 0
loot replace block 2026 99 1997 container.0 loot gui:normal/iron_pickaxe
scoreboard players operation #store_iron_pickaxe tick = #store tick
scoreboard players operation #store number = #store_iron_pickaxe number
scoreboard players operation #store dummy = #store_iron_pickaxe dummy
execute unless score #store_iron_pickaxe tick matches 1 run function gui:_exper
execute if score #store_iron_pickaxe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
item replace block 2012 75 2004 container.1 from block 2026 99 1997 container.0
loot replace block 2026 99 1997 container.0 loot gui:normal/iron_pickaxe
execute if score #store_iron_pickaxe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_iron_pickaxe custom
scoreboard players operation #store dummy = #store_iron_pickaxe cd
scoreboard players operation #store limit = #store_iron_pickaxe limit
execute unless score #store_iron_pickaxe tick matches 1 run function gui:_exper
item replace block 2012 75 2004 container.10 from block 2026 99 1997 container.0
#金镐
scoreboard players set #store limit 0
scoreboard players operation #store tick = #store_golden_pickaxe tick
scoreboard players set #store_golden_pickaxe tick 0
loot replace block 2026 99 1997 container.0 loot gui:normal/golden_pickaxe
scoreboard players operation #store_golden_pickaxe tick = #store tick
scoreboard players operation #store number = #store_golden_pickaxe number
scoreboard players operation #store dummy = #store_golden_pickaxe dummy
execute unless score #store_golden_pickaxe tick matches 1 run function gui:_exper
execute if score #store_golden_pickaxe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
item replace block 2012 75 2004 container.2 from block 2026 99 1997 container.0
loot replace block 2026 99 1997 container.0 loot gui:normal/golden_pickaxe
execute if score #store_golden_pickaxe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_golden_pickaxe custom
scoreboard players operation #store dummy = #store_golden_pickaxe cd
scoreboard players operation #store limit = #store_golden_pickaxe limit
execute unless score #store_golden_pickaxe tick matches 1 run function gui:_exper
item replace block 2012 75 2004 container.11 from block 2026 99 1997 container.0
#钻石镐
scoreboard players set #store limit 0
scoreboard players operation #store tick = #store_diamond_pickaxe tick
scoreboard players set #store_diamond_pickaxe tick 0
loot replace block 2026 99 1997 container.0 loot gui:normal/diamond_pickaxe
scoreboard players operation #store_diamond_pickaxe tick = #store tick
scoreboard players operation #store number = #store_diamond_pickaxe number
scoreboard players operation #store dummy = #store_diamond_pickaxe dummy
execute unless score #store_diamond_pickaxe tick matches 1 run function gui:_exper
execute if score #store_diamond_pickaxe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
item replace block 2012 75 2004 container.3 from block 2026 99 1997 container.0
loot replace block 2026 99 1997 container.0 loot gui:normal/diamond_pickaxe
execute if score #store_diamond_pickaxe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_diamond_pickaxe custom
scoreboard players operation #store dummy = #store_diamond_pickaxe cd
scoreboard players operation #store limit = #store_diamond_pickaxe limit
execute unless score #store_diamond_pickaxe tick matches 1 run function gui:_exper
item replace block 2012 75 2004 container.12 from block 2026 99 1997 container.0
#下界合金镐
scoreboard players set #store limit 0
scoreboard players operation #store tick = #store_netherite_pickaxe tick
scoreboard players set #store_netherite_pickaxe tick 0
loot replace block 2026 99 1997 container.0 loot gui:normal/netherite_pickaxe
scoreboard players operation #store_netherite_pickaxe tick = #store tick
scoreboard players operation #store number = #store_netherite_pickaxe number
scoreboard players operation #store dummy = #store_netherite_pickaxe dummy
execute unless score #store_netherite_pickaxe tick matches 1 run function gui:_exper
execute if score #store_netherite_pickaxe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
item replace block 2012 75 2004 container.4 from block 2026 99 1997 container.0
loot replace block 2026 99 1997 container.0 loot gui:normal/netherite_pickaxe
execute if score #store_netherite_pickaxe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_netherite_pickaxe custom
scoreboard players operation #store dummy = #store_netherite_pickaxe cd
scoreboard players operation #store limit = #store_netherite_pickaxe limit
execute unless score #store_netherite_pickaxe tick matches 1 run function gui:_exper
item replace block 2012 75 2004 container.13 from block 2026 99 1997 container.0

#木斧
scoreboard players set #store limit 0
scoreboard players operation #store tick = #store_wooden_axe tick
scoreboard players set #store_wooden_axe tick 0
loot replace block 2026 99 1997 container.0 loot gui:normal/wooden_axe
scoreboard players operation #store_wooden_axe tick = #store tick
scoreboard players operation #store number = #store_wooden_axe number
scoreboard players operation #store dummy = #store_wooden_axe dummy
execute unless score #store_wooden_axe tick matches 1 run function gui:_exper
execute if score #store_wooden_axe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
item replace block 2014 75 2004 container.0 from block 2026 99 1997 container.0
loot replace block 2026 99 1997 container.0 loot gui:normal/wooden_axe
execute if score #store_wooden_axe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_wooden_axe custom
scoreboard players operation #store dummy = #store_wooden_axe cd
scoreboard players operation #store limit = #store_wooden_axe limit
execute unless score #store_wooden_axe tick matches 1 run function gui:_exper
item replace block 2014 75 2004 container.9 from block 2026 99 1997 container.0
#石斧
scoreboard players set #store limit 0
scoreboard players operation #store tick = #store_stone_axe tick
scoreboard players set #store_stone_axe tick 0
loot replace block 2026 99 1997 container.0 loot gui:normal/stone_axe
scoreboard players operation #store_stone_axe tick = #store tick
scoreboard players operation #store number = #store_stone_axe number
scoreboard players operation #store dummy = #store_stone_axe dummy
execute unless score #store_stone_axe tick matches 1 run function gui:_exper
execute if score #store_stone_axe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
item replace block 2014 75 2004 container.1 from block 2026 99 1997 container.0
loot replace block 2026 99 1997 container.0 loot gui:normal/stone_axe
execute if score #store_stone_axe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_stone_axe custom
scoreboard players operation #store dummy = #store_stone_axe cd
scoreboard players operation #store limit = #store_stone_axe limit
execute unless score #store_stone_axe tick matches 1 run function gui:_exper
item replace block 2014 75 2004 container.10 from block 2026 99 1997 container.0
#铁斧
scoreboard players set #store limit 0
scoreboard players operation #store tick = #store_iron_axe tick
scoreboard players set #store_iron_axe tick 0
loot replace block 2026 99 1997 container.0 loot gui:normal/iron_axe
scoreboard players operation #store_iron_axe tick = #store tick
scoreboard players operation #store number = #store_iron_axe number
scoreboard players operation #store dummy = #store_iron_axe dummy
execute unless score #store_iron_axe tick matches 1 run function gui:_exper
execute if score #store_iron_axe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
item replace block 2014 75 2004 container.2 from block 2026 99 1997 container.0
loot replace block 2026 99 1997 container.0 loot gui:normal/iron_axe
execute if score #store_iron_axe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_iron_axe custom
scoreboard players operation #store dummy = #store_iron_axe cd
scoreboard players operation #store limit = #store_iron_axe limit
execute unless score #store_iron_axe tick matches 1 run function gui:_exper
item replace block 2014 75 2004 container.11 from block 2026 99 1997 container.0
#钻石斧
scoreboard players set #store limit 0
scoreboard players operation #store tick = #store_diamond_axe tick
scoreboard players set #store_diamond_axe tick 0
loot replace block 2026 99 1997 container.0 loot gui:normal/diamond_axe
scoreboard players operation #store_diamond_axe tick = #store tick
scoreboard players operation #store number = #store_diamond_axe number
scoreboard players operation #store dummy = #store_diamond_axe dummy
execute unless score #store_diamond_axe tick matches 1 run function gui:_exper
execute if score #store_diamond_axe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
item replace block 2014 75 2004 container.3 from block 2026 99 1997 container.0
loot replace block 2026 99 1997 container.0 loot gui:normal/diamond_axe
execute if score #store_diamond_axe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_diamond_axe custom
scoreboard players operation #store dummy = #store_diamond_axe cd
scoreboard players operation #store limit = #store_diamond_axe limit
execute unless score #store_diamond_axe tick matches 1 run function gui:_exper
item replace block 2014 75 2004 container.12 from block 2026 99 1997 container.0
#下界合金斧
scoreboard players set #store limit 0
scoreboard players operation #store tick = #store_netherite_axe tick
scoreboard players set #store_netherite_axe tick 0
loot replace block 2026 99 1997 container.0 loot gui:normal/netherite_axe
scoreboard players operation #store_netherite_axe tick = #store tick
scoreboard players operation #store number = #store_netherite_axe number
scoreboard players operation #store dummy = #store_netherite_axe dummy
execute unless score #store_netherite_axe tick matches 1 run function gui:_exper
execute if score #store_netherite_axe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
item replace block 2014 75 2004 container.4 from block 2026 99 1997 container.0
loot replace block 2026 99 1997 container.0 loot gui:normal/netherite_axe
execute if score #store_netherite_axe tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_netherite_axe custom
scoreboard players operation #store dummy = #store_netherite_axe cd
scoreboard players operation #store limit = #store_netherite_axe limit
execute unless score #store_netherite_axe tick matches 1 run function gui:_exper
item replace block 2014 75 2004 container.13 from block 2026 99 1997 container.0

#木锹
scoreboard players set #store limit 0
scoreboard players operation #store tick = #store_wooden_shovel tick
scoreboard players set #store_wooden_shovel tick 0
loot replace block 2026 99 1997 container.0 loot gui:normal/wooden_shovel
scoreboard players operation #store_wooden_shovel tick = #store tick
scoreboard players operation #store number = #store_wooden_shovel number
scoreboard players operation #store dummy = #store_wooden_shovel dummy
execute unless score #store_wooden_shovel tick matches 1 run function gui:_exper
execute if score #store_wooden_shovel tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
item replace block 2016 75 2004 container.0 from block 2026 99 1997 container.0
loot replace block 2026 99 1997 container.0 loot gui:normal/wooden_shovel
execute if score #store_wooden_shovel tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_wooden_shovel custom
scoreboard players operation #store dummy = #store_wooden_shovel cd
scoreboard players operation #store limit = #store_wooden_shovel limit
execute unless score #store_wooden_shovel tick matches 1 run function gui:_exper
item replace block 2016 75 2004 container.9 from block 2026 99 1997 container.0
#石锹
scoreboard players set #store limit 0
scoreboard players operation #store tick = #store_stone_shovel tick
scoreboard players set #store_stone_shovel tick 0
loot replace block 2026 99 1997 container.0 loot gui:normal/stone_shovel
scoreboard players operation #store_stone_shovel tick = #store tick
scoreboard players operation #store number = #store_stone_shovel number
scoreboard players operation #store dummy = #store_stone_shovel dummy
execute unless score #store_stone_shovel tick matches 1 run function gui:_exper
execute if score #store_stone_shovel tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
item replace block 2016 75 2004 container.1 from block 2026 99 1997 container.0
loot replace block 2026 99 1997 container.0 loot gui:normal/stone_shovel
execute if score #store_stone_shovel tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_stone_shovel custom
scoreboard players operation #store dummy = #store_stone_shovel cd
scoreboard players operation #store limit = #store_stone_shovel limit
execute unless score #store_stone_shovel tick matches 1 run function gui:_exper
item replace block 2016 75 2004 container.10 from block 2026 99 1997 container.0
#铁锹
scoreboard players set #store limit 0
scoreboard players operation #store tick = #store_iron_shovel tick
scoreboard players set #store_iron_shovel tick 0
loot replace block 2026 99 1997 container.0 loot gui:normal/iron_shovel
scoreboard players operation #store_iron_shovel tick = #store tick
scoreboard players operation #store number = #store_iron_shovel number
scoreboard players operation #store dummy = #store_iron_shovel dummy
execute unless score #store_iron_shovel tick matches 1 run function gui:_exper
execute if score #store_iron_shovel tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
item replace block 2016 75 2004 container.2 from block 2026 99 1997 container.0
loot replace block 2026 99 1997 container.0 loot gui:normal/iron_shovel
execute if score #store_iron_shovel tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_iron_shovel custom
scoreboard players operation #store dummy = #store_iron_shovel cd
scoreboard players operation #store limit = #store_iron_shovel limit
execute unless score #store_iron_shovel tick matches 1 run function gui:_exper
item replace block 2016 75 2004 container.11 from block 2026 99 1997 container.0
#钻石锹
scoreboard players set #store limit 0
scoreboard players operation #store tick = #store_diamond_shovel tick
scoreboard players set #store_diamond_shovel tick 0
loot replace block 2026 99 1997 container.0 loot gui:normal/diamond_shovel
scoreboard players operation #store_diamond_shovel tick = #store tick
scoreboard players operation #store number = #store_diamond_shovel number
scoreboard players operation #store dummy = #store_diamond_shovel dummy
execute unless score #store_diamond_shovel tick matches 1 run function gui:_exper
execute if score #store_diamond_shovel tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
item replace block 2016 75 2004 container.3 from block 2026 99 1997 container.0
loot replace block 2026 99 1997 container.0 loot gui:normal/diamond_shovel
execute if score #store_diamond_shovel tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_diamond_shovel custom
scoreboard players operation #store dummy = #store_diamond_shovel cd
scoreboard players operation #store limit = #store_diamond_shovel limit
execute unless score #store_diamond_shovel tick matches 1 run function gui:_exper
item replace block 2016 75 2004 container.12 from block 2026 99 1997 container.0
#下界合金锹
scoreboard players set #store limit 0
scoreboard players operation #store tick = #store_netherite_shovel tick
scoreboard players set #store_netherite_shovel tick 0
loot replace block 2026 99 1997 container.0 loot gui:normal/netherite_shovel
scoreboard players operation #store_netherite_shovel tick = #store tick
scoreboard players operation #store number = #store_netherite_shovel number
scoreboard players operation #store dummy = #store_netherite_shovel dummy
execute unless score #store_netherite_shovel tick matches 1 run function gui:_exper
execute if score #store_netherite_shovel tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
item replace block 2016 75 2004 container.4 from block 2026 99 1997 container.0
loot replace block 2026 99 1997 container.0 loot gui:normal/netherite_shovel
execute if score #store_netherite_shovel tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_netherite_shovel custom
scoreboard players operation #store dummy = #store_netherite_shovel cd
scoreboard players operation #store limit = #store_netherite_shovel limit
execute unless score #store_netherite_shovel tick matches 1 run function gui:_exper
item replace block 2016 75 2004 container.13 from block 2026 99 1997 container.0

#普通三叉戟
loot replace block 2026 99 1997 container.0 loot gui:normal/trident1
execute if score #store_trident1 tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_trident1 number
scoreboard players operation #store dummy = #store_trident1 dummy
scoreboard players operation #store limit = #store_trident1 limit
execute unless score #store_trident1 tick matches 1 run function gui:_exper
item replace block 2014 75 2008 container.0 from block 2026 99 1997 container.0
#穿刺三叉戟
loot replace block 2026 99 1997 container.0 loot gui:normal/trident2
execute if score #store_trident2 tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_trident2 number
scoreboard players operation #store dummy = #store_trident2 dummy
scoreboard players operation #store limit = #store_trident2 limit
execute unless score #store_trident2 tick matches 1 run function gui:_exper
item replace block 2014 75 2008 container.1 from block 2026 99 1997 container.0
#忠诚三叉戟
loot replace block 2026 99 1997 container.0 loot gui:normal/trident3
execute if score #store_trident3 tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_trident3 number
scoreboard players operation #store dummy = #store_trident3 dummy
scoreboard players operation #store limit = #store_trident3 limit
execute unless score #store_trident3 tick matches 1 run function gui:_exper
item replace block 2014 75 2008 container.2 from block 2026 99 1997 container.0
#忠诚，穿刺三叉戟
loot replace block 2026 99 1997 container.0 loot gui:normal/trident4
execute if score #store_trident4 tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_trident4 number
scoreboard players operation #store dummy = #store_trident4 dummy
scoreboard players operation #store limit = #store_trident4 limit
execute unless score #store_trident4 tick matches 1 run function gui:_exper
item replace block 2014 75 2008 container.3 from block 2026 99 1997 container.0
#引雷三叉戟
loot replace block 2026 99 1997 container.0 loot gui:normal/trident5
execute if score #store_trident5 tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_trident5 number
scoreboard players operation #store dummy = #store_trident5 dummy
scoreboard players operation #store limit = #store_trident5 limit
execute unless score #store_trident5 tick matches 1 run function gui:_exper
item replace block 2014 75 2008 container.4 from block 2026 99 1997 container.0
#全能三叉戟
loot replace block 2026 99 1997 container.0 loot gui:normal/trident6
execute if score #store_trident6 tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_trident6 number
scoreboard players operation #store dummy = #store_trident6 dummy
scoreboard players operation #store limit = #store_trident6 limit
execute unless score #store_trident6 tick matches 1 run function gui:_exper
item replace block 2014 75 2008 container.5 from block 2026 99 1997 container.0
#激流三叉戟
loot replace block 2026 99 1997 container.0 loot gui:normal/trident_riptide
execute if score #store_trident_riptide tick matches 1 run loot replace block 2026 99 1997 container.0 loot gui:gui_pane
scoreboard players operation #store number = #store_trident_riptide number
scoreboard players operation #store dummy = #store_trident_riptide dummy
scoreboard players operation #store limit = #store_trident_riptide limit
execute unless score #store_trident_riptide tick matches 1 run function gui:_exper
item replace block 2014 75 2008 container.6 from block 2026 99 1997 container.0

item replace block 2026 99 1997 container.0 with minecraft:air