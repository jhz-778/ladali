execute unless items entity @s player.cursor * run return run item replace entity @s player.cursor from entity @s enderchest.26
execute unless items entity @s player.cursor *[minecraft:custom_data~{gui:1b}] at @s run return run function gui:item_drop
item replace entity @s player.cursor from entity @s enderchest.26