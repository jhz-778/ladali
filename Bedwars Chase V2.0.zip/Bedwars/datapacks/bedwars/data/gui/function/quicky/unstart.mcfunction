execute unless items entity @s enderchest.0 * run scoreboard players set @s slot 1
execute unless items entity @s enderchest.1 * run scoreboard players set @s slot 2
execute unless items entity @s enderchest.2 * run scoreboard players set @s slot 3
execute unless items entity @s enderchest.3 * run scoreboard players set @s slot 4
execute unless items entity @s enderchest.4 * run scoreboard players set @s slot 5
execute unless items entity @s enderchest.5 * run scoreboard players set @s slot 6
execute unless items entity @s enderchest.6 * run scoreboard players set @s slot 7
execute unless items entity @s enderchest.7 * run scoreboard players set @s slot 8
execute unless items entity @s enderchest.8 * run scoreboard players set @s slot 9
execute unless items entity @s enderchest.9 * run scoreboard players set @s slot 10
execute unless items entity @s enderchest.10 * run scoreboard players set @s slot 11
execute unless items entity @s enderchest.11 * run scoreboard players set @s slot 12
execute unless items entity @s enderchest.12 * run scoreboard players set @s slot 13
execute unless items entity @s enderchest.13 * run scoreboard players set @s slot 14
execute unless items entity @s enderchest.14 * run scoreboard players set @s slot 15
execute unless items entity @s enderchest.15 * run scoreboard players set @s slot 16
execute unless items entity @s enderchest.16 * run scoreboard players set @s slot 17
execute unless items entity @s enderchest.17 * run scoreboard players set @s slot 18
clear @s *[minecraft:custom_data={gui:1b}]
execute if entity @s[tag=shift] run return run function gui:quicky/withdraw
execute if score @s slot matches 1.. run function gui:normal/menu_list