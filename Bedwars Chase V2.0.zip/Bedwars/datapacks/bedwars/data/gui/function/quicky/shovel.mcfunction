$execute unless score @s shovel matches 1.. run item replace entity @s enderchest.$(Set) from block 2016 75 2004 container.0
$execute if score @s shovel matches 1 run item replace entity @s enderchest.$(Set) from block 2016 75 2004 container.1
$execute if score @s shovel matches 2 run item replace entity @s enderchest.$(Set) from block 2016 75 2004 container.2
$execute if score @s shovel matches 3 run item replace entity @s enderchest.$(Set) from block 2016 75 2004 container.3
$execute if score @s shovel matches 4.. run item replace entity @s enderchest.$(Set) from block 2016 75 2004 container.4
$item modify entity @s enderchest.$(Set) gui:unlock/shovel