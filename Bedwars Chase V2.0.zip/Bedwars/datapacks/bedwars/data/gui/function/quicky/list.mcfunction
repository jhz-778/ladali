scoreboard players set @s gui -1
scoreboard players set @s slot 0
execute unless data storage minecraft:bedwars {start:1b} run function gui:_start
tag @s add quicky
function gui:quicky/list_pane
execute as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[limit=1,tag=quicky] uid run function gui:quicky/list_item with entity @s data.Quicky
tag @s remove quicky
execute if data storage minecraft:bedwars {start:0b} run function gui:quicky/list_tip