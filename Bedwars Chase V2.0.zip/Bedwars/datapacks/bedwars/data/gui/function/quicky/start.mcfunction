#购买
function gui:normal/_weapon
execute unless data storage minecraft:bedwars {mode:2b} run function gui:normal/_bows
function gui:normal/_tool
function gui:normal/_block
function gui:normal/_food
function gui:normal/_prop
function gui:normal/_armor
#其它模式
execute if data storage minecraft:bedwars {mode:2b} run function gui:normal/_tridents
#菜单
execute if items entity @s player.cursor minecraft:arrow[!minecraft:custom_model_data={floats:[10.0f]},!minecraft:custom_model_data={floats:[14.0f]}] run scoreboard players set @s gui 1