#进程
execute if data storage minecraft:bedwars {start:1b} run return run function gui:quicky/start
execute unless data storage minecraft:bedwars {start:1b} run function gui:quicky/unstart