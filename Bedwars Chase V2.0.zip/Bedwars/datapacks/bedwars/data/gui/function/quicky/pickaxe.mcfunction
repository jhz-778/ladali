$execute unless score @s pickaxe matches 1.. run item replace entity @s enderchest.$(Set) from block 2012 75 2004 container.0
$execute if score @s pickaxe matches 1 run item replace entity @s enderchest.$(Set) from block 2012 75 2004 container.1
$execute if score @s pickaxe matches 2 run item replace entity @s enderchest.$(Set) from block 2012 75 2004 container.2
$execute if score @s pickaxe matches 3 run item replace entity @s enderchest.$(Set) from block 2012 75 2004 container.3
$execute if score @s pickaxe matches 4.. run item replace entity @s enderchest.$(Set) from block 2012 75 2004 container.4
$item modify entity @s enderchest.$(Set) gui:unlock/pickaxe