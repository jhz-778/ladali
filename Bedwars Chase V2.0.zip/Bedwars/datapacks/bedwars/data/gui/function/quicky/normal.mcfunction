#三叉戟
loot replace block 2014 75 2008 container.0 loot gui:gui_pane
loot replace block 2014 75 2008 container.1 loot gui:gui_pane
loot replace block 2014 75 2008 container.2 loot gui:gui_pane
loot replace block 2014 75 2008 container.3 loot gui:gui_pane
loot replace block 2014 75 2008 container.4 loot gui:gui_pane
loot replace block 2014 75 2008 container.5 loot gui:gui_pane
loot replace block 2014 75 2008 container.6 loot gui:gui_pane
#水肺药水
loot replace block 2012 77 2004 container.12 loot gui:gui_pane
#海洋道具
loot replace block 2018 75 2004 container.0 loot gui:gui_pane
loot replace block 2018 75 2004 container.1 loot gui:gui_pane
loot replace block 2018 75 2004 container.2 loot gui:gui_pane
loot replace block 2018 75 2004 container.3 loot gui:gui_pane
loot replace block 2018 75 2004 container.4 loot gui:gui_pane