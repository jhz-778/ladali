$execute unless score @s axe matches 1.. run item replace entity @s enderchest.$(Set) from block 2014 75 2004 container.0
$execute if score @s axe matches 1 run item replace entity @s enderchest.$(Set) from block 2014 75 2004 container.1
$execute if score @s axe matches 2 run item replace entity @s enderchest.$(Set) from block 2014 75 2004 container.2
$execute if score @s axe matches 3 run item replace entity @s enderchest.$(Set) from block 2014 75 2004 container.3
$execute if score @s axe matches 4.. run item replace entity @s enderchest.$(Set) from block 2014 75 2004 container.4
$item modify entity @s enderchest.$(Set) gui:unlock/axe