scoreboard players remove @s slot 1
execute store result storage minecraft:bedwars QUICKY.Set int 1 run scoreboard players get @s slot
function gui:quicky/remove with storage minecraft:bedwars QUICKY