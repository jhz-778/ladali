#陆地道具
loot replace block 2018 77 2004 container.0 loot gui:gui_pane
loot replace block 2018 77 2004 container.1 loot gui:gui_pane
loot replace block 2018 77 2004 container.9 loot gui:gui_pane
loot replace block 2018 77 2004 container.15 loot gui:gui_pane
loot replace block 2018 77 2004 container.17 loot gui:gui_pane
#弓箭类
loot replace block 2014 77 2008 container.0 loot gui:gui_pane
loot replace block 2014 77 2008 container.1 loot gui:gui_pane
loot replace block 2014 77 2008 container.2 loot gui:gui_pane
loot replace block 2014 77 2008 container.3 loot gui:gui_pane
loot replace block 2014 77 2008 container.4 loot gui:gui_pane
loot replace block 2014 77 2008 container.5 loot gui:gui_pane
loot replace block 2014 77 2008 container.6 loot gui:gui_pane
loot replace block 2014 77 2008 container.9 loot gui:gui_pane
loot replace block 2014 77 2008 container.10 loot gui:gui_pane
loot replace block 2014 77 2008 container.11 loot gui:gui_pane
loot replace block 2014 77 2008 container.12 loot gui:gui_pane
loot replace block 2014 77 2008 container.13 loot gui:gui_pane
#钓鱼竿
loot replace block 2016 77 2008 container.10 loot gui:gui_pane
#工具
loot replace block 2014 77 2004 container.3 loot gui:gui_pane
loot replace block 2014 77 2004 container.4 loot gui:gui_pane
#方块
loot replace block 2012 77 2008 container.2 loot gui:gui_pane
loot replace block 2012 77 2008 container.6 loot gui:gui_pane
loot replace block 2012 77 2008 container.9 loot gui:gui_pane