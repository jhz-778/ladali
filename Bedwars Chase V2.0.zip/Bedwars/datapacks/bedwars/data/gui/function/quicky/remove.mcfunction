tag @s add quickyset
$execute as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[limit=1,tag=quickyset] uid run data modify entity @s data.Quicky.Slot$(Set) set value "function bedwars:_none"
$execute as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[limit=1,tag=quickyset] uid run data modify entity @s data.Quicky.SlotAdd$(Set) set value "function bedwars:_none"
tag @s remove quickyset
execute at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2