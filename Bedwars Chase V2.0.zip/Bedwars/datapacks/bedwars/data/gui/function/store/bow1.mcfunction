#快速购买
execute if data storage minecraft:bedwars {start:0b} run data modify storage minecraft:bedwars QUICKY.Slot set value "2014 77 2008 container.0"
execute if data storage minecraft:bedwars {start:0b} run data modify storage minecraft:bedwars QUICKY.SlotAdd set value "gui:_none"
execute if data storage minecraft:bedwars {start:0b} run return run function gui:quicky/set
#重置
scoreboard players set @s cd 0
scoreboard players set @s amount 1
#货币
scoreboard players operation @s dummy = #store_bow1 dummy
scoreboard players operation @s number = #store_bow1 number
function gui:store/_money
#背包容量
execute if predicate minecraft:inventory run scoreboard players set @s cd 2
#限购
tag @s add buying
execute if score #store_bow1 limit matches 1.. as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[limit=1,tag=buying] uid store result score @a[limit=1,tag=buying] limit run data get entity @s data.Limit.bow1
execute if score #store_bow1 limit matches 1.. if score @s limit >= #store_bow1 limit run scoreboard players set @s cd 1
#购买
execute if score @s cd matches 1.. at @s run function gui:store/_fail
execute unless score @s cd matches 1.. run loot replace block 2026 99 1997 container.0 loot gui:store/bow1
execute unless score @s cd matches 1.. at @s run function gui:store/_success
execute unless score @s cd matches 1.. run loot give @s loot gui:store/bow1
execute if score #store_bow1 limit matches 1.. unless score @s cd matches 1.. as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[limit=1,tag=buying] uid store result entity @s data.Limit.bow1 int 1 run scoreboard players get @a[limit=1,tag=buying] limit
tag @s remove buying