#快速购买
execute if data storage minecraft:bedwars {start:0b} run data modify storage minecraft:bedwars QUICKY.Slot set value "2012 77 2004 container.9"
execute if data storage minecraft:bedwars {start:0b} run data modify storage minecraft:bedwars QUICKY.SlotAdd set value "gui:_none"
execute if data storage minecraft:bedwars {start:0b} run return run function gui:quicky/set
#重置
data merge storage minecraft:bedwars {STORE:"cookie"}
scoreboard players set @s cd 0
#货币
scoreboard players operation @s amount = #store_cookie amount
scoreboard players operation @s dummy = #store_cookie dummy
scoreboard players operation @s number = #store_cookie number
function gui:store/_money
#背包容量
execute if predicate minecraft:inventory run scoreboard players set @s cd 2
#限购
tag @s add buying
execute if score #store_cookie limit matches 1.. as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[limit=1,tag=buying] uid store result score @a[limit=1,tag=buying] limit run data get entity @s data.Limit.cookie
execute if score #store_cookie limit matches 1.. if score @s limit >= #store_cookie limit run scoreboard players set @s cd 1
#购买
execute if score @s cd matches 1.. at @s run function gui:store/_fail
execute unless score @s cd matches 1.. run loot replace block 2026 99 1997 container.0 loot gui:store/cookie
execute unless score @s cd matches 1.. at @s run function gui:store/_success
execute unless score @s cd matches 1.. run loot give @s loot gui:store/cookie
execute if score #store_cookie limit matches 1.. unless score @s cd matches 1.. as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[limit=1,tag=buying] uid store result entity @s data.Limit.cookie int 1 run scoreboard players get @a[limit=1,tag=buying] limit
tag @s remove buying