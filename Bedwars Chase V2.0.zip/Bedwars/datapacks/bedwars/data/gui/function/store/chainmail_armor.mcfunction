#快速购买
execute if data storage minecraft:bedwars {start:0b} run data modify storage minecraft:bedwars QUICKY.Slot set value "2016 77 2004 container.0"
execute if data storage minecraft:bedwars {start:0b} run data modify storage minecraft:bedwars QUICKY.SlotAdd set value "gui:unlock/chainmail"
execute if data storage minecraft:bedwars {start:0b} run return run function gui:quicky/set
#重置
scoreboard players set @s cd 0
scoreboard players set @s amount 1
#货币
scoreboard players operation @s dummy = #store_chainmail_armor dummy
scoreboard players operation @s number = #store_chainmail_armor number
function gui:store/_money
#解锁
execute if score @s armor matches 1.. run scoreboard players set @s cd 4
#购买
execute if score @s cd matches 1.. at @s run function gui:store/_fail
execute unless score @s cd matches 1.. run loot replace block 2026 99 1997 container.0 loot gui:normal/chainmail_armor
execute unless score @s cd matches 1.. at @s run function gui:store/_success
execute unless score @s cd matches 1.. run scoreboard players set @s armor 1
execute unless score @s cd matches 1.. run loot replace entity @s armor.legs loot gui:store/chainmail_leggings
execute unless score @s cd matches 1.. run loot replace entity @s armor.feet loot gui:store/chainmail_boots