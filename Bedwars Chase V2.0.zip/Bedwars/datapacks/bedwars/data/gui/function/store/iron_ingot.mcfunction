#重置
data merge storage minecraft:bedwars {STORE:"iron"}
scoreboard players set @s cd 0
scoreboard players set @s amount 1
#货币
scoreboard players set @s dummy 1
scoreboard players operation @s number = #exper_iron math
function gui:store/_money
execute store result storage minecraft:bedwars MONEY int 1 run scoreboard players get @s number
#背包容量
execute if predicate minecraft:inventory run scoreboard players set @s cd 2
#购买
tag @s add expbuy
execute if score @s cd matches 1.. at @s run function gui:store/_fail
execute unless score @s cd matches 1.. run loot give @s loot mode:iron
execute unless score @s cd matches 1.. run function mode:exper/success
execute unless score @s cd matches 1.. at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
tag @s remove expbuy