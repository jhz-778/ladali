#快速购买
execute if data storage minecraft:bedwars {start:0b} run data modify storage minecraft:bedwars QUICKY.Slot set value "2016 77 2004 container.1"
execute if data storage minecraft:bedwars {start:0b} run data modify storage minecraft:bedwars QUICKY.SlotAdd set value "gui:unlock/iron"
execute if data storage minecraft:bedwars {start:0b} run return run function gui:quicky/set
#重置
scoreboard players set @s cd 0
scoreboard players set @s amount 1
#货币
scoreboard players operation @s dummy = #store_iron_armor dummy
scoreboard players operation @s number = #store_iron_armor number
function gui:store/_money
#解锁
execute if score @s armor matches 2.. run scoreboard players set @s cd 4
#购买
execute if score @s cd matches 1.. at @s run function gui:store/_fail
execute unless score @s cd matches 1.. run loot replace block 2026 99 1997 container.0 loot gui:normal/iron_armor
execute unless score @s cd matches 1.. at @s run function gui:store/_success
execute unless score @s cd matches 1.. run scoreboard players set @s armor 2
execute unless score @s cd matches 1.. run advancement grant @s only bedwars:bedwars/iron_armor
execute unless score @s cd matches 1.. run loot replace entity @s armor.legs loot gui:store/iron_leggings
execute unless score @s cd matches 1.. run loot replace entity @s armor.feet loot gui:store/iron_boots