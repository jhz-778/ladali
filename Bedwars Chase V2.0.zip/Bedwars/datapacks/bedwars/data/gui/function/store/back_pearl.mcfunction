#快速购买
execute if data storage minecraft:bedwars {start:0b} run data modify storage minecraft:bedwars QUICKY.Slot set value "2018 77 2004 container.6"
execute if data storage minecraft:bedwars {start:0b} run data modify storage minecraft:bedwars QUICKY.SlotAdd set value "gui:_none"
execute if data storage minecraft:bedwars {start:0b} run return run function gui:quicky/set
#重置
tag @s add shift16
data merge storage minecraft:bedwars {STORE:"back_pearl"}
scoreboard players set @s cd 0
#货币
scoreboard players operation @s amount = #store_back_pearl amount
scoreboard players operation @s dummy = #store_back_pearl dummy
scoreboard players operation @s number = #store_back_pearl number
function gui:store/_money
#背包容量
execute if predicate minecraft:inventory run scoreboard players set @s cd 2
#限购
tag @s add buying
execute if score #store_back_pearl limit matches 1.. as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[limit=1,tag=buying] uid store result score @a[limit=1,tag=buying] limit run data get entity @s data.Limit.back_pearl
execute if score #store_back_pearl limit matches 1.. if score @s limit >= #store_back_pearl limit run scoreboard players set @s cd 1
#购买
execute if score @s cd matches 1.. at @s run function gui:store/_fail
execute unless score @s cd matches 1.. run loot replace block 2026 99 1997 container.0 loot gui:store/back_pearl
execute unless score @s cd matches 1.. at @s run function gui:store/_success
execute unless score @s cd matches 1.. run loot give @s loot gui:store/back_pearl
execute if score #store_back_pearl limit matches 1.. unless score @s cd matches 1.. as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[limit=1,tag=buying] uid store result entity @s data.Limit.back_pearl int 1 run scoreboard players get @a[limit=1,tag=buying] limit
tag @s remove buying