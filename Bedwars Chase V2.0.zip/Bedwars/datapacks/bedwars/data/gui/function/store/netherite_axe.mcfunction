#快速购买
execute if data storage minecraft:bedwars {start:0b} run data modify storage minecraft:bedwars QUICKY.Slot set value "2014 75 2004 container.13"
execute if data storage minecraft:bedwars {start:0b} if data storage minecraft:detail {tool:1b} run data modify storage minecraft:bedwars QUICKY.Slot set value "tool.axe"
execute if data storage minecraft:bedwars {start:0b} run data modify storage minecraft:bedwars QUICKY.SlotAdd set value "gui:_none"
execute if data storage minecraft:bedwars {start:0b} run return run function gui:quicky/set
#重置
scoreboard players set @s cd 0
scoreboard players set @s amount 1
#货币
scoreboard players operation @s dummy = #store_netherite_axe cd
execute if data storage minecraft:detail {tool:1b} run scoreboard players operation @s dummy = #store_netherite_axe dummy
scoreboard players operation @s number = #store_netherite_axe custom
execute if data storage minecraft:detail {tool:1b} run scoreboard players operation @s number = #store_netherite_axe number
function gui:store/_money
#背包容量
execute if predicate minecraft:inventory run scoreboard players set @s cd 2
#限购
tag @s add buying
execute if data storage minecraft:detail {tool:0b} if score #store_netherite_axe limit matches 1.. as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[limit=1,tag=buying] uid store result score @a[limit=1,tag=buying] limit run data get entity @s data.Limit.netherite_axe
execute if data storage minecraft:detail {tool:0b} if score #store_netherite_axe limit matches 1.. if score @s limit >= #store_netherite_axe limit run scoreboard players set @s cd 1
#解锁
execute if score @s axe matches 5 run scoreboard players set @s cd 4
#购买
execute if score @s cd matches 1.. at @s run function gui:store/_fail
execute unless score @s cd matches 1.. run loot replace block 2026 99 1997 container.0 loot gui:store/netherite_axe
execute unless score @s cd matches 1.. at @s run function gui:store/_success
execute if data storage minecraft:detail {tool:1b} unless score @s cd matches 1.. run clear @s #minecraft:axes
execute if data storage minecraft:detail {tool:1b} unless score @s cd matches 1.. run scoreboard players set @s axe 5
execute unless score @s cd matches 1.. run loot give @s loot gui:store/netherite_axe
execute if data storage minecraft:detail {tool:0b} if score #store_netherite_axe limit matches 1.. unless score @s cd matches 1.. as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[limit=1,tag=buying] uid store result entity @s data.Limit.netherite_axe int 1 run scoreboard players get @a[limit=1,tag=buying] limit
tag @s remove buying