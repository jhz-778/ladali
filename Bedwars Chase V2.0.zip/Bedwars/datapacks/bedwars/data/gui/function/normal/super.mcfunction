loot replace entity @s enderchest.0 loot gui:gui_pane
loot replace entity @s enderchest.1 loot gui:gui_pane
loot replace entity @s enderchest.2 loot gui:gui_pane
loot replace entity @s enderchest.3 loot gui:gui_pane
loot replace entity @s enderchest.4 loot gui:normal/super_hacker
execute if score @s super matches 4 run item modify entity @s enderchest.4 gui:select
execute if items entity @s enderchest.4 minecraft:barrier run loot replace entity @s enderchest.4 loot gui:gui_pane
loot replace entity @s enderchest.5 loot gui:gui_pane
loot replace entity @s enderchest.6 loot gui:gui_pane
loot replace entity @s enderchest.7 loot gui:gui_pane
loot replace entity @s enderchest.8 loot gui:gui_pane
loot replace entity @s enderchest.9 loot gui:gui_pane
loot replace entity @s enderchest.10 loot gui:normal/super_assassin
execute if score @s super matches 1 run item modify entity @s enderchest.10 gui:select
execute if data storage minecraft:bedwars {combat:0b} run loot replace entity @s enderchest.10 loot gui:gui_pane
execute if items entity @s enderchest.10 minecraft:barrier run loot replace entity @s enderchest.10 loot gui:gui_pane
loot replace entity @s enderchest.11 loot gui:normal/super_kangaroo
execute if score @s super matches 2 run item modify entity @s enderchest.11 gui:select
execute if items entity @s enderchest.11 minecraft:barrier run loot replace entity @s enderchest.11 loot gui:gui_pane
loot replace entity @s enderchest.12 loot gui:normal/super_builder
execute if score @s super matches 3 run item modify entity @s enderchest.12 gui:select
execute if items entity @s enderchest.12 minecraft:barrier run loot replace entity @s enderchest.12 loot gui:gui_pane
loot replace entity @s enderchest.13 loot gui:gui_pane
loot replace entity @s enderchest.14 loot gui:normal/super_hunter
execute if score @s super matches 5 run item modify entity @s enderchest.14 gui:select
execute if items entity @s enderchest.14 minecraft:barrier run loot replace entity @s enderchest.14 loot gui:gui_pane
loot replace entity @s enderchest.15 loot gui:normal/super_witch
execute if score @s super matches 6 run item modify entity @s enderchest.15 gui:select
execute if items entity @s enderchest.15 minecraft:barrier run loot replace entity @s enderchest.15 loot gui:gui_pane
loot replace entity @s enderchest.16 loot gui:normal/super_bomber
execute if score @s super matches 7 run item modify entity @s enderchest.16 gui:select
execute if items entity @s enderchest.16 minecraft:barrier run loot replace entity @s enderchest.16 loot gui:gui_pane
execute if data storage minecraft:bedwars {combat:0b} run loot replace entity @s enderchest.16 loot gui:gui_pane
loot replace entity @s enderchest.17 loot gui:gui_pane
loot replace entity @s enderchest.18 loot gui:gui_pane
loot replace entity @s enderchest.19 loot gui:gui_pane
loot replace entity @s enderchest.20 loot gui:gui_pane
loot replace entity @s enderchest.21 loot gui:gui_pane
loot replace entity @s enderchest.22 loot gui:gui_back
loot replace entity @s enderchest.23 loot gui:gui_pane
loot replace entity @s enderchest.24 loot gui:gui_pane
loot replace entity @s enderchest.25 loot gui:gui_pane
loot replace entity @s enderchest.26 loot gui:gui_pane