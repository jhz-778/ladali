#菜单
execute if items entity @s player.cursor minecraft:arrow[!minecraft:custom_model_data={floats:[10.0f]},!minecraft:custom_model_data={floats:[14.0f]}] run scoreboard players set @s gui 1
#物品
execute if items entity @s player.cursor minecraft:mace run function gui:store/mace
execute if items entity @s player.cursor minecraft:fishing_rod run function gui:store/fishing_rod
execute if items entity @s player.cursor minecraft:golden_axe run function gui:store/miaoren_axe
execute if items entity @s player.cursor minecraft:stone_sword run function gui:store/stone_sword
execute if items entity @s player.cursor minecraft:iron_sword[minecraft:custom_model_data={floats:[2.0f]}] run function gui:store/iron_sword
execute if items entity @s player.cursor minecraft:diamond_sword run function gui:store/diamond_sword
execute if items entity @s player.cursor minecraft:netherite_sword run function gui:store/netherite_sword
execute if items entity @s player.cursor minecraft:stick run function gui:store/knockback_stick