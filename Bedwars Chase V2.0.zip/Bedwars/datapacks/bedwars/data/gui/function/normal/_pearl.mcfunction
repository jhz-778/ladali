execute unless score @s gui matches 7 if items entity @s player.cursor minecraft:arrow[!minecraft:custom_model_data={floats:[10.0f]},!minecraft:custom_model_data={floats:[14.0f]}] run scoreboard players set @s gui 7
execute if items entity @s player.cursor minecraft:ender_pearl[minecraft:custom_model_data={floats:[6.0f]}] run function gui:store/ender_pearl
execute if items entity @s player.cursor minecraft:ender_pearl[minecraft:custom_model_data={floats:[7.0f]}] run function gui:store/back_pearl
execute if items entity @s player.cursor minecraft:ender_eye[minecraft:custom_model_data={floats:[8.0f]}] run function gui:store/move_pearl
execute if items entity @s player.cursor minecraft:ender_eye[minecraft:custom_model_data={floats:[9.0f]}] run function gui:store/tp_pearl