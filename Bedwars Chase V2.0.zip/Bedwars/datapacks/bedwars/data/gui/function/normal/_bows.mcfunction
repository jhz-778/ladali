#菜单
execute if items entity @s player.cursor minecraft:arrow[!minecraft:custom_model_data={floats:[10.0f]},!minecraft:custom_model_data={floats:[14.0f]}] run scoreboard players set @s gui 1
#物品
execute if items entity @s player.cursor minecraft:tipped_arrow run function gui:store/arrow_potion
execute if items entity @s player.cursor minecraft:arrow[minecraft:custom_model_data={floats:[10.0f]}] run function gui:store/arrow
execute if items entity @s player.cursor minecraft:firework_rocket run function gui:store/firework
execute if items entity @s player.cursor minecraft:spectral_arrow run function gui:store/arrow_spectral
execute if items entity @s player.cursor minecraft:arrow[minecraft:custom_model_data={floats:[14.0f]}] run function gui:store/dart
execute if items entity @s player.cursor minecraft:bow[minecraft:custom_model_data={floats:[1.0f]}] run function gui:store/bow1
execute if items entity @s player.cursor minecraft:bow[minecraft:custom_model_data={floats:[2.0f]}] run function gui:store/bow2
execute if items entity @s player.cursor minecraft:bow[minecraft:custom_model_data={floats:[3.0f]}] run function gui:store/bow3
execute if items entity @s player.cursor minecraft:crossbow[minecraft:custom_model_data={floats:[4.0f]}] run function gui:store/crossbow1
execute if items entity @s player.cursor minecraft:crossbow[minecraft:custom_model_data={floats:[5.0f]}] run function gui:store/crossbow2
execute if items entity @s player.cursor minecraft:crossbow[minecraft:custom_model_data={floats:[6.0f]}] run function gui:store/crossbow3
execute if items entity @s player.cursor minecraft:crossbow[minecraft:custom_model_data={floats:[7.0f]}] run function gui:store/crossbow4