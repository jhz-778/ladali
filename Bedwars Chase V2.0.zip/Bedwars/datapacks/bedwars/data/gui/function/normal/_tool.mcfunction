#里菜单
function gui:normal/_pickaxe
function gui:normal/_axe
function gui:normal/_shovel
#菜单
execute if items entity @s player.cursor minecraft:arrow[!minecraft:custom_model_data={floats:[10.0f]},!minecraft:custom_model_data={floats:[14.0f]}] run scoreboard players set @s gui 1
execute if items entity @s player.cursor minecraft:wooden_pickaxe[!minecraft:custom_model_data={floats:[10.0f]}] run scoreboard players set @s gui 9
execute if items entity @s player.cursor minecraft:wooden_axe[!minecraft:custom_model_data={floats:[19.0f]}] run scoreboard players set @s gui 10
execute if items entity @s player.cursor minecraft:wooden_shovel[!minecraft:custom_model_data={floats:[28.0f]}] run scoreboard players set @s gui 11
#物品
execute if items entity @s player.cursor minecraft:shears run function gui:store/shears
execute if items entity @s player.cursor minecraft:totem_of_undying run function gui:store/totem
execute if items entity @s player.cursor minecraft:spyglass run function gui:store/spyglass
execute if items entity @s player.cursor minecraft:flint_and_steel run function gui:store/flint
execute if items entity @s player.cursor minecraft:elytra run function gui:store/elytra