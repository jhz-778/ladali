loot replace entity @s enderchest.0 loot gui:gui_pane
loot replace entity @s enderchest.1 loot gui:gui_pane
item replace entity @s enderchest.2 from block 2012 77 2004 container.10
item replace entity @s enderchest.3 from block 2012 77 2004 container.11
loot replace entity @s enderchest.4 loot gui:gui_pane
loot replace entity @s enderchest.4 loot gui:gui_pane
execute if data storage minecraft:detail {rain_plan:1b} run item replace entity @s enderchest.5 from block 2012 77 2004 container.17
execute if data storage minecraft:detail {rain_plan:1b} if data storage minecraft:bedwars {start:0b} run item replace entity @s enderchest.5 from block 2012 77 2004 container.8
loot replace entity @s enderchest.6 loot gui:gui_pane
loot replace entity @s enderchest.7 loot gui:gui_pane
loot replace entity @s enderchest.8 loot gui:gui_pane
item replace entity @s enderchest.9 from block 2012 77 2004 container.0
item replace entity @s enderchest.10 from block 2012 77 2004 container.1
item replace entity @s enderchest.11 from block 2012 77 2004 container.2
item replace entity @s enderchest.12 from block 2012 77 2004 container.3
item replace entity @s enderchest.13 from block 2012 77 2004 container.4
item replace entity @s enderchest.14 from block 2012 77 2004 container.5
item replace entity @s enderchest.15 from block 2012 77 2004 container.6
item replace entity @s enderchest.16 from block 2012 77 2004 container.7
item replace entity @s enderchest.17 from block 2012 77 2004 container.9
loot replace entity @s enderchest.18 loot gui:gui_pane
loot replace entity @s enderchest.19 loot gui:gui_pane
loot replace entity @s enderchest.20 loot gui:gui_pane
loot replace entity @s enderchest.21 loot gui:gui_pane
loot replace entity @s enderchest.22 loot gui:gui_back
loot replace entity @s enderchest.23 loot gui:gui_pane
loot replace entity @s enderchest.24 loot gui:gui_pane
loot replace entity @s enderchest.25 loot gui:gui_pane
loot replace entity @s enderchest.26 loot gui:gui_pane