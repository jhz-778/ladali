execute unless score @s gui matches 4 if items entity @s player.cursor minecraft:arrow[!minecraft:custom_model_data={floats:[10.0f]},!minecraft:custom_model_data={floats:[14.0f]}] run scoreboard players set @s gui 4
execute if items entity @s player.cursor minecraft:wooden_pickaxe[minecraft:custom_model_data={floats:[10.0f]}] run function gui:store/wooden_pickaxe
execute if items entity @s player.cursor minecraft:iron_pickaxe run function gui:store/iron_pickaxe
execute if items entity @s player.cursor minecraft:golden_pickaxe[minecraft:custom_model_data={floats:[12.0f]}] run function gui:store/golden_pickaxe
execute if items entity @s player.cursor minecraft:diamond_pickaxe run function gui:store/diamond_pickaxe
execute if items entity @s player.cursor minecraft:netherite_pickaxe run function gui:store/netherite_pickaxe