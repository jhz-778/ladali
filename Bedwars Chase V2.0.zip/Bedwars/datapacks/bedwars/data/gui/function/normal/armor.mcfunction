loot replace entity @s enderchest.0 loot gui:gui_pane
loot replace entity @s enderchest.1 loot gui:gui_pane
loot replace entity @s enderchest.2 loot gui:gui_pane
loot replace entity @s enderchest.3 loot gui:gui_pane
loot replace entity @s enderchest.4 loot gui:gui_pane
loot replace entity @s enderchest.5 loot gui:gui_pane
loot replace entity @s enderchest.6 loot gui:gui_pane
loot replace entity @s enderchest.7 loot gui:gui_pane
loot replace entity @s enderchest.8 loot gui:gui_pane
loot replace entity @s enderchest.9 loot gui:gui_pane
loot replace entity @s enderchest.10 loot gui:gui_pane
item replace entity @s enderchest.11 from block 2016 77 2004 container.0
execute unless items entity @s enderchest.11 minecraft:light_gray_stained_glass_pane[minecraft:custom_data~{gui:1b}] run item modify entity @s enderchest.11 gui:unlock/chainmail
item replace entity @s enderchest.12 from block 2016 77 2004 container.1
execute unless items entity @s enderchest.12 minecraft:light_gray_stained_glass_pane[minecraft:custom_data~{gui:1b}] run item modify entity @s enderchest.12 gui:unlock/iron
item replace entity @s enderchest.13 from block 2016 77 2004 container.2
execute unless items entity @s enderchest.13 minecraft:light_gray_stained_glass_pane[minecraft:custom_data~{gui:1b}] run item modify entity @s enderchest.13 gui:unlock/diamond
item replace entity @s enderchest.14 from block 2016 77 2004 container.3
execute unless items entity @s enderchest.14 minecraft:light_gray_stained_glass_pane[minecraft:custom_data~{gui:1b}] run item modify entity @s enderchest.14 gui:unlock/netherite
item replace entity @s enderchest.15 from block 2016 77 2004 container.4
execute unless items entity @s enderchest.15 minecraft:light_gray_stained_glass_pane[minecraft:custom_data~{gui:1b}] run item modify entity @s enderchest.15 gui:unbreaking
loot replace entity @s enderchest.16 loot gui:gui_pane
loot replace entity @s enderchest.17 loot gui:gui_pane
loot replace entity @s enderchest.18 loot gui:gui_pane
loot replace entity @s enderchest.19 loot gui:gui_pane
loot replace entity @s enderchest.20 loot gui:gui_pane
loot replace entity @s enderchest.21 loot gui:gui_pane
loot replace entity @s enderchest.22 loot gui:gui_back
loot replace entity @s enderchest.23 loot gui:gui_pane
loot replace entity @s enderchest.24 loot gui:gui_pane
loot replace entity @s enderchest.25 loot gui:gui_pane
loot replace entity @s enderchest.26 loot gui:gui_pane