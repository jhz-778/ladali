#菜单
execute if items entity @s player.cursor minecraft:arrow[!minecraft:custom_model_data={floats:[10.0f]},!minecraft:custom_model_data={floats:[14.0f]}] run scoreboard players set @s gui 1
#物品
execute if items entity @s player.cursor minecraft:crimson_fungus run function gui:store/burst_mushroom
execute if items entity @s player.cursor minecraft:brown_mushroom run function gui:store/growth_mushroom
execute if items entity @s player.cursor #minecraft:eat run function gui:store/eat
execute if items entity @s player.cursor minecraft:chorus_fruit run function gui:store/fruit
execute if items entity @s player.cursor minecraft:golden_apple run function gui:store/golden_apple
execute if items entity @s player.cursor minecraft:enchanted_golden_apple run function gui:store/enchanted_golden_apple
execute if items entity @s player.cursor minecraft:potion[minecraft:custom_model_data={floats:[5.0f]}] run function gui:store/potion_strength
execute if items entity @s player.cursor minecraft:potion[minecraft:custom_model_data={floats:[6.0f]}] run function gui:store/potion_speed
execute if items entity @s player.cursor minecraft:potion[minecraft:custom_model_data={floats:[7.0f]}] run function gui:store/potion_invisible
execute if items entity @s player.cursor minecraft:potion[minecraft:custom_model_data={floats:[8.0f]}] run function gui:store/potion_jump
execute if items entity @s player.cursor minecraft:potion[minecraft:custom_model_data={floats:[9.0f]}] run function gui:store/potion_vision
execute if items entity @s player.cursor minecraft:potion[minecraft:custom_model_data={floats:[13.0f]}] run function gui:store/potion_breath
execute if items entity @s player.cursor minecraft:cookie run function gui:store/cookie