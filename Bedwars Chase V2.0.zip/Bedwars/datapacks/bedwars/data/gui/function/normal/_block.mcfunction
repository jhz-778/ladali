#菜单
execute if items entity @s player.cursor minecraft:arrow[!minecraft:custom_model_data={floats:[10.0f]},!minecraft:custom_model_data={floats:[14.0f]}] run scoreboard players set @s gui 1
#物品
execute if items entity @s player.cursor minecraft:barrel run function gui:store/barrel
execute if items entity @s player.cursor minecraft:cobweb run function gui:store/cobweb
execute if items entity @s player.cursor minecraft:chest run function gui:store/chest
execute if items entity @s player.cursor #minecraft:wool run function gui:store/wool
execute if items entity @s player.cursor #minecraft:planks run function gui:store/planks
execute if items entity @s player.cursor #minecraft:concrete_powder run function gui:store/powder
execute if items entity @s player.cursor #minecraft:concrete run function gui:store/concrete
execute if items entity @s player.cursor minecraft:cobbled_deepslate run function gui:store/deepslate
execute if items entity @s player.cursor #minecraft:glass run function gui:store/glass
execute if items entity @s player.cursor minecraft:ladder run function gui:store/ladder
execute if items entity @s player.cursor minecraft:obsidian run function gui:store/obsidian
execute if items entity @s player.cursor minecraft:reinforced_deepslate run function gui:store/reinforced