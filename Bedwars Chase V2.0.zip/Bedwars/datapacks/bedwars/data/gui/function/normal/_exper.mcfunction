#菜单
execute if items entity @s player.cursor minecraft:arrow[!minecraft:custom_model_data={floats:[10.0f]},!minecraft:custom_model_data={floats:[14.0f]}] run scoreboard players set @s gui 1
#物品
execute if items entity @s player.cursor minecraft:iron_ingot run function gui:store/iron_ingot
execute if items entity @s player.cursor minecraft:gold_ingot run function gui:store/gold_ingot
execute if items entity @s player.cursor minecraft:emerald run function gui:store/emerald