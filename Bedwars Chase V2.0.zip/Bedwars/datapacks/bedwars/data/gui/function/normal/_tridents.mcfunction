#菜单
execute if items entity @s player.cursor minecraft:arrow[!minecraft:custom_model_data={floats:[10.0f]},!minecraft:custom_model_data={floats:[14.0f]}] run scoreboard players set @s gui 1
#物品
execute if items entity @s player.cursor minecraft:trident[minecraft:custom_model_data={floats:[19.0f]}] run function gui:store/trident1
execute if items entity @s player.cursor minecraft:trident[minecraft:custom_model_data={floats:[20.0f]}] run function gui:store/trident2
execute if items entity @s player.cursor minecraft:trident[minecraft:custom_model_data={floats:[21.0f]}] run function gui:store/trident3
execute if items entity @s player.cursor minecraft:trident[minecraft:custom_model_data={floats:[22.0f]}] run function gui:store/trident4
execute if items entity @s player.cursor minecraft:trident[minecraft:custom_model_data={floats:[23.0f]}] run function gui:store/trident5
execute if items entity @s player.cursor minecraft:trident[minecraft:custom_model_data={floats:[24.0f]}] run function gui:store/trident6
execute if items entity @s player.cursor minecraft:trident[minecraft:custom_model_data={floats:[25.0f]}] run function gui:store/trident_riptide