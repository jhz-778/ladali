#菜单
execute if items entity @s player.cursor minecraft:arrow[!minecraft:custom_model_data={floats:[10.0f]},!minecraft:custom_model_data={floats:[14.0f]}] run scoreboard players set @s gui 1
#物品
execute if items entity @s player.cursor minecraft:chainmail_boots run function gui:store/chainmail_armor
execute if items entity @s player.cursor minecraft:iron_boots run function gui:store/iron_armor
execute if items entity @s player.cursor minecraft:diamond_boots[minecraft:custom_model_data={floats:[3.0f]}] run function gui:store/diamond_armor
execute if items entity @s player.cursor minecraft:netherite_boots run function gui:store/netherite_armor
execute if items entity @s player.cursor minecraft:shield run function gui:store/shield