#里菜单
function gui:normal/_pearl
#菜单
execute if items entity @s player.cursor minecraft:arrow[!minecraft:custom_model_data={floats:[10.0f]},!minecraft:custom_model_data={floats:[14.0f]}] run scoreboard players set @s gui 1
execute if items entity @s player.cursor minecraft:ender_pearl[!minecraft:custom_model_data={floats:[6.0f]}] run scoreboard players set @s gui 12
#物品
execute if items entity @s player.cursor minecraft:sponge run function gui:store/sponge
execute if items entity @s player.cursor minecraft:tnt[minecraft:custom_model_data={floats:[2.0f]}] run function gui:store/tnt
execute if items entity @s player.cursor minecraft:iron_golem_spawn_egg run function gui:store/iron_golem
execute if items entity @s player.cursor minecraft:snowball run function gui:store/silverfish
execute if items entity @s player.cursor minecraft:fire_charge[minecraft:custom_model_data={floats:[5.0f]}] run function gui:store/fireball
execute if items entity @s player.cursor minecraft:ice run function gui:store/ice
execute if items entity @s player.cursor minecraft:tnt_minecart run function gui:store/tnt_minecart
execute if items entity @s player.cursor minecraft:blaze_rod run function gui:store/platform
execute if items entity @s player.cursor minecraft:clay_ball run function gui:store/rock
execute if items entity @s player.cursor minecraft:wind_charge run function gui:store/wind_charge
execute if items entity @s player.cursor minecraft:egg run function gui:store/egg
execute if items entity @s player.cursor minecraft:water_bucket run function gui:store/water
execute if items entity @s player.cursor minecraft:milk_bucket run function gui:store/milk
execute if items entity @s player.cursor minecraft:powder_snow_bucket run function gui:store/snow
execute if items entity @s player.cursor minecraft:flow_banner_pattern run function gui:store/scroll
execute if items entity @s player.cursor minecraft:tnt[minecraft:custom_model_data={floats:[20.0f]}] run function gui:store/tnt_water
execute if items entity @s player.cursor minecraft:magma_block run function gui:store/magma_block
execute if items entity @s player.cursor minecraft:soul_sand run function gui:store/soul_sand
execute if items entity @s player.cursor minecraft:lava_bucket run function gui:store/lava
execute if items entity @s player.cursor minecraft:pufferfish_bucket run function gui:store/pufferfish