scoreboard players set @s gui 1
loot replace entity @s enderchest.0 loot gui:gui_pane
loot replace entity @s enderchest.1 loot gui:gui_pane
loot replace entity @s enderchest.2 loot gui:gui_pane
loot replace entity @s enderchest.3 loot gui:gui_pane
loot replace entity @s enderchest.4 loot gui:quicky_buy
loot replace entity @s enderchest.5 loot gui:gui_pane
loot replace entity @s enderchest.6 loot gui:gui_pane
loot replace entity @s enderchest.7 loot gui:gui_pane
loot replace entity @s enderchest.8 loot gui:gui_pane
loot replace entity @s enderchest.9 loot gui:gui_pane
loot replace entity @s enderchest.10 loot gui:normal/weapon
loot replace entity @s enderchest.11 loot gui:normal/bows
execute if data storage minecraft:bedwars {mode:2b} run loot replace entity @s enderchest.11 loot gui:normal/tridents
loot replace entity @s enderchest.12 loot gui:normal/tool
loot replace entity @s enderchest.13 loot gui:normal/block
loot replace entity @s enderchest.14 loot gui:normal/food
loot replace entity @s enderchest.15 loot gui:normal/prop
loot replace entity @s enderchest.16 loot gui:normal/armor
loot replace entity @s enderchest.17 loot gui:gui_pane
loot replace entity @s enderchest.18 loot gui:gui_pane
loot replace entity @s enderchest.19 loot gui:gui_pane
loot replace entity @s enderchest.20 loot gui:gui_pane
loot replace entity @s enderchest.21 loot gui:gui_pane
loot replace entity @s enderchest.22 loot gui:gui_pane
execute if data storage minecraft:bedwars {Special:{exper:1b}} run loot replace entity @s enderchest.22 loot gui:normal/exper
execute if data storage minecraft:bedwars {mode:3b} run loot replace entity @s enderchest.22 loot gui:normal/super
execute if data storage minecraft:bedwars {start:0b} run loot replace entity @s enderchest.22 loot gui:gui_pane
loot replace entity @s enderchest.23 loot gui:gui_pane
loot replace entity @s enderchest.24 loot gui:gui_pane
loot replace entity @s enderchest.25 loot gui:gui_pane
loot replace entity @s enderchest.26 loot gui:gui_pane