loot replace entity @s enderchest.0 loot gui:gui_pane
loot replace entity @s enderchest.1 loot gui:gui_pane
loot replace entity @s enderchest.2 loot gui:gui_pane
loot replace entity @s enderchest.3 loot gui:gui_pane
loot replace entity @s enderchest.4 loot gui:gui_pane
loot replace entity @s enderchest.5 loot gui:gui_pane
loot replace entity @s enderchest.6 loot gui:gui_pane
loot replace entity @s enderchest.7 loot gui:gui_pane
loot replace entity @s enderchest.8 loot gui:gui_pane
loot replace entity @s enderchest.9 loot gui:gui_pane
loot replace entity @s enderchest.10 loot gui:gui_pane
item replace entity @s enderchest.11 from block 2012 75 2008 container.0
loot replace entity @s enderchest.12 loot gui:gui_pane
item replace entity @s enderchest.13 from block 2012 75 2008 container.1
loot replace entity @s enderchest.14 loot gui:gui_pane
item replace entity @s enderchest.15 from block 2012 75 2008 container.2
loot replace entity @s enderchest.16 loot gui:gui_pane
loot replace entity @s enderchest.17 loot gui:gui_pane
loot replace entity @s enderchest.18 loot gui:gui_pane
loot replace entity @s enderchest.19 loot gui:gui_pane
loot replace entity @s enderchest.20 loot gui:gui_pane
loot replace entity @s enderchest.21 loot gui:gui_pane
loot replace entity @s enderchest.22 loot gui:gui_back
loot replace entity @s enderchest.23 loot gui:gui_pane
loot replace entity @s enderchest.24 loot gui:gui_pane
loot replace entity @s enderchest.25 loot gui:gui_pane
loot replace entity @s enderchest.26 loot gui:gui_pane