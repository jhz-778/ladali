#菜单
execute if items entity @s player.cursor minecraft:arrow[!minecraft:custom_model_data={floats:[10.0f]},!minecraft:custom_model_data={floats:[14.0f]}] run scoreboard players set @s gui 1
#超能力
execute if items entity @s player.cursor minecraft:sentry_armor_trim_smithing_template run scoreboard players set @s super 1
execute if items entity @s player.cursor minecraft:wayfinder_armor_trim_smithing_template run scoreboard players set @s super 2
execute if items entity @s player.cursor minecraft:bolt_armor_trim_smithing_template run scoreboard players set @s super 3
execute if items entity @s player.cursor minecraft:flow_armor_trim_smithing_template run scoreboard players set @s super 4
execute if items entity @s player.cursor minecraft:eye_armor_trim_smithing_template run scoreboard players set @s super 5
execute if items entity @s player.cursor minecraft:spire_armor_trim_smithing_template run scoreboard players set @s super 6
execute if items entity @s player.cursor minecraft:rib_armor_trim_smithing_template run scoreboard players set @s super 7
#声音
execute unless items entity @s player.cursor minecraft:netherite_upgrade_smithing_template unless items entity @s player.cursor minecraft:arrow unless items entity @s player.cursor minecraft:lime_stained_glass_pane unless items entity @s player.cursor minecraft:light_gray_stained_glass_pane run function mode:super_chase/attribute
execute unless items entity @s player.cursor minecraft:netherite_upgrade_smithing_template unless items entity @s player.cursor minecraft:arrow unless items entity @s player.cursor minecraft:lime_stained_glass_pane unless items entity @s player.cursor minecraft:light_gray_stained_glass_pane run function mode:super_chase/item
execute unless items entity @s player.cursor minecraft:netherite_upgrade_smithing_template unless items entity @s player.cursor minecraft:arrow unless items entity @s player.cursor minecraft:lime_stained_glass_pane unless items entity @s player.cursor minecraft:light_gray_stained_glass_pane at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2