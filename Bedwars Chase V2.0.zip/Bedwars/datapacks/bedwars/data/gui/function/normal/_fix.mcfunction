#清理
execute unless data entity @s {EnderItems:[{Slot:0b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_0
execute unless data entity @s {EnderItems:[{Slot:1b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_1
execute unless data entity @s {EnderItems:[{Slot:2b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_2
execute unless data entity @s {EnderItems:[{Slot:3b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_3
execute unless data entity @s {EnderItems:[{Slot:4b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_4
execute unless data entity @s {EnderItems:[{Slot:5b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_5
execute unless data entity @s {EnderItems:[{Slot:6b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_6
execute unless data entity @s {EnderItems:[{Slot:7b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_7
execute unless data entity @s {EnderItems:[{Slot:8b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_8
execute unless data entity @s {EnderItems:[{Slot:9b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_9
execute unless data entity @s {EnderItems:[{Slot:10b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_10
execute unless data entity @s {EnderItems:[{Slot:11b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_11
execute unless data entity @s {EnderItems:[{Slot:12b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_12
execute unless data entity @s {EnderItems:[{Slot:13b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_13
execute unless data entity @s {EnderItems:[{Slot:14b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_14
execute unless data entity @s {EnderItems:[{Slot:15b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_15
execute unless data entity @s {EnderItems:[{Slot:16b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_16
execute unless data entity @s {EnderItems:[{Slot:17b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_17
execute unless data entity @s {EnderItems:[{Slot:18b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_18
execute unless data entity @s {EnderItems:[{Slot:19b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_19
execute unless data entity @s {EnderItems:[{Slot:20b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_20
execute unless data entity @s {EnderItems:[{Slot:21b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_21
execute unless data entity @s {EnderItems:[{Slot:22b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_22
execute unless data entity @s {EnderItems:[{Slot:23b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_23
execute unless data entity @s {EnderItems:[{Slot:24b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_24
execute unless data entity @s {EnderItems:[{Slot:25b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_25
execute unless data entity @s {EnderItems:[{Slot:26b,components:{"minecraft:custom_data":{gui:1b}}}]} run function gui:slot_26
#复位
execute if entity @s[tag=fix] run function gui:normal/_list
clear @s *[minecraft:custom_data={gui:1b}]