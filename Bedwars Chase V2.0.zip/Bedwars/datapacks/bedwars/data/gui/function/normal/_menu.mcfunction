execute if items entity @s player.cursor minecraft:nether_star run scoreboard players set @s gui -1
#经典模式
execute if items entity @s player.cursor minecraft:iron_sword run scoreboard players set @s gui 2
execute if items entity @s player.cursor minecraft:bow run scoreboard players set @s gui 3
execute if items entity @s player.cursor minecraft:golden_pickaxe run scoreboard players set @s gui 4
execute if items entity @s player.cursor minecraft:bricks run scoreboard players set @s gui 5
execute if items entity @s player.cursor minecraft:bread run scoreboard players set @s gui 6
execute if items entity @s player.cursor minecraft:fire_charge run scoreboard players set @s gui 7
execute if items entity @s player.cursor minecraft:diamond_boots run scoreboard players set @s gui 8
#其他模式
execute if items entity @s player.cursor minecraft:trident run scoreboard players set @s gui 13
execute if items entity @s player.cursor minecraft:experience_bottle run scoreboard players set @s gui 14
execute if items entity @s player.cursor minecraft:netherite_upgrade_smithing_template run scoreboard players set @s gui 15