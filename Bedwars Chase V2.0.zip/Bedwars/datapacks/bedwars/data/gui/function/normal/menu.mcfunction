execute if data storage minecraft:bedwars {start:0b} run tag @s remove quicky_empty
scoreboard players set @s chest 0
execute if score @s gui matches 0 run function gui:ender_chest
execute if entity @s[tag=!quicky_empty] run return run function gui:quicky/list
execute unless score @s gui matches 1 run function gui:normal/menu_list