execute if score @s gui matches -1 run function gui:quicky/list
execute if score @s gui matches 1 run function gui:normal/menu_list
execute if score @s gui matches 2 run function gui:normal/weapon
execute if score @s gui matches 3 run function gui:normal/bows
execute if score @s gui matches 4 run function gui:normal/tool
execute if score @s gui matches 5 run function gui:normal/block
execute if score @s gui matches 6 run function gui:normal/food
execute if score @s gui matches 7 run function gui:normal/prop
execute if score @s gui matches 8 run function gui:normal/armor
execute if score @s gui matches 9 run function gui:normal/pickaxe
execute if score @s gui matches 10 run function gui:normal/axe
execute if score @s gui matches 11 run function gui:normal/shovel
execute if score @s gui matches 12 run function gui:normal/pearl
execute if score @s gui matches 13 run function gui:normal/tridents
execute if score @s gui matches 14 run function gui:normal/exper
execute if score @s gui matches 15 run function gui:normal/super
execute if score @s gui matches 100 run function gui:normal/team_list
tag @s remove fix