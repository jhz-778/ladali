#经典
execute if items entity @s player.cursor minecraft:blaze_powder run function gui:store/team/fire
execute if items entity @s player.cursor minecraft:iron_sword run function gui:store/team/sharpness
execute if items entity @s player.cursor minecraft:furnace run function gui:store/team/resource
execute if items entity @s player.cursor minecraft:iron_chestplate run function gui:store/team/protection
execute if items entity @s player.cursor minecraft:glowstone_dust run function gui:store/team/glowing
execute if items entity @s player.cursor minecraft:golden_apple run function gui:store/team/twice
execute if items entity @s player.cursor minecraft:golden_pickaxe run function gui:store/team/mining
execute if items entity @s player.cursor minecraft:beacon run function gui:store/team/healing
execute if items entity @s player.cursor minecraft:tripwire_hook run function gui:store/team/trap_slow
execute if items entity @s player.cursor minecraft:iron_pickaxe run function gui:store/team/trap_mining
execute if items entity @s player.cursor minecraft:feather run function gui:store/team/trap_speed
execute if items entity @s player.cursor minecraft:redstone_torch run function gui:store/team/trap_warning
execute if items entity @s player.cursor minecraft:end_portal_frame run function gui:store/team/trap_tp
#其它
execute if items entity @s player.cursor minecraft:apple run function gui:store/team/respawn
execute if items entity @s player.cursor minecraft:turtle_helmet run function gui:store/team/water_breath