execute unless score @s gui matches 4 if items entity @s player.cursor minecraft:arrow[!minecraft:custom_model_data={floats:[10.0f]},!minecraft:custom_model_data={floats:[14.0f]}] run scoreboard players set @s gui 4
execute if items entity @s player.cursor minecraft:wooden_axe[minecraft:custom_model_data={floats:[19.0f]}] run function gui:store/wooden_axe
execute if items entity @s player.cursor minecraft:stone_axe run function gui:store/stone_axe
execute if items entity @s player.cursor minecraft:iron_axe run function gui:store/iron_axe
execute if items entity @s player.cursor minecraft:diamond_axe run function gui:store/diamond_axe
execute if items entity @s player.cursor minecraft:netherite_axe run function gui:store/netherite_axe