#空白页
loot replace entity @s enderchest.0 loot gui:gui_pane
loot replace entity @s enderchest.3 loot gui:gui_pane
loot replace entity @s enderchest.4 loot gui:gui_pane
loot replace entity @s enderchest.5 loot gui:gui_pane
loot replace entity @s enderchest.6 loot gui:gui_pane
loot replace entity @s enderchest.7 loot gui:gui_pane
loot replace entity @s enderchest.8 loot gui:gui_pane
loot replace entity @s enderchest.9 loot gui:gui_pane
loot replace entity @s enderchest.11 loot gui:gui_pane
loot replace entity @s enderchest.12 loot gui:gui_pane
loot replace entity @s enderchest.21 loot gui:gui_pane
loot replace entity @s enderchest.22 loot gui:gui_pane
loot replace entity @s enderchest.23 loot gui:gui_pane
loot replace entity @s enderchest.24 loot gui:gui_pane
loot replace entity @s enderchest.25 loot gui:gui_pane
loot replace entity @s enderchest.26 loot gui:gui_pane
#火焰附加
execute if entity @s[team=red] run scoreboard players operation @s cd = #red_fire tick
execute if entity @s[team=blue] run scoreboard players operation @s cd = #blue_fire tick
execute if entity @s[team=green] run scoreboard players operation @s cd = #green_fire tick
execute if entity @s[team=yellow] run scoreboard players operation @s cd = #yellow_fire tick
execute unless data storage minecraft:bedwars {mode:2b} if score @s cd matches 0.. run item replace entity @s enderchest.0 from block 2018 77 2008 container.23
execute if score @s cd matches 1.. unless score #store_fire uid matches 1 run item replace entity @s enderchest.0 from block 2018 77 2008 container.24
execute if score @s cd matches 2.. unless score #store_fire uid matches 2 run item replace entity @s enderchest.0 from block 2018 77 2008 container.25
execute if score @s cd matches 3.. unless score #store_fire uid matches 3 run item replace entity @s enderchest.0 from block 2018 77 2008 container.26
execute if score @s cd = #store_fire uid run item modify entity @s enderchest.0 gui:teamed
#锋利
execute if entity @s[team=red] run scoreboard players operation @s cd = #red_sharpness tick
execute if entity @s[team=blue] run scoreboard players operation @s cd = #blue_sharpness tick
execute if entity @s[team=green] run scoreboard players operation @s cd = #green_sharpness tick
execute if entity @s[team=yellow] run scoreboard players operation @s cd = #yellow_sharpness tick
execute if score @s cd matches 0.. run item replace entity @s enderchest.1 from block 2018 77 2008 container.0
execute if score @s cd matches 1.. unless score #store_sharpness uid matches 1 run item replace entity @s enderchest.1 from block 2018 77 2008 container.1
execute if score @s cd matches 2.. unless score #store_sharpness uid matches 2 run item replace entity @s enderchest.1 from block 2018 77 2008 container.2
execute if score @s cd matches 3.. unless score #store_sharpness uid matches 3 run item replace entity @s enderchest.1 from block 2018 77 2008 container.3
execute if score @s cd = #store_sharpness uid run item modify entity @s enderchest.1 gui:teamed
#资源
execute if entity @s[team=red] run scoreboard players operation @s cd = #red_resource tick
execute if entity @s[team=blue] run scoreboard players operation @s cd = #blue_resource tick
execute if entity @s[team=green] run scoreboard players operation @s cd = #green_resource tick
execute if entity @s[team=yellow] run scoreboard players operation @s cd = #yellow_resource tick
execute if score @s cd matches 0.. run item replace entity @s enderchest.2 from block 2018 77 2008 container.14
execute if score @s cd matches 1.. unless score #store_resource uid matches 1 run item replace entity @s enderchest.2 from block 2018 77 2008 container.15
execute if score @s cd matches 2.. unless score #store_resource uid matches 2 run item replace entity @s enderchest.2 from block 2018 77 2008 container.16
execute if score @s cd matches 3.. unless score #store_resource uid matches 3 run item replace entity @s enderchest.2 from block 2018 77 2008 container.17
execute if score @s cd = #store_resource uid run item modify entity @s enderchest.2 gui:teamed
#水下呼吸
execute if entity @s[team=red] run scoreboard players operation @s cd = #red_breath tick
execute if entity @s[team=blue] run scoreboard players operation @s cd = #blue_breath tick
execute if entity @s[team=green] run scoreboard players operation @s cd = #green_breath tick
execute if entity @s[team=yellow] run scoreboard players operation @s cd = #yellow_breath tick
execute if data storage minecraft:bedwars {mode:2b} if score @s cd matches 0.. run item replace entity @s enderchest.9 from block 2018 75 2008 container.0
execute if score @s cd matches 1.. unless score #store_water_breath uid matches 1 run item replace entity @s enderchest.9 from block 2018 75 2008 container.1
execute if score @s cd matches 2.. unless score #store_water_breath uid matches 2 run item replace entity @s enderchest.9 from block 2018 75 2008 container.2
execute if score @s cd matches 3.. unless score #store_water_breath uid matches 3 run item replace entity @s enderchest.9 from block 2018 75 2008 container.3
execute if score @s cd = #store_water_breath uid run item modify entity @s enderchest.9 gui:teamed
#快速重生
execute if data storage minecraft:bedwars {mode:1b} run item replace entity @s enderchest.9 from block 2018 75 2008 container.18
execute if data storage minecraft:bedwars {mode:3b} run item replace entity @s enderchest.9 from block 2018 75 2008 container.18
execute if entity @s[team=red] if data storage minecraft:red {respawn:1b} run item modify entity @s enderchest.9 gui:teamed
execute if entity @s[team=blue] if data storage minecraft:blue {respawn:1b} run item modify entity @s enderchest.9 gui:teamed
execute if entity @s[team=green] if data storage minecraft:green {respawn:1b} run item modify entity @s enderchest.9 gui:teamed
execute if entity @s[team=yellow] if data storage minecraft:yellow {respawn:1b} run item modify entity @s enderchest.9 gui:teamed
#保护
execute if entity @s[team=red] run scoreboard players operation @s cd = #red_protection tick
execute if entity @s[team=blue] run scoreboard players operation @s cd = #blue_protection tick
execute if entity @s[team=green] run scoreboard players operation @s cd = #green_protection tick
execute if entity @s[team=yellow] run scoreboard players operation @s cd = #yellow_protection tick
execute if score @s cd matches 0.. run item replace entity @s enderchest.10 from block 2018 77 2008 container.5
execute if score @s cd matches 1.. unless score #store_protection uid matches 1 run item replace entity @s enderchest.10 from block 2018 77 2008 container.6
execute if score @s cd matches 2.. unless score #store_protection uid matches 2 run item replace entity @s enderchest.10 from block 2018 77 2008 container.7
execute if score @s cd matches 3.. unless score #store_protection uid matches 3 run item replace entity @s enderchest.10 from block 2018 77 2008 container.8
execute if score @s cd = #store_protection uid run item modify entity @s enderchest.10 gui:teamed
#夜视增益
execute if data storage minecraft:detail {rain_plan:1b} run item replace entity @s enderchest.11 from block 2018 75 2008 container.11
execute if entity @s[team=red] if data storage minecraft:red {glowing:1b} run item modify entity @s enderchest.11 gui:teamed
execute if entity @s[team=blue] if data storage minecraft:blue {glowing:1b} run item modify entity @s enderchest.11 gui:teamed
execute if entity @s[team=green] if data storage minecraft:green {glowing:1b} run item modify entity @s enderchest.11 gui:teamed
execute if entity @s[team=yellow] if data storage minecraft:yellow {glowing:1b} run item modify entity @s enderchest.11 gui:teamed
#失明陷阱
item replace entity @s enderchest.13 from block 2018 75 2008 container.13
execute store result score @s[team=red] tick run scoreboard players get #red_trap_slow tick
execute store result score @s[team=blue] tick run scoreboard players get #blue_trap_slow tick
execute store result score @s[team=green] tick run scoreboard players get #green_trap_slow tick
execute store result score @s[team=yellow] tick run scoreboard players get #yellow_trap_slow tick
execute if score @s tick matches 1.. run item modify entity @s enderchest.13 gui:traped
#挖掘疲劳陷阱
item replace entity @s enderchest.14 from block 2018 75 2008 container.14
execute store result score @s[team=red] tick run scoreboard players get #red_trap_mining tick
execute store result score @s[team=blue] tick run scoreboard players get #blue_trap_mining tick
execute store result score @s[team=green] tick run scoreboard players get #green_trap_mining tick
execute store result score @s[team=yellow] tick run scoreboard players get #yellow_trap_mining tick
execute if score @s tick matches 1.. run item modify entity @s enderchest.14 gui:traped
#反击陷阱
item replace entity @s enderchest.15 from block 2018 75 2008 container.15
execute store result score @s[team=red] tick run scoreboard players get #red_trap_speed tick
execute store result score @s[team=blue] tick run scoreboard players get #blue_trap_speed tick
execute store result score @s[team=green] tick run scoreboard players get #green_trap_speed tick
execute store result score @s[team=yellow] tick run scoreboard players get #yellow_trap_speed tick
execute if score @s tick matches 1.. run item modify entity @s enderchest.15 gui:traped
#警报陷阱
item replace entity @s enderchest.16 from block 2018 75 2008 container.16
execute store result score @s[team=red] tick run scoreboard players get #red_trap_warning tick
execute store result score @s[team=blue] tick run scoreboard players get #blue_trap_warning tick
execute store result score @s[team=green] tick run scoreboard players get #green_trap_warning tick
execute store result score @s[team=yellow] tick run scoreboard players get #yellow_trap_warning tick
execute if score @s tick matches 1.. run item modify entity @s enderchest.16 gui:traped
#传送陷阱
item replace entity @s enderchest.17 from block 2018 75 2008 container.17
execute store result score @s[team=red] tick run scoreboard players get #red_trap_tp tick
execute store result score @s[team=blue] tick run scoreboard players get #blue_trap_tp tick
execute store result score @s[team=green] tick run scoreboard players get #green_trap_tp tick
execute store result score @s[team=yellow] tick run scoreboard players get #yellow_trap_tp tick
execute if score @s tick matches 1.. run item modify entity @s enderchest.17 gui:traped
#二次生命
item replace entity @s enderchest.18 from block 2018 75 2008 container.10
execute if entity @s[team=red] if data storage minecraft:red {twice:1b} run item modify entity @s enderchest.18 gui:teamed
execute if entity @s[team=blue] if data storage minecraft:blue {twice:1b} run item modify entity @s enderchest.18 gui:teamed
execute if entity @s[team=green] if data storage minecraft:green {twice:1b} run item modify entity @s enderchest.18 gui:teamed
execute if entity @s[team=yellow] if data storage minecraft:yellow {twice:1b} run item modify entity @s enderchest.18 gui:teamed
#急迫
execute if entity @s[team=red] run scoreboard players operation @s cd = #red_mining tick
execute if entity @s[team=blue] run scoreboard players operation @s cd = #blue_mining tick
execute if entity @s[team=green] run scoreboard players operation @s cd = #green_mining tick
execute if entity @s[team=yellow] run scoreboard players operation @s cd = #yellow_mining tick
execute if score @s cd matches 0.. run item replace entity @s enderchest.19 from block 2018 77 2008 container.9
execute if score @s cd matches 1.. unless score #store_mining uid matches 1 run item replace entity @s enderchest.19 from block 2018 77 2008 container.10
execute if score @s cd matches 2.. unless score #store_mining uid matches 2 run item replace entity @s enderchest.19 from block 2018 77 2008 container.11
execute if score @s cd matches 3.. unless score #store_mining uid matches 3 run item replace entity @s enderchest.19 from block 2018 77 2008 container.12
execute if score @s cd = #store_mining uid run item modify entity @s enderchest.19 gui:teamed
#治愈池
execute if entity @s[team=red] run scoreboard players operation @s cd = #red_healing tick
execute if entity @s[team=blue] run scoreboard players operation @s cd = #blue_healing tick
execute if entity @s[team=green] run scoreboard players operation @s cd = #green_healing tick
execute if entity @s[team=yellow] run scoreboard players operation @s cd = #yellow_healing tick
execute if score @s cd matches 0.. run item replace entity @s enderchest.20 from block 2018 77 2008 container.18
execute if score @s cd matches 1.. unless score #store_healing uid matches 1 run item replace entity @s enderchest.20 from block 2018 77 2008 container.19
execute if score @s cd matches 2.. unless score #store_healing uid matches 2 run item replace entity @s enderchest.20 from block 2018 77 2008 container.20
execute if score @s cd matches 3.. unless score #store_healing uid matches 3 run item replace entity @s enderchest.20 from block 2018 77 2008 container.21
execute if score @s cd = #store_healing uid run item modify entity @s enderchest.20 gui:teamed