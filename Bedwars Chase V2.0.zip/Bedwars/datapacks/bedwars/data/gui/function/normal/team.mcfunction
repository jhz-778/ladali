execute if score @s gui matches 0 run function gui:ender_chest
scoreboard players set @s gui 100
function gui:normal/team_list