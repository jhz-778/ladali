#镐类
execute unless score @s pickaxe matches 1.. run item replace entity @s enderchest.10 from block 2012 75 2004 container.0
execute if score @s pickaxe matches 1 run item replace entity @s enderchest.10 from block 2012 75 2004 container.1
execute if score @s pickaxe matches 2 run item replace entity @s enderchest.10 from block 2012 75 2004 container.2
execute if score @s pickaxe matches 3 run item replace entity @s enderchest.10 from block 2012 75 2004 container.3
execute if score @s pickaxe matches 4.. run item replace entity @s enderchest.10 from block 2012 75 2004 container.4
item modify entity @s enderchest.10 gui:unlock/pickaxe
#斧类
execute unless score @s axe matches 1.. run item replace entity @s enderchest.11 from block 2014 75 2004 container.0
execute if score @s axe matches 1 run item replace entity @s enderchest.11 from block 2014 75 2004 container.1
execute if score @s axe matches 2 run item replace entity @s enderchest.11 from block 2014 75 2004 container.2
execute if score @s axe matches 3 run item replace entity @s enderchest.11 from block 2014 75 2004 container.3
execute if score @s axe matches 4.. run item replace entity @s enderchest.11 from block 2014 75 2004 container.4
item modify entity @s enderchest.11 gui:unlock/axe
#锹类
execute unless score @s shovel matches 1.. run item replace entity @s enderchest.12 from block 2016 75 2004 container.0
execute if score @s shovel matches 1 run item replace entity @s enderchest.12 from block 2016 75 2004 container.1
execute if score @s shovel matches 2 run item replace entity @s enderchest.12 from block 2016 75 2004 container.2
execute if score @s shovel matches 3 run item replace entity @s enderchest.12 from block 2016 75 2004 container.3
execute if score @s shovel matches 4.. run item replace entity @s enderchest.12 from block 2016 75 2004 container.4
item modify entity @s enderchest.12 gui:unlock/shovel