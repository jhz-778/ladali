execute unless score @s gui matches 4 if items entity @s player.cursor minecraft:arrow[!minecraft:custom_model_data={floats:[10.0f]},!minecraft:custom_model_data={floats:[14.0f]}] run scoreboard players set @s gui 4
execute if items entity @s player.cursor minecraft:wooden_shovel[minecraft:custom_model_data={floats:[28.0f]}] run function gui:store/wooden_shovel
execute if items entity @s player.cursor minecraft:stone_shovel run function gui:store/stone_shovel
execute if items entity @s player.cursor minecraft:iron_shovel run function gui:store/iron_shovel
execute if items entity @s player.cursor minecraft:diamond_shovel run function gui:store/diamond_shovel
execute if items entity @s player.cursor minecraft:netherite_shovel run function gui:store/netherite_shovel