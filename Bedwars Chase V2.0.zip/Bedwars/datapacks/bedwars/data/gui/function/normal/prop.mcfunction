loot replace entity @s enderchest.0 loot gui:gui_pane
item replace entity @s enderchest.1 from block 2018 77 2004 container.10
item replace entity @s enderchest.2 from block 2018 77 2004 container.11
item replace entity @s enderchest.3 from block 2018 77 2004 container.18
item replace entity @s enderchest.4 from block 2018 77 2004 container.13
item replace entity @s enderchest.5 from block 2018 77 2004 container.12
item replace entity @s enderchest.6 from block 2018 77 2004 container.17
execute if data storage minecraft:bedwars {mode:2b} run item replace entity @s enderchest.6 from block 2018 75 2004 container.1
item replace entity @s enderchest.7 from block 2018 77 2004 container.9
execute if data storage minecraft:bedwars {mode:2b} run item replace entity @s enderchest.7 from block 2018 75 2004 container.2
loot replace entity @s enderchest.8 loot gui:gui_pane
item replace entity @s enderchest.9 from block 2018 77 2004 container.0
execute if data storage minecraft:bedwars {mode:2b} run item replace entity @s enderchest.9 from block 2018 75 2004 container.3
item replace entity @s enderchest.10 from block 2018 77 2004 container.1
execute if data storage minecraft:bedwars {mode:2b} run item replace entity @s enderchest.10 from block 2018 75 2004 container.0
item replace entity @s enderchest.11 from block 2018 77 2004 container.2
item replace entity @s enderchest.12 from block 2018 77 2004 container.3
item replace entity @s enderchest.13 from block 2018 77 2004 container.4
loot replace entity @s enderchest.14 loot gui:normal/pearl
execute if score #store_ender_pearl tick matches 0 if score #store_back_pearl tick matches 1 if score #store_move_pearl tick matches 1 if score #store_tp_pearl tick matches 1 run item replace entity @s enderchest.14 from block 2018 77 2004 container.5
execute if score #store_ender_pearl tick matches 1 if score #store_back_pearl tick matches 0 if score #store_move_pearl tick matches 1 if score #store_tp_pearl tick matches 1 run item replace entity @s enderchest.14 from block 2018 77 2004 container.6
execute if score #store_ender_pearl tick matches 1 if score #store_back_pearl tick matches 1 if score #store_move_pearl tick matches 0 if score #store_tp_pearl tick matches 1 run item replace entity @s enderchest.14 from block 2018 77 2004 container.7
execute if score #store_ender_pearl tick matches 1 if score #store_back_pearl tick matches 1 if score #store_move_pearl tick matches 1 if score #store_tp_pearl tick matches 0 run item replace entity @s enderchest.14 from block 2018 77 2004 container.8
item replace entity @s enderchest.15 from block 2018 77 2004 container.14
item replace entity @s enderchest.16 from block 2018 77 2004 container.15
execute if data storage minecraft:bedwars {mode:2b} run item replace entity @s enderchest.16 from block 2018 75 2004 container.4
item replace entity @s enderchest.17 from block 2018 77 2004 container.16
loot replace entity @s enderchest.18 loot gui:gui_pane
loot replace entity @s enderchest.19 loot gui:gui_pane
loot replace entity @s enderchest.20 loot gui:gui_pane
loot replace entity @s enderchest.21 loot gui:gui_pane
loot replace entity @s enderchest.22 loot gui:gui_back
loot replace entity @s enderchest.23 loot gui:gui_pane
loot replace entity @s enderchest.24 loot gui:gui_pane
loot replace entity @s enderchest.25 loot gui:gui_pane
loot replace entity @s enderchest.26 loot gui:gui_pane