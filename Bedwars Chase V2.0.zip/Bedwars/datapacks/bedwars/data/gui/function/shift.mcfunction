#检测
execute if items entity @s player.cursor *[minecraft:max_stack_size=1] run return run tag @s remove shift
scoreboard players operation @s shift = @s number
scoreboard players operation @s shift *= #math2 math
execute if score @s custom < @s shift run return run tag @s remove shift
execute if entity @s[tag=teambuy] run return run tag @s remove shift
scoreboard players set @s shift 64
scoreboard players set @s[tag=shift16] shift 16
scoreboard players operation @s shift /= @s amount
execute unless score @s shift matches 2.. run return run tag @s remove shift
$execute unless score #store_$(STORE) limit matches 0 unless score @s limit < #store_$(STORE) limit run return run tag @s remove shift
#处理
scoreboard players set @s shift 64
scoreboard players set @s[tag=shift16] shift 16
function gui:store/_shift with storage minecraft:bedwars
tag @s remove shifted
execute unless data storage minecraft:bedwars {Special:{exper:1b}} run function gui:success
execute if data storage minecraft:bedwars {Special:{exper:1b}} run function mode:exper/success