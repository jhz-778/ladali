#检测
execute if score @s dummy matches -1 store result score @s custom run clear @s minecraft:diamond 0
execute if score @s dummy matches 0 store result score @s custom run clear @s minecraft:nether_star 0
execute if score @s dummy matches 1 store result score @s custom run clear @s minecraft:iron_ingot 0
execute if score @s dummy matches 2 store result score @s custom run clear @s minecraft:gold_ingot 0
execute if score @s dummy matches 3 store result score @s custom run clear @s minecraft:emerald 0
#判定
execute if score @s custom < @s number run scoreboard players set @s cd 3
execute if score @s custom < @s number run scoreboard players operation @s number -= @s custom