#镐类
loot replace block 2012 75 2004 container.9 loot gui:gui_pane
loot replace block 2012 75 2004 container.10 loot gui:gui_pane
loot replace block 2012 75 2004 container.11 loot gui:gui_pane
loot replace block 2012 75 2004 container.12 loot gui:gui_pane
loot replace block 2012 75 2004 container.13 loot gui:gui_pane
#斧类
loot replace block 2014 75 2004 container.9 loot gui:gui_pane
loot replace block 2014 75 2004 container.10 loot gui:gui_pane
loot replace block 2014 75 2004 container.11 loot gui:gui_pane
loot replace block 2014 75 2004 container.12 loot gui:gui_pane
loot replace block 2014 75 2004 container.13 loot gui:gui_pane
#锹类
loot replace block 2016 75 2004 container.9 loot gui:gui_pane
loot replace block 2016 75 2004 container.10 loot gui:gui_pane
loot replace block 2016 75 2004 container.11 loot gui:gui_pane
loot replace block 2016 75 2004 container.12 loot gui:gui_pane
loot replace block 2016 75 2004 container.13 loot gui:gui_pane