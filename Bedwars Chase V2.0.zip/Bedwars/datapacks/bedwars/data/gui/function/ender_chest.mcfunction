tag @s add chestore
execute as @e[type=minecraft:marker,tag=saves] if score @s uid = @a[tag=chestore,limit=1] uid run data modify entity @s data.EnderItems set from entity @a[tag=chestore,limit=1] EnderItems
tag @s remove chestore