execute if entity @s[type=minecraft:item_display] unless data storage minecraft:bedwars {mode:2b} positioned ~ ~ ~ summon minecraft:marker run function explode:model
execute unless entity @s[type=minecraft:item_display] positioned ~ ~ ~ summon minecraft:marker run function explode:model
tag @s add exploding
execute as @a if score @s uid = @e[type=minecraft:tnt,tag=exploding,limit=1] uid run tag @s add exploding
execute positioned ~ ~-0.25 ~ as @a[distance=..3.5,gamemode=!spectator] run damage @s 7.5 minecraft:explode by @a[limit=1,tag=exploding]
tag @a remove exploding
execute if data storage minecraft:bedwars {dragon:1b} run gamerule mobGriefing false
execute if data storage minecraft:bedwars {dragon:1b} run schedule function bedwars:mobgriefing 2t replace
summon minecraft:creeper ~ ~ ~ {Invulnerable:1b,CustomName:'{"text":"TNT"}',Fuse:-1,Attributes:[{Name:"generic.scale",Base:0.0625}]}
execute unless data storage minecraft:bedwars {dragon:1b} run particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 1 1 force
kill @s