execute as @a[scores={tnt=1..}] at @s run function explode:tnt
scoreboard players remove @e[type=minecraft:tnt,scores={explode=1..}] explode 1
execute as @e[type=minecraft:tnt,scores={explode=0}] at @s run function explode:explode