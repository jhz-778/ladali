execute if score @s explode matches 400.. run setblock ^ ^ ^ minecraft:air destroy
scoreboard players remove @s explode 400
tag @s add tested