execute if score @s explode matches 30.. run setblock ^ ^ ^ minecraft:air destroy
scoreboard players remove @s explode 30
tag @s add tested