execute if score @s explode matches 285.. run setblock ^ ^ ^ minecraft:air destroy
scoreboard players remove @s explode 285
tag @s add tested