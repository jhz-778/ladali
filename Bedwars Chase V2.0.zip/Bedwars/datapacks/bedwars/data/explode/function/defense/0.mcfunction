execute if score @s explode matches 0.. run setblock ^ ^ ^ minecraft:air destroy
tag @s add tested