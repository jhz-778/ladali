execute if score @s explode matches 100.. run setblock ^ ^ ^ minecraft:air destroy
scoreboard players remove @s explode 100
tag @s add tested