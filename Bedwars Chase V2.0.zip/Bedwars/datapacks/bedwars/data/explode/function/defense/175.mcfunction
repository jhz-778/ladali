execute if score @s explode matches 175.. unless block ^ ^ ^ #minecraft:waters run setblock ^ ^ ^ minecraft:air destroy
scoreboard players remove @s explode 175
tag @s add tested