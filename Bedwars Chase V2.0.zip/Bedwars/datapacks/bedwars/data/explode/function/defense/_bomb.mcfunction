execute if block ^ ^ ^ #minecraft:defense_pass run tag @s add tested
execute if block ^ ^ ^ #minecraft:defense_0 run function explode:defense/0
execute if block ^ ^ ^ #minecraft:defense_30 run function explode:defense/30
execute if block ^ ^ ^ #minecraft:defense_100 run function explode:defense/100
execute if block ^ ^ ^ #minecraft:defense_175 run function explode:defense/175
execute if block ^ ^ ^ #minecraft:defense_285 run function explode:defense/285
execute if block ^ ^ ^ #minecraft:defense_400 run function explode:defense/400
execute if entity @s[tag=!tested] run scoreboard players set @s explode -1
tag @s remove tested