execute as @e[type=minecraft:item,tag=bomb] store result score @s explode run data get entity @s Age
execute as @e[type=minecraft:item,scores={explode=-1..},tag=bomb] on vehicle run kill @s
execute as @e[type=minecraft:item,scores={explode=-1..},tag=bomb] run data merge entity @s {Invulnerable:0b}