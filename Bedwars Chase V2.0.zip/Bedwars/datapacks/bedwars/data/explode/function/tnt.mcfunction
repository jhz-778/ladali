execute as @e[type=minecraft:tnt,tag=!tnt] run function explode:tnt_fix
scoreboard players operation #tnt uid = @s uid
fill ~6 ~6 ~6 ~-6 ~-6 ~-6 minecraft:command_block{auto:1b,Command:"function explode:bomb/tnt"} replace minecraft:tnt
execute positioned ~ 70 ~ run fill ~6 ~6 ~6 ~-6 ~-6 ~-6 minecraft:command_block{auto:1b,Command:"function explode:bomb/tnt"} replace minecraft:tnt
execute positioned ~ 105 ~ run fill ~6 ~6 ~6 ~-6 ~-6 ~-6 minecraft:command_block{auto:1b,Command:"function explode:bomb/tnt"} replace minecraft:tnt
scoreboard players set @s tnt 0