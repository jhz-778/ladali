#爆炸力度
scoreboard players set @s explode 785
scoreboard players set @s[tag=fireball] explode 475
scoreboard players set @s[tag=bomber] explode 400
tag @s remove fireball
#起爆点
execute if block ~ ~ ~ #minecraft:combination_step_sound_blocks run tag @s add tested
execute if block ~ ~ ~ #minecraft:slabs run tag @s add tested
execute if block ~ ~ ~ #minecraft:defense_pass run tag @s add tested
execute if block ~ ~ ~ #minecraft:defense_0 run function explode:defense/0
execute if block ~ ~ ~ #minecraft:defense_30 run function explode:defense/30
execute if block ~ ~ ~ #minecraft:defense_100 run function explode:defense/100
execute unless block ~ ~ ~ #minecraft:waters if block ~ ~ ~ #minecraft:defense_175 run function explode:defense/175
execute if block ~ ~ ~ #minecraft:defense_285 run function explode:defense/285
execute if block ~ ~ ~ #minecraft:defense_400 run function explode:defense/400
execute if entity @s[tag=!tested] run scoreboard players set @s explode -1
tag @s remove tested
#衰减
execute if score @s explode matches 100.. run function explode:bomb/1st
execute as @e[type=minecraft:item,nbt={Age:0s},distance=..5] at @s run function explode:invul
schedule function explode:item 3t append
#清除
kill @s