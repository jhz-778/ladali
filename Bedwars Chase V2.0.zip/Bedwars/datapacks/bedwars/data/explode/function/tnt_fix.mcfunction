tag @s add tnt
data merge entity @s {fuse:32767s}
execute as @e[type=minecraft:tnt,tag=tnt] store result score @s explode run data get storage minecraft:detail tnt_time