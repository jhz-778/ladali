setblock ~ ~ ~ minecraft:air replace
summon minecraft:tnt ~ ~-0.5 ~ {fuse:32767s,Tags:["tnt"]}
execute as @e[type=minecraft:tnt,tag=tnt] unless score @s explode = @s explode run scoreboard players operation @s uid = #tnt uid
execute as @e[type=minecraft:tnt,tag=tnt] unless score @s explode = @s explode store result score @s explode run data get storage minecraft:detail tnt_time