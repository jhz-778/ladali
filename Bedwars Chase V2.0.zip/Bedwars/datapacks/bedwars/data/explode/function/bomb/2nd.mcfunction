#爆炸AB位
execute store result score @s explode run data get entity @s data.a1
execute store result score @s math run data get entity @s data.b1
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^1 ^ ^1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.ab2 int 1 run scoreboard players get @s explode
#爆炸DA位
execute store result score @s explode run data get entity @s data.d1
execute store result score @s math run data get entity @s data.a1
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^-1 ^ ^1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.da2 int 1 run scoreboard players get @s explode
#爆炸CD位
execute store result score @s explode run data get entity @s data.c1
execute store result score @s math run data get entity @s data.d1
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^-1 ^ ^-1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.cd2 int 1 run scoreboard players get @s explode
#爆炸BC位
execute store result score @s explode run data get entity @s data.b1
execute store result score @s math run data get entity @s data.c1
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^1 ^ ^-1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.bc2 int 1 run scoreboard players get @s explode
#爆炸MA位
execute store result score @s explode run data get entity @s data.m1
execute store result score @s math run data get entity @s data.a1
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^ ^1 ^1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.ma2 int 1 run scoreboard players get @s explode
#爆炸MB位
execute store result score @s explode run data get entity @s data.m1
execute store result score @s math run data get entity @s data.b1
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^1 ^1 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.mb2 int 1 run scoreboard players get @s explode
#爆炸MC位
execute store result score @s explode run data get entity @s data.m1
execute store result score @s math run data get entity @s data.c1
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^ ^1 ^-1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.mc2 int 1 run scoreboard players get @s explode
#爆炸MD位
execute store result score @s explode run data get entity @s data.m1
execute store result score @s math run data get entity @s data.d1
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^-1 ^1 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.md2 int 1 run scoreboard players get @s explode
#爆炸NA位
execute store result score @s explode run data get entity @s data.n1
execute store result score @s math run data get entity @s data.a1
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^ ^-1 ^1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.na2 int 1 run scoreboard players get @s explode
#爆炸NB位
execute store result score @s explode run data get entity @s data.n1
execute store result score @s math run data get entity @s data.b1
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^1 ^-1 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.nb2 int 1 run scoreboard players get @s explode
#爆炸NC位
execute store result score @s explode run data get entity @s data.n1
execute store result score @s math run data get entity @s data.c1
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^ ^-1 ^-1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.nc2 int 1 run scoreboard players get @s explode
#爆炸ND位
execute store result score @s explode run data get entity @s data.n1
execute store result score @s math run data get entity @s data.d1
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^-1 ^-1 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.nd2 int 1 run scoreboard players get @s explode
#爆炸上位
execute store result score @s explode run data get entity @s data.m1
execute positioned ^ ^2 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.m2 int 1 run scoreboard players get @s explode
#爆炸下位
execute store result score @s explode run data get entity @s data.n1
execute positioned ^ ^-2 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.n2 int 1 run scoreboard players get @s explode
#爆炸前位
execute store result score @s explode run data get entity @s data.a1
execute positioned ^ ^ ^2 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.a2 int 1 run scoreboard players get @s explode
#爆炸后位
execute store result score @s explode run data get entity @s data.c1
execute positioned ^ ^ ^-2 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.c2 int 1 run scoreboard players get @s explode
#爆炸左位
execute store result score @s explode run data get entity @s data.b1
execute positioned ^2 ^ ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.b2 int 1 run scoreboard players get @s explode
#爆炸右位
execute store result score @s explode run data get entity @s data.d1
execute positioned ^-2 ^ ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.d2 int 1 run scoreboard players get @s explode
#三级衰减
function explode:bomb/3rd