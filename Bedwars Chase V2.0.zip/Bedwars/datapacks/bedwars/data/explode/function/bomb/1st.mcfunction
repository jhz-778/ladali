#一级衰减
scoreboard players remove @s explode 100
execute store result entity @s data.st int 1 run scoreboard players get @s explode
#爆炸上位
execute positioned ^ ^1 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.m1 int 1 run scoreboard players get @s explode
#爆炸下位
execute store result score @s explode run data get entity @s data.st
execute positioned ^ ^-1 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.n1 int 1 run scoreboard players get @s explode
#爆炸前位
execute store result score @s explode run data get entity @s data.st
execute positioned ^ ^ ^1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.a1 int 1 run scoreboard players get @s explode
#爆炸后位
execute store result score @s explode run data get entity @s data.st
execute positioned ^ ^ ^-1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.c1 int 1 run scoreboard players get @s explode
#爆炸左位
execute store result score @s explode run data get entity @s data.st
execute positioned ^1 ^ ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.b1 int 1 run scoreboard players get @s explode
#爆炸右位
execute store result score @s explode run data get entity @s data.st
execute positioned ^-1 ^ ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.d1 int 1 run scoreboard players get @s explode
#二级衰减
function explode:bomb/2nd