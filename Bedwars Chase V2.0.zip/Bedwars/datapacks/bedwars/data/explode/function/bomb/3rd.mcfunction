#爆炸MAB位
execute store result score @s explode run data get entity @s data.ma2
execute store result score @s math run data get entity @s data.mb2
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.ab2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^1 ^1 ^1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.mab3 int 1 run scoreboard players get @s explode
#爆炸MDA位
execute store result score @s explode run data get entity @s data.ma2
execute store result score @s math run data get entity @s data.md2
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.da2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-1 ^1 ^1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.mda3 int 1 run scoreboard players get @s explode
#爆炸MCD位
execute store result score @s explode run data get entity @s data.mc2
execute store result score @s math run data get entity @s data.md2
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.cd2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-1 ^1 ^-1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.mcd3 int 1 run scoreboard players get @s explode
#爆炸MBC位
execute store result score @s explode run data get entity @s data.mb2
execute store result score @s math run data get entity @s data.mc2
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.bc2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^1 ^1 ^-1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.mbc3 int 1 run scoreboard players get @s explode
#爆炸NAB位
execute store result score @s explode run data get entity @s data.na2
execute store result score @s math run data get entity @s data.nb2
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.ab2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^1 ^-1 ^1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.nab3 int 1 run scoreboard players get @s explode
#爆炸NDA位
execute store result score @s explode run data get entity @s data.na2
execute store result score @s math run data get entity @s data.nd2
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.da2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-1 ^-1 ^1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.nda3 int 1 run scoreboard players get @s explode
#爆炸NCD位
execute store result score @s explode run data get entity @s data.nc2
execute store result score @s math run data get entity @s data.nd2
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.cd2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-1 ^-1 ^-1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.ncd3 int 1 run scoreboard players get @s explode
#爆炸NBC位
execute store result score @s explode run data get entity @s data.nb2
execute store result score @s math run data get entity @s data.nc2
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.bc2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^1 ^-1 ^-1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.nbc3 int 1 run scoreboard players get @s explode
#爆炸AB位
execute store result score @s explode run data get entity @s data.a2
execute store result score @s math run data get entity @s data.ab2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^1 ^ ^2 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.ab3 int 1 run scoreboard players get @s explode
#爆炸AD位
execute store result score @s explode run data get entity @s data.a2
execute store result score @s math run data get entity @s data.da2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^-1 ^ ^2 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.ad3 int 1 run scoreboard players get @s explode
#爆炸BA位
execute store result score @s explode run data get entity @s data.b2
execute store result score @s math run data get entity @s data.ab2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^2 ^ ^1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.ba3 int 1 run scoreboard players get @s explode
#爆炸BC位
execute store result score @s explode run data get entity @s data.b2
execute store result score @s math run data get entity @s data.bc2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^2 ^ ^-1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.bc3 int 1 run scoreboard players get @s explode
#爆炸CB位
execute store result score @s explode run data get entity @s data.c2
execute store result score @s math run data get entity @s data.bc2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^1 ^ ^-2 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.cb3 int 1 run scoreboard players get @s explode
#爆炸CD位
execute store result score @s explode run data get entity @s data.c2
execute store result score @s math run data get entity @s data.cd2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^-1 ^ ^-2 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.cd3 int 1 run scoreboard players get @s explode
#爆炸DA位
execute store result score @s explode run data get entity @s data.d2
execute store result score @s math run data get entity @s data.da2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^-2 ^ ^1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.da3 int 1 run scoreboard players get @s explode
#爆炸DC位
execute store result score @s explode run data get entity @s data.d2
execute store result score @s math run data get entity @s data.cd2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^-2 ^ ^-1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.dc3 int 1 run scoreboard players get @s explode
#爆炸AM位
execute store result score @s explode run data get entity @s data.a2
execute store result score @s math run data get entity @s data.ma2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^ ^1 ^2 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.am3 int 1 run scoreboard players get @s explode
#爆炸BM位
execute store result score @s explode run data get entity @s data.b2
execute store result score @s math run data get entity @s data.mb2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^2 ^1 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.bm3 int 1 run scoreboard players get @s explode
#爆炸CM位
execute store result score @s explode run data get entity @s data.c2
execute store result score @s math run data get entity @s data.mc2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^ ^1 ^-2 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.cm3 int 1 run scoreboard players get @s explode
#爆炸DM位
execute store result score @s explode run data get entity @s data.d2
execute store result score @s math run data get entity @s data.md2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^-2 ^1 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.dm3 int 1 run scoreboard players get @s explode
#爆炸MA位
execute store result score @s explode run data get entity @s data.m2
execute store result score @s math run data get entity @s data.ma2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^ ^2 ^1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.ma3 int 1 run scoreboard players get @s explode
#爆炸MB位
execute store result score @s explode run data get entity @s data.m2
execute store result score @s math run data get entity @s data.mb2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^1 ^2 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.mb3 int 1 run scoreboard players get @s explode
#爆炸MC位
execute store result score @s explode run data get entity @s data.m2
execute store result score @s math run data get entity @s data.mc2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^ ^2 ^-1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.mc3 int 1 run scoreboard players get @s explode
#爆炸MD位
execute store result score @s explode run data get entity @s data.m2
execute store result score @s math run data get entity @s data.md2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^-1 ^2 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.md3 int 1 run scoreboard players get @s explode
#爆炸AN位
execute store result score @s explode run data get entity @s data.a2
execute store result score @s math run data get entity @s data.na2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^ ^-1 ^2 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.an3 int 1 run scoreboard players get @s explode
#爆炸BN位
execute store result score @s explode run data get entity @s data.b2
execute store result score @s math run data get entity @s data.nb2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^2 ^-1 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.bn3 int 1 run scoreboard players get @s explode
#爆炸CN位
execute store result score @s explode run data get entity @s data.c2
execute store result score @s math run data get entity @s data.nc2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^ ^-1 ^-2 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.cn3 int 1 run scoreboard players get @s explode
#爆炸DN位
execute store result score @s explode run data get entity @s data.d2
execute store result score @s math run data get entity @s data.nd2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^-2 ^-1 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.dn3 int 1 run scoreboard players get @s explode
#爆炸NA位
execute store result score @s explode run data get entity @s data.n2
execute store result score @s math run data get entity @s data.na2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^ ^-2 ^1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.na3 int 1 run scoreboard players get @s explode
#爆炸NB位
execute store result score @s explode run data get entity @s data.n2
execute store result score @s math run data get entity @s data.nb2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^1 ^-2 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.nb3 int 1 run scoreboard players get @s explode
#爆炸NC位
execute store result score @s explode run data get entity @s data.n2
execute store result score @s math run data get entity @s data.nc2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^ ^-2 ^-1 run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.nc3 int 1 run scoreboard players get @s explode
#爆炸ND位
execute store result score @s explode run data get entity @s data.n2
execute store result score @s math run data get entity @s data.nd2
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math2 math
execute positioned ^-1 ^-2 ^ run function explode:defense/_bomb
scoreboard players remove @s explode 100
execute if score @s explode matches ..-2 run scoreboard players set @s explode -1
execute store result entity @s data.nd3 int 1 run scoreboard players get @s explode
#四级衰减
function explode:bomb/4th