#爆炸AMB位
execute store result score @s explode run data get entity @s data.am3
execute store result score @s math run data get entity @s data.mab3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.ab3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^1 ^1 ^2 run function explode:defense/_bomb
#爆炸AMD位
execute store result score @s explode run data get entity @s data.am3
execute store result score @s math run data get entity @s data.mda3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.ad3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-1 ^1 ^2 run function explode:defense/_bomb
#爆炸BMA位
execute store result score @s explode run data get entity @s data.bm3
execute store result score @s math run data get entity @s data.mab3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.ba3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^2 ^1 ^1 run function explode:defense/_bomb
#爆炸BMC位
execute store result score @s explode run data get entity @s data.bm3
execute store result score @s math run data get entity @s data.mbc3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.bc3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^2 ^1 ^-1 run function explode:defense/_bomb
#爆炸CMB位
execute store result score @s explode run data get entity @s data.cm3
execute store result score @s math run data get entity @s data.mbc3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.ab3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^1 ^1 ^-2 run function explode:defense/_bomb
#爆炸CMD位
execute store result score @s explode run data get entity @s data.cm3
execute store result score @s math run data get entity @s data.mcd3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.cd3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-1 ^1 ^-2 run function explode:defense/_bomb
#爆炸DMA位
execute store result score @s explode run data get entity @s data.dm3
execute store result score @s math run data get entity @s data.mda3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.da3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-2 ^1 ^1 run function explode:defense/_bomb
#爆炸DMC位
execute store result score @s explode run data get entity @s data.dm3
execute store result score @s math run data get entity @s data.mcd3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.dc3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-2 ^1 ^-1 run function explode:defense/_bomb
#爆炸MAB位
execute store result score @s explode run data get entity @s data.ma3
execute store result score @s math run data get entity @s data.mb3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.mab3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^1 ^2 ^1 run function explode:defense/_bomb
#爆炸MBC位
execute store result score @s explode run data get entity @s data.mb3
execute store result score @s math run data get entity @s data.mc3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.mbc3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^1 ^2 ^-1 run function explode:defense/_bomb
#爆炸MCD位
execute store result score @s explode run data get entity @s data.mc3
execute store result score @s math run data get entity @s data.md3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.mcd3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-1 ^2 ^-1 run function explode:defense/_bomb
#爆炸MDA位
execute store result score @s explode run data get entity @s data.md3
execute store result score @s math run data get entity @s data.ma3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.mda3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-1 ^2 ^1 run function explode:defense/_bomb
#爆炸ABN位
execute store result score @s explode run data get entity @s data.an3
execute store result score @s math run data get entity @s data.nab3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.ab3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^1 ^-1 ^2 run function explode:defense/_bomb
#爆炸ADN位
execute store result score @s explode run data get entity @s data.an3
execute store result score @s math run data get entity @s data.nda3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.ad3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-1 ^-1 ^2 run function explode:defense/_bomb
#爆炸BAN位
execute store result score @s explode run data get entity @s data.bn3
execute store result score @s math run data get entity @s data.nab3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.ba3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^2 ^-1 ^1 run function explode:defense/_bomb
#爆炸BCN位
execute store result score @s explode run data get entity @s data.bn3
execute store result score @s math run data get entity @s data.nbc3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.bc3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^2 ^-1 ^-1 run function explode:defense/_bomb
#爆炸CBN位
execute store result score @s explode run data get entity @s data.cn3
execute store result score @s math run data get entity @s data.nbc3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.cb3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^1 ^-1 ^-2 run function explode:defense/_bomb
#爆炸CDN位
execute store result score @s explode run data get entity @s data.cn3
execute store result score @s math run data get entity @s data.ncd3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.cd3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-1 ^-1 ^-2 run function explode:defense/_bomb
#爆炸DAN位
execute store result score @s explode run data get entity @s data.dn3
execute store result score @s math run data get entity @s data.nda3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.da3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-2 ^-1 ^1 run function explode:defense/_bomb
#爆炸DCN位
execute store result score @s explode run data get entity @s data.dn3
execute store result score @s math run data get entity @s data.ncd3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.dc3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-2 ^-1 ^-1 run function explode:defense/_bomb
#爆炸NAB位
execute store result score @s explode run data get entity @s data.na3
execute store result score @s math run data get entity @s data.nb3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.nab3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^1 ^-2 ^1 run function explode:defense/_bomb
#爆炸NBC位
execute store result score @s explode run data get entity @s data.nb3
execute store result score @s math run data get entity @s data.nc3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.nbc3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^1 ^-2 ^-1 run function explode:defense/_bomb
#爆炸NCD位
execute store result score @s explode run data get entity @s data.nc3
execute store result score @s math run data get entity @s data.nd3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.ncd3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-1 ^-2 ^-1 run function explode:defense/_bomb
#爆炸NDA位
execute store result score @s explode run data get entity @s data.nd3
execute store result score @s math run data get entity @s data.na3
scoreboard players operation @s explode += @s math
execute store result score @s math run data get entity @s data.nda3
scoreboard players operation @s explode += @s math
scoreboard players operation @s explode /= #math3 math
execute positioned ^-1 ^-2 ^1 run function explode:defense/_bomb