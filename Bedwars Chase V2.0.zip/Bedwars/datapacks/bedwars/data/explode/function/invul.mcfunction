data merge entity @s {Invulnerable:1b,Age:-3s}
tag @s add bomb
execute summon minecraft:item_display run ride @e[type=minecraft:item,tag=bomb,limit=1,sort=nearest] mount @s