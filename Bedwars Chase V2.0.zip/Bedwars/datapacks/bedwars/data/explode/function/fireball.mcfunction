execute unless data storage minecraft:bedwars {mode:2b} positioned ~ ~-0.25 ~ summon minecraft:marker run tag @s add fireball
tag @s add exploding
execute as @a if score @s uid = @e[type=minecraft:armor_stand,tag=exploding,limit=1] uid run tag @s add exploding
execute positioned ~ ~-0.25 ~ as @a[distance=..3.5,gamemode=!spectator] run damage @s 6.25 minecraft:fireball by @a[limit=1,tag=exploding]
tag @a remove exploding
execute as @e[type=minecraft:marker,tag=fireball] at @s run function explode:model
execute if data storage minecraft:bedwars {dragon:1b} run gamerule mobGriefing false
execute if data storage minecraft:bedwars {dragon:1b} run schedule function bedwars:mobgriefing 2t replace
execute unless data storage minecraft:bedwars {dragon:1b} run particle minecraft:explosion_emitter ~ ~-0.25 ~ 0 0 0 1 1 force
kill @s